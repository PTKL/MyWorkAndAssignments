matrix-curses
=============

matrix code animation for curses - see how deep the rabbit-hole goes

![All I see now is blonde, brunette, redhead](https://raw.github.com/devsnd/matrix-curses/master/screenshot.jpg)

works with python 2 and 3.
