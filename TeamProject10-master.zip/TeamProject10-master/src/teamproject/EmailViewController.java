package teamproject;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

/**
 * Controller for Email View
 * @author vamsi
 *
 */
public class EmailViewController {

  @FXML //fx:id for cancel button : CancelButton
  private Button CancelButton;
  
  @FXML //fx:id for Send Email : SendEmailButton
  private Button SendEmailButton;
  
  @FXML
  private TextArea content;
  
  @FXML
  void initialize() {
    SendEmailButton.setOnAction(new EventHandler<ActionEvent>(){

      @Override
      public void handle(ActionEvent event) {
        EmailClient e = new EmailClient("chicks@salsa.com","","Special Offer",content.getText());
        for(ManagerViewLoginTable mv : Model.getModel().getDatabase().displayLoginTable()){
          if(mv.getLogintype().equalsIgnoreCase("Customer")){
            e.setTo(mv.getUsername());
            e.sendEmail();
          }
        }
        ViewManager.getInstance().showManagerView();
      }
      
    });
    
    CancelButton.setOnAction(new EventHandler<ActionEvent>(){
      @Override
      public void handle(ActionEvent event) {
        ViewManager.getInstance().showManagerView();
        
      }
      
    });
    
  }
}