package teamproject;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.util.Duration;

/**
 * @author emil
 * @author seong
 */
public class KitchenHomeViewController {

  @FXML // ResourceBundle that was given to the FXMLLoader
  private ResourceBundle resources;

  @FXML // URL location of the FXML file that was given to the FXMLLoader
  private URL location;

  @FXML
  private TabPane tabPane;

  @FXML
  private ListView<String> orderedList;

  @FXML // fx:id="logout"
  private Button logout; // Value injected by FXMLLoader

  @FXML
  private Button orderReadyBtn;

  @FXML // fx:id="callWaiter"
  private Button callWaiter; // Value injected by FXMLLoader

  ObservableList<String> obsOrderList = FXCollections.observableArrayList();
  ArrayList<Order> orderList = new ArrayList<>();
  ArrayList<Order> underwayList = new ArrayList<>();

  @FXML // This method is called by the FXMLLoader when initialization is
        // complete
  void initialize() {

    logout.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        ViewManager.getInstance().showLoginScreen();
      }
    });
    orderList = getOrderedList();
    underwayList = getUnderwayList();
    setupOrders();

    // check orders every 2 secs
    // currently not working
    /*
     * Timer timer = new Timer(); timer.scheduleAtFixedRate(new TimerTask() {
     * 
     * @Override public void run() { checkNewOrders(); } }, 0, 2000);
     */
  }

  /**
   * setup orders. adds underway orders to the tabPane and ordered orders to the
   * listview
   */
  public void setupOrders() {
    Tab tab;
    tabPane.getTabs().clear();
    obsOrderList.clear();

    for (Order o : underwayList) {
      tab = createOrderTab(o);
      tabPane.getTabs().add(tab);
    }
    for (Order o : orderList) {
      obsOrderList.add("Order " + o.getOrderID());
    }
    orderedList.setItems(obsOrderList);
  }

  public void refreshBtnController() {
    checkNewOrders();
  }

  /**
   * controller for the underway button changes order status of the selected
   * order to underway removes from list and adds to tab
   */
  public void underwayBtnController() {
    Tab tab = new Tab();
    int index = orderedList.getSelectionModel().getSelectedIndex();
    if (index > -1) {
      Order temp = orderList.get(index);

      StockRoom.getInstance().update();
      StockRoom.getInstance().orderStarted(temp);
      Model.getModel().getDatabase().removeOrderFromOrderReservationCJB(temp);

      nextOrderStatus(temp);

      orderList.remove(index);
      obsOrderList.remove(index);
      orderedList.setItems(obsOrderList);

      tab = createOrderTab(temp);
      tabPane.getTabs().add(tab);
      underwayList.add(temp);
    } else {
      Alert alert = new Alert(AlertType.ERROR);
      alert.setTitle("Select an order!");
      alert.setHeaderText(null);
      alert.setContentText("Select an order you wish to get underway!");
      alert.showAndWait();
    }
  }

  /**
   * controller for the ready button. changes selected orderstatus to ready and
   * removes from tab
   */
  public void orderReadyBtnController() {
    Tab tab;
    int index = tabPane.getSelectionModel().getSelectedIndex();
    if (index > -1) {
      Order o = underwayList.get(index);
      
      nextOrderStatus(o);
      
      tab = getTabByOrder(o);
      tabPane.getTabs().remove(tab);
      underwayList.remove(index);
      System.out.println("?");
      Model.getModel().getDatabase().toggleReady(o.getOrderID());
    } else {
      Alert alert = new Alert(AlertType.ERROR);
      alert.setTitle("Select an order!");
      alert.setHeaderText(null);
      alert.setContentText("Select an order thats ready!");
      alert.showAndWait();
    }
  }

  /**
   * checks for new orders. alerts if there are new orders or if orders are
   * cancelled
   */
  public void checkNewOrders() {
    ArrayList<Order> check = getOrderedList();
    Tab tab;
    // order added
    if (orderList.size() < check.size()) {
      for (Order o : check) {
        if (!orderList.contains(o)) {
          // will close after 3 secs
          Alert a = new Alert(AlertType.INFORMATION);
          a.setTitle("NEW ORDER!");
          a.setHeaderText(null);
          a.setContentText("Order " + o.getOrderID() + " added!");
          PauseTransition delay = new PauseTransition(Duration.seconds(3));
          delay.setOnFinished(event -> a.hide());
          delay.play();
          a.showAndWait();
          // not sure if to close or not.
          // could use this to confirm order
          // when ok is pressed -> o.NextStep();
          obsOrderList.add("Order " + o.getOrderID());
          orderedList.setItems(obsOrderList);
        }
      }
    }
    // order is cancelled
    if (orderList.size() > check.size()) {
      for (Order o : orderList) {
        if (!check.contains(o)) {

          Alert a = new Alert(AlertType.INFORMATION);
          a.setTitle("ORDER CANCELLED!");
          a.setHeaderText(null);
          a.setContentText("Order " + o.getOrderID() + " cancelled!");
          PauseTransition delay = new PauseTransition(Duration.seconds(3));
          delay.setOnFinished(event -> a.hide());
          delay.play();
          a.showAndWait();

          obsOrderList.remove("Order " + o.getOrderID());
          orderedList.setItems(obsOrderList);
        }
      }
    }
    orderList = new ArrayList<Order>(check);
  }

  /**
   * get 'ordered' orders from database.
   * 
   * @return arraylist of 'ordered' orders from the database
   */
  public ArrayList<Order> getOrderedList() {
    ArrayList<Order> retList = new ArrayList<>();
    for (Order o : Model.getModel().getDatabase().getAllOrders()) {
      if (isOrdered(o)) {
        retList.add(o);
      }
    }
    return retList;
  }

  /**
   * gets 'underway' orders from the database.
   * 
   * @return arraylist of 'underway' orders from the database
   */
  public ArrayList<Order> getUnderwayList() {
    ArrayList<Order> retList = new ArrayList<>();
    for (Order o : Model.getModel().getDatabase().getAllOrders()) {
      if (isUnderway(o)) {
        retList.add(o);
      }
    }
    return retList;
  }

  /**
   * Creates a order tab.
   * the tab will have order info 
   * @param o order to create tab
   * @return a tab with order 
   */
  public Tab createOrderTab(Order o) {
    Tab orderTab = new Tab("Order " + o.getOrderID());
    ListView<String> orderInfo = new ListView<>();
    ObservableList<String> orderObservableList = FXCollections.observableArrayList();

    for (MenuItem item : o.getMenuItems()) {
      orderObservableList.add(item.getName());
    }

    orderTab.setContent(orderInfo);
    orderInfo.setItems(orderObservableList);
    return orderTab;
  }
  /**
   * get tab by Order.
   * @param o the order to get tab by
   * @return a Tab with the same order id
   */
  public Tab getTabByOrder(Order o) {
    Tab tab = new Tab();
    for (Tab t : tabPane.getTabs()) {
      if (t.getText().equals("Order " + o.getOrderID())) {
        tab = t;
      }
    }
    return tab;
  }
  /**
   * next order status.
   * removes the order from database,
   * changes the orderstatus to the next orderstatus
   * add the order to the database
   * @param o Order to change the order status
   */
  public void nextOrderStatus(Order o) {
    Model.getModel().getDatabase().removeOrderFromOrderCJB(o);
    System.out.println(""+o.toString());
    o.NextStep();
    System.out.println(""+o.toString());
    Model.getModel().getDatabase().addOrderToOrderCJB(o);
  }

  /**
   * check if order is 'ordered'.
   * @param o Order to check
   * @return true if the orderstatus is 'ordered'
   */
  public boolean isOrdered(Order o) {
    return o.getOrderStatus().equals(OrderStatus.ordered);
  }
  /**
   * check if order is 'underway'.
   * @param o order to check
   * @return true if the orderstatus is 'underway'
   */
  public boolean isUnderway(Order o) {
    return o.getOrderStatus().equals(OrderStatus.underway);
  }
}
