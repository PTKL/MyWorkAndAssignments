package teamproject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

// TODO prepared statements not check for sql special chars
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.Random;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * sqlJDBC provides the database needed for the program to function. It stores
 * ingredients, meals(courses), menus, orders, staff info allergies etc. It will
 * be used as a gateway for different parts of program to interact with each
 * other. For example if waiter confirms an order this order will go to the
 * database, kitchen staff will see new order through the thread, that monitors
 * changes in the database, once an order is confirmed, kitchen will receive a
 * notification about new order.
 * 
 * @author Nikoloz , Callum
 *
 */
public class sqlJDBC {

	private static final String menuitemsCJBDesc = "menuitem varchar(2048) primary key";
	private static final String ingredientsCJBDesc = "stocklevel int, ingredient varchar(2048) primary key";
	private static final String waiterCJBDesc = "username varchar(255) primary key";
	private static final String customerCJBDesc = "username varchar(255) primary key";
	private static final String loginsCJBDesc = "username varchar(255) primary key,salt varchar(255) ,hash varchar(2048) NOT NULL,userType varchar(256) NOT NULL";
	private static final String orderCJBDesc = "ord varchar(16384) primary key";
	private static final String orderReservationCJBDesc = "ord varchar(16384) primary key";
	private static final String customerWaiterCallsCJBDesc = "tbl int primary key, time bigint";
	private static final String waiterReadyCJBDesc = "tbl int primary key, time bigint";
	private static final String customerdata = "username varchar(255) primary key, userType varchar(255), email varchar(255)";
	private static final String staffdata = "id int primary key, username varchar(255), responcetime int, numberoforders, int";
	private static final String waiterTableCJBDesc = "username varchar(255) primary key, id int, assignedTables varchar(255), waiterSale int";

	/**
	 * @param iterations
	 *            Number of each times each hash is hashed, to increase brute
	 *            force security.
	 */
	private static final int iterations = 10000;

	private Connection connection;
	private static sqlJDBC instance;

	public static sqlJDBC getsqlJDBC() {
		if (instance == null) {
			instance = new sqlJDBC();
		}
		return instance;
	}

	private sqlJDBC() {
		/** where the database is hosted */
		String host = "localhost";

		// db port 27010
		/** port is port number where program can connect to the database */
		String port = "11000";
		/** database is a name of the database */
		String database = "teamproject";

		// Making connection to the database with username, port and test
		// database. change username to the current user forwarding on
		// the db connection on putty
		connection = connectToDatabase(host, port, database, "manager", "manager");

		if (connection != null) {
		} else {
			System.out.println("Failed to make connection!");
			return;
		}

	}

	//// READY FOR DELIVERY ////
	public void toggleReady(int i) {
		if (getWaiterReadyCJBIDS().contains(i)) {
			// remove from table
			try {
				String query = "DELETE FROM waiterReadyCJB WHERE tbl=?;";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, i);
				preparedStatement.execute();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			// add to table
			Date d = new Date();
			String query = "INSERT INTO waiterReadyCJB (tbl,time) VALUES ('" + i + "','" + d.getTime() + "');";
			execute(query);
		}
	}

	public ArrayList<Integer> getWaiterReadyCJBIDS() {
		ArrayList<Integer> ids = new ArrayList<Integer>();

		String query = "SELECT * FROM waiterReadyCJB";
		ResultSet result = executeSelect(query);

		try {
			while (result.next()) {
				ids.add(result.getInt(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return ids;
	}

	public Long getReadyTimeCalled(int tableNumber) {
		String query = "SELECT * FROM waiterReadyCJB";
		ResultSet result = executeSelect(query);

		try {
			if (result.next()) {
				return result.getLong(2);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	//// WAITER FUNCTIONS ////

	public void toggleCall(int i) {
		if (getCustomerWaiterCalls().contains(i)) {
			// remove from table
			try {
				String query = "DELETE FROM customerWaiterCallsCJB WHERE tbl=?;";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, i);
				preparedStatement.execute();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			// add to table
			Date d = new Date();
			String query = "INSERT INTO customerWaiterCallsCJB (tbl,time) VALUES ('" + i + "','" + d.getTime() + "');";
			execute(query);
		}
	}

	public ArrayList<Integer> getCustomerWaiterCalls() {
		ArrayList<Integer> calls = new ArrayList<Integer>();

		String query = "SELECT * FROM customerWaiterCallsCJB";
		ResultSet result = executeSelect(query);

		try {
			while (result.next()) {
				calls.add(result.getInt(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return calls;
	}

	public Long getTableNumberTimeCalled(int tableNumber) {
		String query = "SELECT * FROM customerWaiterCallsCJB";
		ResultSet result = executeSelect(query);

		try {
			if (result.next()) {
				return result.getLong(2);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

  public void waiterTable() {
    try {
      addTable("waiterTableCJB", waiterTableCJBDesc);
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  public void clearWaiterTable() {
    dropTable("waiterTableCJB");
    try {
      addTable("waiterTableCJB", waiterTableCJBDesc);
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
  
  public void addWaiter(Waiter waiter) {
    ArrayList<Integer> tbl = waiter.getAssignedTables();
    String assigntbl = "";
    for (int i : tbl) {
      assigntbl += i;
    }
    try {
      String query = "INSERT INTO waiterTableCJB (username, id, assignedTables, waiterSale) " + "VALUES (?,?,?,?);";
      PreparedStatement preparedStatement = connection.prepareStatement(query);
      preparedStatement.setString(1, waiter.getUsername());
      preparedStatement.setInt(2, waiter.getID());
      preparedStatement.setString(3, assigntbl);
      preparedStatement.setInt(4, waiter.getExtraSales());
      preparedStatement.execute();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  public void removeWaiter(Waiter waiter) {
    try {
      String query = "DELETE FROM waiterTableCJB WHERE username=?;";
      PreparedStatement preparedStatement = connection.prepareStatement(query);
      preparedStatement.setString(1, waiter.getUsername());
      preparedStatement.execute();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  public ArrayList<Waiter> getAllWaiters() throws SQLException {
    ArrayList<Waiter> waiters = new ArrayList<>();
    Waiter waiter;

    String waiterQuery = "SELECT * FROM waiterTableCJB;";
    ResultSet rs = executeSelect(waiterQuery);
    while (rs.next()) {
      char[] ch = rs.getString(3).toCharArray();
      ArrayList<Integer> tbl = new ArrayList<>();
      for (char c : ch) {
        tbl.add(Character.getNumericValue(c));
      }
      waiter = new Waiter(rs.getString(1), rs.getInt(2), tbl, rs.getInt(4));
      waiters.add(waiter);
    }
    return waiters;

  }

  public Waiter getWaiter(String username) throws SQLException {
    Waiter waiter;

    String waiterQuery = "SELECT * FROM waiterTableCJB WHERE username = '" + username + "';";
    ResultSet rs = executeSelect(waiterQuery);
    ArrayList<Integer> tbl = new ArrayList<>();
    rs.next();
    char[] ch = rs.getString(3).toCharArray();
    for (char c : ch) {
      tbl.add(Character.getNumericValue(c));
    }
    waiter = new Waiter(rs.getString(1), rs.getInt(2), tbl, rs.getInt(4));
    return waiter;
  }
	//// ORDER FUNCTIONS ////

	/**
	 * TODO JAVADOC
	 * 
	 * @author CAllum
	 */
	public void modifyOrderToOrderCJB(Order oldOrder, Order newOrder) {
		removeOrderFromOrderCJB(oldOrder);
		addOrderToOrderCJB(newOrder);
	}

	/**
	 * TODO JAVADOC
	 * 
	 * @author CAllum
	 */
	public void addOrderToOrderReservationCJB(Order order) {
		try {
			String query = "INSERT INTO orderReservationCJB (ord) VALUES (?);";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, order.toString());
			preparedStatement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * TODO JAVADOC
	 * 
	 * @author CAllum
	 */
	public void removeOrderFromOrderReservationCJB(Order order) {
    String query = "DELETE FROM orderReservationCJB WHERE ord='"+order.toString()+"';";
    execute(query);
	}

	/**
	 * TODO JAVADOC
	 * 
	 * @author CAllum
	 */
	public ArrayList<Order> getAllOrderReservationCJB() {
		ArrayList<Order> orders = new ArrayList<Order>();

		String query = "SELECT * FROM orderReservationCJB;";
		ResultSet orderResult = executeSelect(query);

		try {
			while (orderResult.next()) {
				orders.add(Order.toOrder(orderResult.getString(1)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return orders;
	}

	/**
	 * TODO JAVADOC
	 * 
	 * @author CAllum
	 */
	public void addOrderToOrderCJB(Order order) {
		try {
			String query = "INSERT INTO orderCJB (ord) VALUES (?);";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, order.toString());
			preparedStatement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * TODO JAVADOC
	 * 
	 * @author CAllum
	 */
	public void removeOrderFromOrderCJB(Order order) {
    String query = "DELETE FROM orderCJB WHERE ord='"+order.toString()+"';";
    execute(query);
	}

	/**
	 * TODO JAVADOC
	 * 
	 * @author CAllum
	 */
	public void setOrderID() {
		int id = 0;
		ArrayList<Order> order = getAllOrders();
		for (Order o : order) {
			if (o.getOrderID() > id) {
				id = o.getOrderID();
			}
		}
		id++;
		Order.orderIdNext = id;
	}

	/**
	 * TODO JAVADOC
	 * 
	 * @author CAllum
	 */
	public ArrayList<Order> getAllOrders() {
		ArrayList<Order> orders = new ArrayList<Order>();

		String query = "SELECT * FROM orderCJB";
		ResultSet orderResult = executeSelect(query);

		try {
			while (orderResult.next()) {
				orders.add(Order.toOrder(orderResult.getString(1)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return orders;
	}

	//// LOGIN FUNCTIONS ////
	// waiter functions

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	public void addWaiterLogin(String username, String password) {
		if (!(containsAny(username) || containsAny(password))) {
			addLogin(username, password, LoginType.Waiter);
			// TODO get more info from them and add to waiter table
		}
	}

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	public void modifyWaiterLogin(String username, String password) {
		removeLogin(username);
		addWaiterLogin(username, password);
	}

	// customer functions

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	public void addCustomerLogin(String username, String password) {
		if (!(containsAny(password) || containsAny(username))) {
			addLogin(username, password, LoginType.Customer);
			// TODO get more info from them and add to customer table
		}
	}

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	public void modifyCustomerLogin(String username, String password) {
		removeLogin(username);
		addCustomerLogin(username, password);
	}

	// kitchen functions

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	public void addKitchenLogin(String username, String password) {
		if (!(containsAny(password) || containsAny(username))) {
			addLogin(username, password, LoginType.Kitchen);
		}
	}

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	public void modifyKitchenLogin(String username, String password) {
		removeLogin(username);
		addKitchenLogin(username, password);
	}

	// manager functions

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	public void addManagerLogin(String username, String password) {
		if (!(containsAny(password) || containsAny(username))) {
			addLogin(username, password, LoginType.Manager);
		}
	}

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	public void modifyManagerLogin(String username, String password) {
		removeLogin(username);
		addManagerLogin(username, password);
	}

	// login functions

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	private void addLogin(String username, String password, LoginType loginType) {
		// check for sql injection
		if (!(containsAny(password) || containsAny(username))) {

			try {
				ResultSet rs = executeSelect("SELECT * FROM loginsCJB WHERE username='" + username + "';");
				if (rs.next()) {
					return;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}

			byte[] salt = generateSalt();
			String passwordHash = hash(password, salt.toString());
			String loginTypeStr = loginType.toString();

			String query = "INSERT INTO loginsCJB (username,salt,hash,userType) VALUES ('" + username + "','"
					+ salt.toString() + "','" + passwordHash + "','" + loginTypeStr + "');";
			execute(query);
		}
	}

	public boolean containsUsername(String username) {
		// check for sql injection
		if (!containsAny(username)) {

			try {
				ResultSet rs = executeSelect("SELECT * FROM loginsCJB WHERE username='" + username + "';");
				if (rs.next()) {
					return true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return false;
	}

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	private byte[] generateSalt() {
		final Random r = new SecureRandom();
		byte[] salt = new byte[32];
		r.nextBytes(salt);
		return salt;
	}

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	public void removeLogin(String username) {
		if (!(containsAny(username))) {
			String query = "DELETE FROM loginsCJB WHERE username='" + username + "';";
			execute(query);
		}
	}

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	public boolean validLogin(String username, String password) {
		// check for sql injection
		if (!containsAny(password) && !containsAny(username)) {
			// check password and username work

			String query = "SELECT * FROM loginsCJB WHERE username='" + username + "';";

			ResultSet rs = executeSelect(query);
			try {
				while (rs.next()) {
					if (rs.getString(3).equalsIgnoreCase(hash(password, rs.getString(2)))) {
						return true;
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return false;
	}

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	public LoginType getLoginType(String username) {
		// check for sql injection
		if (!containsAny(username)) {
			// check password and username work

			String query = "SELECT * FROM loginsCJB WHERE username='" + username + "';";

			ResultSet rs = executeSelect(query);
			try {
				while (rs.next()) {
					return LoginType.toLoginType(rs.getString(4));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return null;
	}

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @author Callum
	 */
	public ObservableList<ManagerViewLoginTable> displayLoginTable() {
		ObservableList<ManagerViewLoginTable> data = FXCollections.observableArrayList();

		String query = "SELECT * FROM loginsCJB;";

		ResultSet rs = executeSelect(query);
		try {
			while (rs.next()) {
				// "username ,salt ,hash ,userType ";
				data.add(new ManagerViewLoginTable(rs.getString(1), rs.getString(4), rs.getString(2), rs.getString(3)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return data;
	}

	/**
	 * TODO JAVADOC TODO JUNIT
	 * 
	 * @param checkingIfContains
	 * @return
	 */
	private boolean containsAny(String checkingIfContains) {
		CharSequence checkingFor[] = { "&", "[", "]", "_", "'", ";", "%", "+", "*", "/", "\\", ">", "<", "|", "=", "!",
				"^", "\"" };

		for (int i = 0; i < checkingFor.length; i++) {
			if (checkingIfContains.contains(checkingFor[i])) {
				System.out.println("ATTEMPTED SQL INJECTION");
				return true;
			}
		}

		return false;
	}

	/**
	 * A function which takes the inputed string and appends the sqlJDBC's
	 * static salt then completing a number of pre-specficed number of
	 * iterations. Upon the inputed String and salt and returns the result.<br>
	 * 
	 * @param The
	 *            string you wish to get the hash for.<br>
	 * @return <b>String</b><br>
	 *         SHA512 hash of the passed in String, combined with the salt
	 *         thorough a defined number of SHA512 iterations.<br>
	 * @author Callum
	 */
	public static String hash(String toHash, String salt) {
		String hash = toHash + salt;
		for (int i = 0; i < sqlJDBC.iterations; i++) {
			hash = SHA512(hash);
		}
		return hash;
	}

	/**
	 * A function which takes a String parameter and returns the SHA-512 hash of
	 * the passed in parameter.<br>
	 * 
	 * @param string
	 *            The string you wish to get the hash for.<br>
	 * @return <b>String</b><br>
	 *         SHA512 hash of the passed in String.
	 * @author mkyong.com
	 */
	private static String SHA512(String string) {
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("SHA-512");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		md.update(string.getBytes());

		byte byteData[] = md.digest();

		// convert the byte to hex format method 1
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < byteData.length; i++) {
			sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
		}

		return sb.toString();
	}

	//// INGREDIENT FUNCTIONS ////

	/**
	 * Takes two Ingredient parameters. The New Ingredient is used to modify the
	 * old and replaces the old's values/data structures.<br>
	 * 
	 * @param oldIngredient
	 *            Old Ingredient which is being modified by the new.<br>
	 * @param newIngredient
	 *            New Ingredient which is modifying the old.<br>
	 * @author Callum
	 */
	public void modifyIngredientInIngredientsCJB(Ingredient oldIngredient, Ingredient newIngredient) {
		removeIngredientFromIngredientCJB(oldIngredient);
		addIngredientToIngredientCJB(newIngredient);
	}

	/**
	 * A function which takes a Ingredient parameter and adds it to the
	 * ingredientsCJB table in sqlJDBC singleton's current database connection.
	 * <br>
	 * 
	 * @param ingredient
	 *            The Ingredient you want to add.
	 * @author Callum
	 */
	public void addIngredientToIngredientCJB(Ingredient ingredient) {
		if (!(getAllIngredients().contains(ingredient)) && !(containsAny(ingredient.toString()))) {
			String query = "INSERT INTO ingredientsCJB (stocklevel,ingredient) VALUES ('0','" + ingredient.toString()
					+ "');";
			execute(query);
		}
	}

	/**
	 * A function which takes a Ingredient parameter and removes it from the
	 * ingredientsCJB table in sqlJDBC singleton's current database connection.
	 * <br>
	 * 
	 * @param ingredient
	 *            The Ingredient you want to remove.
	 * @author Callum
	 */
	public void removeIngredientFromIngredientCJB(Ingredient ingredient) {
		if (!(containsAny(ingredient.toString()))) {
			String query = "DELETE FROM ingredientsCJB WHERE ingredient='" + ingredient.toString() + "';";
			execute(query);
		}
	}

	/**
	 * A function which takes an Ingredient parameter and a Integer parameter
	 * and adds to the ingredient's stock level the passed in Integer. If the
	 * Integer is greater than zero.<br>
	 * 
	 * @param i
	 *            The number you wish to add to the current stock level.
	 * @param ingredient
	 *            The ingredient you're adding to the stock level off.
	 * @author Callum
	 */
	public void addToIngredientStockLevel(int i, Ingredient ingredient) {
		int current = getIngredientStockLevel(ingredient);// will return 0 if
		// not found
		if (i > 0 && !(containsAny(ingredient.toString()))) {
			current += i;
			// wouldnt set anything if not in db as doesnt meet WHERE
			String query = "UPDATE ingredientsCJB SET stocklevel='" + current + "' WHERE ingredient='"
					+ ingredient.toString() + "';";
			execute(query);
		}
	}

	/**
	 * A function which takes an Ingredient parameter and a Integer parameter
	 * and deducts from the ingredient's stock level the passed in Integer. If
	 * the Integer is greater than zero.<br>
	 * 
	 * @param i
	 *            The number you wish to deduct from the current stock level.
	 * @param ingredient
	 *            The ingredient you're deducting the stock level off.
	 * @author Callum
	 */
	public void deductFromIngredientStockLevel(int i, Ingredient ingredient) {
		int current = getIngredientStockLevel(ingredient);// will return 0 if
		// not found
		if (i > 0 && !(containsAny(ingredient.toString()))) {
			current -= i;
			// wouldnt set anything if not in db as doesnt meet WHERE
			String query = "UPDATE ingredientsCJB SET stocklevel='" + current + "' WHERE ingredient='"
					+ ingredient.toString() + "';";
			execute(query);
		}
	}

	/**
	 * A function which takes an Ingredient parameter and a Integer parameter
	 * and sets the stock level to be the passed in Integer. If the Integer is
	 * equal or greater than zero.<br>
	 * 
	 * @param stockLevel
	 *            The number you want to set the stock level too.
	 * @param ingredient
	 *            The ingredient you're setting the stock level off.
	 * @author Callum
	 */
	public void setIngredientStockLevel(int stockLevel, Ingredient ingredient) {
		if (stockLevel >= 0 && !(containsAny(ingredient.toString()))) {
			// wouldnt set anything if not in db as doesnt meet WHERE
			String query = "UPDATE ingredientsCJB SET stocklevel='" + stockLevel + "' WHERE ingredient='"
					+ ingredient.toString() + "';";
			execute(query);
		}
	}

	/**
	 * A function which queries the sqlJDBC singleton's current database and
	 * returns the current stock level of the provided Ingredient.<br>
	 * 
	 * @param ingredient
	 *            The Ingredient you wish to get the stock level for.<br>
	 * @return <b>Integer</b><br>
	 *         The current stock level of the provided ingredient.<br>
	 * @author Callum
	 */
	public int getIngredientStockLevel(Ingredient ingredient) {
		if (getAllIngredients().contains(ingredient) && !(containsAny(ingredient.toString()))) {
			// ingredient is in database
			String queryString = "SELECT stocklevel FROM ingredientsCJB WHERE ingredient='" + ingredient.toString()
					+ "';";

			ResultSet ingredientResult = executeSelect(queryString);
			try {
				if (ingredientResult.next()) {
					return Integer.parseInt(ingredientResult.getString(1));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return 0;
	}

	/**
	 * A function that returns all the Ingredient's in an ArrayList that are
	 * contained within the sqlJDBC singleton's current database it is connected
	 * to.<br>
	 * 
	 * @return <b>ArrayList[Ingredient]</b><br>
	 *         All the Ingredients in the sqlJDBC's current database connection.
	 * @author Callum
	 */
	public ArrayList<Ingredient> getAllIngredients() {
		ArrayList<Ingredient> returning = new ArrayList<Ingredient>();

		String ingredientQuery = "SELECT * FROM ingredientsCJB";
		// add ingredient and stock level to stockroom.java
		ResultSet ingredientResult = executeSelect(ingredientQuery);
		try {
			while (ingredientResult.next()) {
				returning.add(Ingredient.toIngredient(ingredientResult.getString(2)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return returning;
	}

	//// MENUITEM FUNCTIONS ////

	/**
	 * A function that returns all the MenuItem's in an ArrayList that are
	 * contained within the sqlJDBC singleton's current database it is connected
	 * to.<br>
	 * 
	 * @return <b>ArrayList[MenuItem]</b><br>
	 *         All the MenuItems in the sqlJDBC's current database connection.
	 * @author Callum
	 */
	public ArrayList<MenuItem> getAllMenuItems() {

		ArrayList<MenuItem> returning = new ArrayList<MenuItem>();

		String menuItemQuery = "SELECT * FROM menuitemsCJB";
		ResultSet menuItemResult = executeSelect(menuItemQuery);

		try {
			while (menuItemResult.next()) {
				returning.add(MenuItem.toMenuItem(menuItemResult.getString(1)));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return returning;
	}

	/**
	 * Takes two MenuItem parameters. The New MenuItem is used to modify the old
	 * and replaces the old's values/data structures.<br>
	 * 
	 * @param oldMenuItem
	 *            Old Ingredient which is being modified by the new.<br>
	 * @param newMenuItem
	 *            New Ingredient which is modifying the old.<br>
	 * @author Callum
	 */
	public void modifyMenuItemInMenuItemsCJB(MenuItem oldMenuItem, MenuItem newMenuItem) {
		removeMenuItemFromMenuItemsCJB(oldMenuItem);
		addMenuItemToMenuItemsCJB(newMenuItem);
	}

	/**
	 * A function which takes a MenuItem parameter and adds it to the
	 * menuitemsCJB table in sqlJDBC singleton's current database connection.
	 * <br>
	 * 
	 * @param menuItem
	 *            The MenuItem you want to add.
	 * @author Callum
	 */
	public void addMenuItemToMenuItemsCJB(MenuItem menuItem) {
		String query = "INSERT INTO menuitemsCJB (menuitem) VALUES ('" + menuItem.toString() + "');";
		execute(query);
	}

	/**
	 * A function which takes a MenuItem parameter and removes it from the
	 * menuitemsCJB table in sqlJDBC singleton's current database and removes
	 * the menuItem from the .<br>
	 * 
	 * @param menuItem
	 *            The MenuItem you want to remove.
	 * @author Callum
	 */
	public void removeMenuItemFromMenuItemsCJB(MenuItem menuItem) {
		String query = "DELETE FROM menuitemsCJB WHERE menuitem='" + menuItem.toString() + "';";
		execute(query);
	}

	//// TABLE FUNCTIONS ////

	/**
	 * Drops the table menuitemsCJB and then re-adds it from the sqlJDBC
	 * singleton's current database AKA, resets it and removes all values.<br>
	 * 
	 * @author Callum
	 */
	public void resetMenuitemsCJB() {
		dropTable("menuitemsCJB");
		try {
			addTable("menuitemsCJB", menuitemsCJBDesc);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Drops the table ingredientsCJB and then re-adds it from the sqlJDBC
	 * singleton's current database AKA, resets it and removes all values.<br>
	 * 
	 * @author Callum
	 */
	public void resetIngredientsCJB() {
		dropTable("ingredientsCJB");
		try {
			addTable("ingredientsCJB", ingredientsCJBDesc);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Drops the table waiterCJB and then re-adds it from the sqlJDBC
	 * singleton's current database AKA, resets it and removes all values.<br>
	 * 
	 * @author Callum
	 */
	public void resetWaiterCJB() {
		dropTable("waiterCJB");
		try {
			addTable("waiterCJB", waiterCJBDesc);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Drops the table customerCJB and then re-adds it from the sqlJDBC
	 * singleton's current database AKA, resets it and removes all values.<br>
	 * 
	 * @author Callum
	 */
	void resetCustomerCJB() {
		dropTable("customerCJB");
		try {
			addTable("customerCJB", customerCJBDesc);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author emil
	 */

	void customerdata() {
		dropTable("customerdata");
		try {
			addTable("customerdata", customerdata);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author emil
	 */

	void staffdata() {
		dropTable("staffdata");
		try {
			addTable("staffdata", staffdata);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Drops the table loginsCJB and then re-adds it from the sqlJDBC
	 * singleton's current database AKA, resets it and removes all values.<br>
	 * 
	 * @author Callum
	 */
	public void resetLoginsCJB() {
		dropTable("loginsCJB");
		try {
			addTable("loginsCJB", loginsCJBDesc);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Drops the table orderCJB and then re-adds it from the sqlJDBC singleton's
	 * current database AKA, resets it and removes all values.<br>
	 * 
	 * @author Callum
	 */
	public void resetOrderCJB() {
		dropTable("orderCJB");
		try {
			addTable("orderCJB", orderCJBDesc);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Drops the table customerWaiterCalls and then re-adds it from the sqlJDBC
	 * singleton's current database AKA, resets it and removes all values.<br>
	 * 
	 * @author Callum
	 */
	public void resetCustomerWaiterCalls() {
		dropTable("customerWaiterCallsCJB");
		try {
			addTable("customerWaiterCallsCJB", customerWaiterCallsCJBDesc);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Drops the table customerWaiterCalls and then re-adds it from the sqlJDBC
	 * singleton's current database AKA, resets it and removes all values.<br>
	 * 
	 * @author Callum
	 */
	public void resetOrderReservationCJB() {
		dropTable("orderReservationCJB");
		try {
			addTable("orderReservationCJB", orderReservationCJBDesc);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Drops the table waiterReadyCJB and then re-adds it from the sqlJDBC
	 * singleton's current database AKA, resets it and removes all values.<br>
	 * 
	 * @author Callum
	 */
	public void resetWaiterReadyCJB() {
		dropTable("waiterReadyCJB");
		try {
			addTable("waiterReadyCJB", waiterReadyCJBDesc);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	//// DATABASE FUNCTIONS ////

	/**
	 * Connection connectToDatabase takes the parameter host, port and database
	 * and loads the postgresql.Driver. It will print the user interactive
	 * notifications when connection is made or print corresponding messages if
	 * any type of exceptions arise.
	 * 
	 * @param host
	 *            name of the host
	 * @param port
	 *            port of the host
	 * @param database
	 *            name of the database
	 * @return returns connection through which we can interact with SQL
	 */
	public Connection connectToDatabase(String host, String port, String database, String username, String password) {

		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Where is your PostgreSQL JDBC Driver? Include in your library path!");
			e.printStackTrace();
		}
		Connection connection = null;
		try {
			Properties connectionProps = new Properties();
			// TODO
			connectionProps.put("user", username);
			connectionProps.put("password", password);
			connection = DriverManager.getConnection("jdbc:postgresql://" + host + ":" + port + "/" + database,
					connectionProps);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}

	/**
	 * dropTable takes the parameters: connection and tableName. It executes
	 * method of postgreSQL to drop the table.
	 * 
	 * @param connection
	 *            connection that was established with the database on the host
	 * @param tableName
	 *            name of the table that will be deleted
	 */
	public void dropTable(String tableName) {
		Statement st = null;
		try {
			st = connection.createStatement();
			st.execute("DROP TABLE " + tableName);
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * createTable takes the parameters: connection, tableName and
	 * tableDescription. It executes postgreSQL statement to create a new table
	 * with the provided tableName and tableDescription.
	 * 
	 * @param connection
	 *            connection that was established with the database on the host
	 * @param tableName
	 *            name of the table that will be created
	 * @param tableDescription
	 *            description of the table that will be created
	 */
	public void createTable(String tableName, String tableDescription) {
		Statement st = null;
		try {
			st = connection.createStatement();
			st.execute("CREATE TABLE " + tableName + "(" + tableDescription + " ); ");
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * addTable takes the parameters: connection, tableName and
	 * tableDescription. If specified table is not already in the database it
	 * will be created. If the specified table is present in the database, it
	 * will drop the table and creates a new one.
	 * 
	 * @param connection
	 *            connection that was established with the database on the host
	 * @param tableName
	 *            name of the table that will be created or deleted and created
	 *            again
	 * @param tableDescription
	 *            description of the table
	 * @throws SQLException
	 *             sql exception is thrown if the connection does not exist or
	 *             description provided is wrong or etc.
	 */
	public void addTable(String tableName, String tableDescription) throws SQLException {
		// connection is of type connection in JDBC
		DatabaseMetaData dbm = connection.getMetaData();

		// Check if the table is there
		ResultSet tables = dbm.getTables(null, null, tableName, null);
		if (tables.next() == true) {
			// The table exist
			System.out.println(tableName + " already exists.");
			dropTable(tableName);
			System.out.println("Dropping the old table");
			createTable(tableName, tableDescription);
			System.out.println("creating new one");
		} else {
			// table doesn't exist
			System.out.println("No tables exist prior in database. Creating new table");
			createTable(tableName, tableDescription);
		}
	}

	/**
	 * insertTableFromFile takes the parameters: connection, table and file. It
	 * uses BufferedReader to read the file and enter every line in the table in
	 * corresponding columns.
	 * 
	 * @param connection
	 *            connection that was established with the database on the host
	 * @param table
	 *            name of the table where the lines from file will be inserted
	 * @param file
	 *            name of the file from which lines will be inserted in the
	 *            table
	 * @return returns a value corresponding to number of rows that have been
	 *         inserted.
	 */
	public int insertIntoTableFromFile(String table, String file) throws FileNotFoundException {
		BufferedReader br = null;
		int numRows = 0;
		try {
			Statement st = connection.createStatement();
			/**
			 * sCurrentLine is one line in the file that is read through buffer
			 */
			String sCurrentLine;
			/** brokenLine is an array that holds each attribute of the table */
			String brokenLine[];
			/**
			 * composedLine combines each attribute of brokenLine array and
			 * inserts the new row in the table
			 */
			String composedLine = "";
			br = new BufferedReader(new FileReader(file));
			while ((sCurrentLine = br.readLine()) != null) {
				/**
				 * each element that was split by \t(tab) is held in brokenLine.
				 * \t is a delimiter that notes each attribute of the row
				 */
				brokenLine = sCurrentLine.split("\t");
				// compose each line to insert in the DB
				composedLine = "INSERT INTO " + table + " VALUES (";
				int i;
				for (i = 0; i < brokenLine.length - 1; i++) {
					composedLine += "'" + brokenLine[i] + "',";
				}
				composedLine += "'" + brokenLine[i] + "')";
				// Insert each line to the DB
				numRows = st.executeUpdate(composedLine);
				System.out.println(composedLine);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return numRows;
	}

	/**
	 * Takes the query and connection as parameters. Executes the query and
	 * stores it in ResultSet, which is returned.
	 * 
	 * @param connection
	 *            connection that was established with the database on the host
	 * @param query
	 *            query that will be executed
	 * @return returns a ResultSet of the query
	 */
	public ResultSet executeSelect(String query) {
		Statement st = null;
		try {
			st = connection.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}

		ResultSet rs = null;
		try {
			rs = st.executeQuery(query);
			// st.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return rs;
	}

	/**
	 * TODO
	 * 
	 * @param query
	 */
	public void execute(String query) {
		Statement st = null;
		try {
			st = connection.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			st.executeUpdate(query);
			// st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Takes the ResultSet as a parameter. It prints the results of the
	 * ResultSet.
	 * 
	 * @param rs
	 *            ResultSet that has been passed.
	 * @throws SQLException
	 *             throws sql exception
	 */
	public static void printResult(ResultSet rs) throws SQLException {
		try {
			while (rs.next()) {
				for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
					String columnValue = rs.getString(i);
					if (columnValue != null) {
						System.out.print(columnValue);
					}
					System.out.print("\t");
				}
				System.out.print("\n");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author emil TODO
	 */
	public ObservableList<ManagerViewUserDataTable> displayUserDataTable() {
		ObservableList<ManagerViewUserDataTable> data = FXCollections.observableArrayList();

		String query = "SELECT * FROM customerdata;";

		ResultSet rs = executeSelect(query);
		try {
			while (rs.next()) {
				data.add(new ManagerViewUserDataTable(rs.getString(1), rs.getString(2), rs.getString(3)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return data;
	}

	/**
	 * TODO
	 * 
	 * @author emil
	 */
	public ObservableList<ManagerViewEmployeeDataTable> displayEmployeeDataTable() {
		ObservableList<ManagerViewEmployeeDataTable> data = FXCollections.observableArrayList();

		String query = "SELECT * FROM staffdata;";

		ResultSet rs = executeSelect(query);
		try {
			while (rs.next()) {
				data.add(new ManagerViewEmployeeDataTable(rs.getString(1), rs.getString(2), rs.getString(3),
						rs.getString(4)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return data;
	}
}
