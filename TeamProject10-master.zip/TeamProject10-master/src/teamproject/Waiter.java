package teamproject;

import java.util.ArrayList;

public class Waiter {
  private String username;
  private int id;
  private ArrayList<Integer> assignedTables;
  private int extraSales;

  public Waiter(String username, int id, ArrayList<Integer> assignedTables, int extraSales) {
    this.username = username;
    this.id = id;
    this.assignedTables = assignedTables;
    this.extraSales = extraSales;
  }

  public String getUsername() {
    return username;
  }

  public int getID() {
    return id;
  }

  public ArrayList<Integer> getAssignedTables() {
    return assignedTables;
  }
  
  public int getExtraSales() {
    return extraSales;
  }
 
  public void addTable(int table) {
    getAssignedTables().add(table);
  }
  
  public void removeTable(int table) {
    getAssignedTables().remove(new Integer(table));
  }
}
