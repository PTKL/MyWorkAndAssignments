package teamproject;

import java.sql.SQLException;
import java.util.ArrayList;

import javafx.animation.PauseTransition;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.util.Duration;

public class WaiterHomeViewController {

  static ArrayList<Integer> assignedTables = new ArrayList<>();
  static String waiterName;
  static Waiter waiter;

  void initialize() throws SQLException {
    waiter = getWaiter();
    assignTables(assignedTables);
    Alert a = new Alert(AlertType.INFORMATION);
    a.setTitle("Table Assignment!");
    a.setHeaderText(null);
    a.setContentText("You have been assigned to tables " + getAssignedTables());
    a.showAndWait();
  }

  public void waiterOrderBtnController() {
    ViewManager.getInstance().showWaiterOrder();
  }

  public void waiterTablesBtnController() {
    ViewManager.getInstance().showWaiterTable();
  }

  public void waiterPaymentBtnController() {
    ViewManager.getInstance().showWaiterPay();
  }

  public void logoutController() {
    ViewManager.getInstance().showLoginScreen();
  }

  /**
   * assignTables.
   * 
   * @param tables
   *          adds a list of tableNumbers that the waiter is assigned to
   */
  public void assignTables(ArrayList<Integer> tables) {
    assignedTables = waiter.getAssignedTables();
  }

  /**
   * getAssignedTables.
   * 
   * @return an ArrayList of Integer of the assigned tables to the waiter
   */
  public static ArrayList<Integer> getAssignedTables() {
    try {
      assignedTables = Model.getModel().getDatabase().getWaiter(waiterName).getAssignedTables();

    } catch (SQLException e) {
      e.printStackTrace();
    }
    return assignedTables;
  }
  
  public String getWaiterName() {
    return waiterName;
  }
  
  public Waiter getWaiter() throws SQLException {
    Waiter retWaiter = Model.getModel().getDatabase().getWaiter(getWaiterName());
    return retWaiter;
  }
  
}
