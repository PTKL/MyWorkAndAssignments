package teamproject;

import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class MenuViewController implements Initializable {

	@FXML
	private ListView<String> mainList = new ListView<String>();
	ObservableList<String> mainItems;

	@FXML
	private ListView<String> sideList = new ListView<String>();
	ObservableList<String> sideItems;

	@FXML
	private ListView<String> dessertList = new ListView<String>();
	ObservableList<String> dessertItems;

	@FXML
	private ListView<String> drinkList = new ListView<String>();
	ObservableList<String> drinkItems;

	@FXML
	private ListView<String> orderList = new ListView<String>();
	ObservableList<String> orderItems;

	@FXML
	private AnchorPane menuAnchor;

	@FXML
	private Button backBtn;

	@FXML
	private TextArea descBox;

	@FXML
	private Text descText;

	@FXML
	private Text allergyText;

	@FXML
	private Text caloriesText;

	@FXML
	private Text priceText;

	@FXML
	private Text totalPriceText;

	@FXML
	private ImageView image;

	@FXML
	private CheckBox eggCheck;

	@FXML
	private CheckBox nutCheck;

	@FXML
	private CheckBox vegetarianCheck;

	ArrayList<MenuItem> allMenuItemsArray;

	NumberFormat formatter = new DecimalFormat("#0.00");

	Stage stage;

	MenuItem selectedItem;

	Order o;

	public static Order changeOrder;

	public void initialize() {
		stage = (Stage) menuAnchor.getScene().getWindow();
		stage.setHeight(625);
		stage.setWidth(810);

		allMenuItemsArray = Model.getModel().getDatabase().getAllMenuItems();
		orderItems = FXCollections.observableArrayList();
		if (changeOrder == null) {
			MenuItem[] m = new MenuItem[0];
			o = new Order(m, CustomerHomeViewController.tableNumber, CustomerHomeViewController.customer);
		} else {
			o = changeOrder;
			for (MenuItem m : o.getMenuItems()) {
				orderItems.add(m.getName());
			}
			orderList.setItems(orderItems);
			totalPriceText.setText("Total: �" + String.valueOf(formatter.format(getTotalPrice())));
		}

		setupMenu();

		// check menu ingredients every 2 secs
		Timer timer = new Timer();
		timer.schedule(new TimerTask() {
		@Override
		    public void run() {
		    Platform.runLater(new Runnable() {
		       public void run() {
		          stockCheck();
		      }
		    });
		}
		}, 3*1000);
	}

	boolean menuFiltered;
	ArrayList<Allergy> doesntHave;
	ArrayList<Category> has;

	public void stockCheck() {
		if (menuFiltered) {
			setupMenu(doesntHave, has);
		} else {
			setupMenu();
		}
	}

	/**
	 * populate the menu tabs , doesnt filter any menuitems
	 */
	public void setupMenu() {
		mainList.setEditable(true);
		sideList.setEditable(true);
		dessertList.setEditable(true);
		drinkList.setEditable(true);
		mainItems = FXCollections.observableArrayList();
		sideItems = FXCollections.observableArrayList();
		dessertItems = FXCollections.observableArrayList();
		drinkItems = FXCollections.observableArrayList();

		for (MenuItem item : allMenuItemsArray) {
			if (StockRoom.getInstance().haveIngredients(item)) {
				if (item.getCatergories() != null) {
					if (item.is(Category.Main)) {
						mainItems.add(item.getName());
					}

					if (item.is(Category.Starter)) {
						sideItems.add(item.getName());
					}

					if (item.is(Category.Dessert)) {
						dessertItems.add(item.getName());
					}

					if (item.is(Category.Drink)) {
						drinkItems.add(item.getName());
					}
				}
			}
		}

		mainList.setItems(mainItems);
		sideList.setItems(sideItems);
		dessertList.setItems(dessertItems);
		drinkList.setItems(drinkItems);

		menuFiltered = false;
	}

	/**
	 * populate the menu tabs, filters it to be from the the specficed
	 * Category[] and NOT from the Allergy[]
	 */
	public void setupMenu(ArrayList<Allergy> doesntHave, ArrayList<Category> has) {
		mainList.setEditable(true);
		sideList.setEditable(true);
		dessertList.setEditable(true);
		drinkList.setEditable(true);
		mainItems = FXCollections.observableArrayList();
		sideItems = FXCollections.observableArrayList();
		dessertItems = FXCollections.observableArrayList();
		drinkItems = FXCollections.observableArrayList();

		boolean isCatergory = true;
		boolean doesntHaveAllergy = true;
		for (MenuItem item : allMenuItemsArray) {
			if (StockRoom.getInstance().haveIngredients(item)) {
				int index = 0;
				while (index < has.size() && isCatergory) {
					if (!item.is(has.get(index))) {
						isCatergory = false;
					}
					index++;
				}

				index = 0;
				HashSet<Allergy> itemsAllergys = new HashSet<Allergy>();
				for (Ingredient i : item.getIngredients()) {
					for (Allergy a : i.getAllergies()) {
						itemsAllergys.add(a);
					}
				}

				while (index < doesntHave.size() && isCatergory && doesntHaveAllergy) {
					for (Allergy a : itemsAllergys) {
						if (a.equals(doesntHave.get(index))) {
							doesntHaveAllergy = false;
						}
					}
					index++;
				}

				if (isCatergory && doesntHaveAllergy) {
					if (item.getCatergories() != null) {
						if (item.is(Category.Main)) {
							mainItems.add(item.getName());
						}

						if (item.is(Category.Starter)) {
							sideItems.add(item.getName());
						}

						if (item.is(Category.Dessert)) {
							dessertItems.add(item.getName());
						}

						if (item.is(Category.Drink)) {
							drinkItems.add(item.getName());
						}
					}
				}
			}
		}

		mainList.setItems(mainItems);
		sideList.setItems(sideItems);
		dessertList.setItems(dessertItems);
		drinkList.setItems(drinkItems);

		menuFiltered = true;
		this.doesntHave = doesntHave;
		this.has = has;
	}

	public void mainController() {
		if (mainList.getSelectionModel().getSelectedIndex() != -1) {
			double price = 0;
			String targetItem = mainList.getSelectionModel().getSelectedItem();
			selectedItem = getItemByName(targetItem);

			Image foodImage = new Image(selectedItem.getImageURL());
			image.setImage(foodImage);
			image.setCache(true);

			setDesc(selectedItem);

			price = selectedItem.getPrice();
			priceText.setText("�" + String.valueOf(formatter.format(price)));
		} else {
			selectedItem = null;

			Image foodImage = new Image("http://i.stack.imgur.com/0BYg1.png");

			descText.setText("");
			allergyText.setText("");
			caloriesText.setText("");

			double price = 0;
			priceText.setText("�" + String.valueOf(formatter.format(price)));
		}
	}

	public void sideController() {
		if (sideList.getSelectionModel().getSelectedIndex() != -1) {
			double price = 0;
			String targetItem = sideList.getSelectionModel().getSelectedItem();

			selectedItem = getItemByName(targetItem);

			Image foodImage = new Image(selectedItem.getImageURL());
			image.setImage(foodImage);
			image.setCache(true);

			setDesc(selectedItem);

			price = selectedItem.getPrice();
			priceText.setText("�" + String.valueOf(formatter.format(price)));
		} else {
			selectedItem = null;

			Image foodImage = new Image("http://i.stack.imgur.com/0BYg1.png");

			descText.setText("");
			allergyText.setText("");
			caloriesText.setText("");

			double price = 0;
			priceText.setText("�" + String.valueOf(formatter.format(price)));
		}
	}

	public void dessertController() {
		if (dessertList.getSelectionModel().getSelectedIndex() != -1) {
			double price = 0;
			String targetItem = dessertList.getSelectionModel().getSelectedItem();

			selectedItem = getItemByName(targetItem);

			Image foodImage = new Image(selectedItem.getImageURL());
			image.setImage(foodImage);
			image.setCache(true);

			setDesc(selectedItem);

			price = selectedItem.getPrice();
			priceText.setText("�" + String.valueOf(formatter.format(price)));
		} else {
			selectedItem = null;

			Image foodImage = new Image("http://i.stack.imgur.com/0BYg1.png");

			descText.setText("");
			allergyText.setText("");
			caloriesText.setText("");

			double price = 0;
			priceText.setText("�" + String.valueOf(formatter.format(price)));
		}
	}

	public void drinkController() {
		if (drinkList.getSelectionModel().getSelectedIndex() != -1) {
			double price = 0;
			String targetItem = drinkList.getSelectionModel().getSelectedItem();

			selectedItem = getItemByName(targetItem);

			Image foodImage = new Image(selectedItem.getImageURL());
			image.setImage(foodImage);
			image.setCache(true);

			setDesc(selectedItem);

			price = selectedItem.getPrice();
			priceText.setText("�" + String.valueOf(formatter.format(price)));
		} else {
			selectedItem = null;

			Image foodImage = new Image("http://i.stack.imgur.com/0BYg1.png");

			descText.setText("");
			allergyText.setText("");
			caloriesText.setText("");

			double price = 0;
			priceText.setText("�" + String.valueOf(formatter.format(price)));
		}
	}

	public void orderController() {
		if (orderList.getSelectionModel().getSelectedIndex() != -1) {
			double price = 0;
			String targetItem = orderList.getSelectionModel().getSelectedItem();

			selectedItem = getItemByName(targetItem);

			Image foodImage = new Image(selectedItem.getImageURL());
			image.setImage(foodImage);
			image.setCache(true);

			setDesc(selectedItem);

			price = selectedItem.getPrice();
			priceText.setText("�" + String.valueOf(formatter.format(price)));
		} else {
			selectedItem = null;

			Image foodImage = new Image("http://i.stack.imgur.com/0BYg1.png");

			descText.setText("");
			allergyText.setText("");
			caloriesText.setText("");

			double price = 0;
			priceText.setText("�" + String.valueOf(formatter.format(price)));
		}
	}

	public void addToOrderBtnController() {
		if (selectedItem != null && StockRoom.getInstance().haveIngredients(selectedItem)) {
			// unreserve ingredient
			if (o.getMenuItems().length != 0) {
				StockRoom.getInstance().update();
				StockRoom.getInstance().unreserveIngredients(o);
				Model.getModel().getDatabase().removeOrderFromOrderReservationCJB(o);
			}

			orderItems.add(selectedItem.getName());
			o.addMenuItem(selectedItem);
			StockRoom.getInstance().reserveIngredients(o);
			Model.getModel().getDatabase().addOrderToOrderReservationCJB(o);
			StockRoom.getInstance().update();

			orderList.setItems(orderItems);

			totalPriceText.setText("Total: �" + String.valueOf(formatter.format(getTotalPrice())));
		}
	}

	public void removeFromOrderBtnController() {
		if (selectedItem != null) {
			StockRoom.getInstance().update();
			StockRoom.getInstance().unreserveIngredients(o);
			Model.getModel().getDatabase().removeOrderFromOrderReservationCJB(o);
			orderItems.remove(selectedItem.getName());
			o.removeMenuItem(selectedItem);
			if (o.getMenuItems().length != 0) {
				StockRoom.getInstance().reserveIngredients(o);
				Model.getModel().getDatabase().addOrderToOrderReservationCJB(o);
			}
			StockRoom.getInstance().update();

			orderList.setItems(orderItems);

			totalPriceText.setText("Total: �" + String.valueOf(formatter.format(getTotalPrice())));
		}
	}

	public void orderBtnController() {
		if (o.getMenuItems().length > 0) {
			Model.getModel().getDatabase().addOrderToOrderCJB(o);

			Alert a = new Alert(AlertType.INFORMATION);
			a.setTitle("ORDERED!");
			a.setHeaderText(null);
			a.setContentText("Order waiting to be confirmed!");
			a.showAndWait();

			ViewManager.getInstance().showCustomerHome();
		} else {
			Alert a = new Alert(AlertType.INFORMATION);
			a.setTitle("Add some MenuItems!");
			a.setHeaderText(null);
			a.setContentText("You can't order nothing!");
			a.showAndWait();
		}
	}

	public void backBtnController() {
		if (o.getMenuItems().length > 0) {
			StockRoom.getInstance().update();
			StockRoom.getInstance().unreserveIngredients(o);
			Model.getModel().getDatabase().removeOrderFromOrderReservationCJB(o);
		}

		ViewManager.getInstance().showCustomerHome();
	}

	public void filterMenu() {
		ArrayList<Category> cat = new ArrayList<Category>();
		ArrayList<Allergy> alg = new ArrayList<Allergy>();

		if (eggCheck.isSelected()) {
			alg.add(Allergy.Egg);
		}

		if (nutCheck.isSelected()) {
			alg.add(Allergy.Nut);
		}

		if (vegetarianCheck.isSelected()) {
			cat.add(Category.Vegetarian);
		}

		setupMenu(alg, cat);
	}

	public double getTotalPrice() {
		double total = 0;

		for (MenuItem m : o.getMenuItems()) {
			total += m.getPrice();
		}
		return total;
	}

	public void setDesc(MenuItem item) {
		String desc = "Ingredients: \n";
		String allergies = "";
		String calories = "Calories: " + String.valueOf(item.getCalories());
		for (Ingredient ing : item.getIngredients()) {
			desc += ing.getName() + "\n";
			if (ing.hasAllergies()) {
				allergies = "CONTAINS : \n";
				for (Allergy allergy : ing.getAllergies()) {
					allergies += allergy.toString() + "\n";
				}
			}
		}
		descText.setText(desc);
		allergyText.setText(allergies);
		caloriesText.setText(calories);
	}

	public MenuItem getItemByName(String itemName) {
		MenuItem item = null;

		for (MenuItem m : allMenuItemsArray) {
			if (itemName.equals(m.getName())) {
				item = m;
			}
		}
		return item;
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub

	}
}
