package teamproject;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Run extends Application {
  /**
   * calls the getController method of Controller class to start execution of the program.
   * 
   * @throws SQLException
   * @throws FileNotFoundException
   */
  public static void main(String[] args) throws SQLException {
    // setup model
    Model.getModel();

    // setup Stock Room
    StockRoom.getInstance();

    // setup viewManager
    ViewManager.getInstance();

    // show login screen, its controller takes over now
    launch(args);
  }

  @Override
  public void start(Stage stage) throws IOException {
    Scene scene = new Scene(new StackPane());

    ViewManager.getInstance().setScene(scene);
    ViewManager.getInstance().showLoginScreen();

    stage.setScene(scene);
    stage.show();
  }
}
