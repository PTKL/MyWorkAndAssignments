package teamproject;

/**
 * A Category class is used as a attribute of an MenuItem class instance. To hold the dishes
 * Category information. Dishes can have multiple categories. Which in the menu is used to filter
 * which menuItems to display, depending on what the customer has specified to filter by. <br>
 * 
 * @author Callum
 */
public enum Category {
  Starter, Main, Dessert, Drink, Alcohol, Vegetarian;

  /**
   * Returns a debug string for the current Enum instance. Which representatives the value the Enum
   * holds. Passing this debug string to Category.toCategory(debugString) will return an Enum from
   * which this debug string was created and has the corresponds values off. <br>
   * <br>
   * <b>Therefore:</b><br>
   * Category.test1 == Category.toCategory(Category.test1.toString()) <br>
   * 
   * @return <b>String</b><br>
   *         A debug string, representative of the enum value.<br>
   * @author Callum
   */
  public String toString() {
    if (this.equals(Category.Starter)) {
      return "Starter";
    } else if (this.equals(Category.Main)) {
      return "Main";
    } else if (this.equals(Category.Dessert)) {
      return "Dessert";
    } else if (this.equals(Category.Drink)) {
      return "Drink";
    } else if (this.equals(Category.Alcohol)) {
      return "Alcohol";
    } else if (this.equals(Category.Vegetarian)) {
      return "Vegetarian";
    }

    return null;// will only ever be "" if we forget to add an enum to the elif's
  }

  /**
   * Is a function which takes a Category array and compiles a debug string containing the debug
   * string of each element in the array. It will begin the debug String with 'Categories{' and end
   * it with '}'. Each debug String of each Category will be separated by a colon. <br>
   * <br>
   * <b>Therefore:</b><br>
   * Category[] cat = {Category.test1,Category.test2,Category.test3};<br>
   * cat == Category.toCategoryArray(Category.toString(cat));<br>
   * 
   * @param Category
   *          [] <br>
   *          The Category Array you wish to compile a debug String for.
   * @return <b>String</b><br>
   *         A debug String, containing debug info for each Category in the array. <br>
   *         <b>format:</b>Categories{debugString,debugString....}
   * @author Callum
   */
  public static String toString(Category[] CategoryArrayToString) {
    if (CategoryArrayToString != null) {
      String returning = "Categories{";
      for (int i = 0; i < CategoryArrayToString.length; i++) {
        if (i != (CategoryArrayToString.length - 1)) {
          returning += CategoryArrayToString[i].toString() + ",";
        } else {
          returning += CategoryArrayToString[i].toString();
        }
      }
      return (returning + "}");
    }

    return null;
  }

  /**
   * Is a function which takes a String and converts the debug string back into the Category; the
   * debug string was created from. If the debug string can't be parsed back into a Category then it
   * will return null. <br>
   * <br>
   * <b>Therefore:</b><br>
   * Category.test1 == Category.toCategory(Category.test1.toString())<br>
   * 
   * @param String
   *          <br>
   *          Category debug string you wish to convert back to an Category Enum.
   * @return <b>Category</b><br>
   *         Returns an Category Enum, which corresponds to the debug String. If one isn't found;
   *         returns null.
   * @author Callum
   */
  public static Category toCategory(String stringToCategory) {
    if (stringToCategory == null) {
      return null;
    }

    if (stringToCategory.equals("Starter")) {
      return Category.Starter;
    } else if (stringToCategory.equals("Main")) {
      return Category.Main;
    } else if (stringToCategory.equals("Dessert")) {
      return Category.Dessert;
    } else if (stringToCategory.equals("Drink")) {
      return Category.Drink;
    } else if (stringToCategory.equals("Alcohol")) {
      return Category.Alcohol;
    } else if (stringToCategory.equals("Vegetarian")) {
      return Category.Vegetarian;
    }

    return null;
  }

  /**
   * Is a function which takes a String and converts the debug string, back into the Category Array
   * the debug string was created from. Will return null if it can't be parsed. Returned Arrays may
   * have elements which are null.<br>
   * <br>
   * <b>Therefore:</b><br>
   * Category[] cat = {Category.test1,Category.test2,Category.test3};<br>
   * cat == Category.toCategoryArray(Category.toString(alg));<br>
   * 
   * @param String
   *          <br>
   *          Category Array debug string you wish to convert back to a Category array.
   * @return <b>Category[]</b><br>
   *         Returns an Category Array which corresponds to the debug String input.
   * @author Callum
   */
  public static Category[] toCategoryArray(String stringToCategoryArray) {
    if (stringToCategoryArray == null) {
      return null;
    }

    if (stringToCategoryArray.length() < 12) {
      return null;
    } // wouldnt be able to sub first 11 and last 1

    if (!(stringToCategoryArray.startsWith("Categories{"))) {
      return null;
    } // isnt an Category[] toString as doesnt start with 'Categories{'

    stringToCategoryArray = stringToCategoryArray.substring(11);
    stringToCategoryArray = stringToCategoryArray.substring(0, stringToCategoryArray.length() - 1);

    String[] splitString = stringToCategoryArray.split(",");
    Category[] returning = new Category[splitString.length];

    int pos = 0;
    for (int i = 0; i < splitString.length; i++) {
      Category temp = Category.toCategory(splitString[i]);
      if (temp == null || temp.equals("")) {
      } else {
        returning[pos] = temp;
        pos++;
      }

    }

    return (resizeArray(returning, pos));
  }

  /**
   * A function which takes an array and resizes it to a smaller size. With the array you wish to
   * resized values.
   * 
   * @param resizing
   *          The array to resize to a smaller size.
   * @param to
   *          Size to resize the array to, should be smaller than resizing.length()
   * @return <b>Allergy[]</b> Resized array.
   * @Author Callum
   */
  public static Category[] resizeArray(Category[] resizing, int to) {
    if (to > resizing.length) {
      // incorrect usage
      return null;
    } else {
      Category returning[] = new Category[to];

      for (int i = 0; i < to; i++) {
        returning[i] = resizing[i];
      }

      return returning;
    }
  }
}
