package teamproject;

import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class EmailClient {
  String to;
  String from;
  String subject;
  String htmlbody;

  public EmailClient(String from, String to, String subject, String htmlbody) {
    this.to = to;
    this.from = from;
    this.subject = subject;
    this.htmlbody = htmlbody;
  }
  
  public void setTo(String to){
    this.to = to;
  }

  public String setHtmlBody(String context) {

    htmlbody = "<h1>Caffe Mccrea</h1><p>Hello there, We are back with our delicious dishes and Special offers for this month</p><ul>"
        + context
        + "</ul> <p>We are open 10am-10pm on weekdays and 12am-9pm on weekends. Visit us soon. Have a good day! </p><p>Thank you, Manager </p>";
    return htmlbody;

  }

  public static String getString(String[] s) {
    String returning = "";
    String[] arrayOfString = s;
    int j = s.length;

    for (int i = 0; i < j; i++) {
      String s2 = arrayOfString[i];
      returning = returning + s2;
    }
    return returning;
  }

  public boolean sendEmail() {
    String from = this.from;
    String to = this.to;
    String host = "localhost";
    java.util.Properties properties = System.getProperties();
    properties.setProperty("mail.smtp.gmail.com", host);
    Session session = Session.getDefaultInstance(properties);
    try {
      MimeMessage message = new MimeMessage(session);
      message.setFrom(new InternetAddress(from));

      message.setRecipient(RecipientType.TO, new InternetAddress(to));

      message.setSubject(this.subject);

      message.setContent(this.htmlbody, "text/html");

      javax.mail.Transport.send(message);

    } catch (javax.mail.MessagingException mex) {
      mex.printStackTrace();
    }
    return false;
  }
}
