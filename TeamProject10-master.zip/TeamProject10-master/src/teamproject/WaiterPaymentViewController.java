package teamproject;

import java.sql.SQLException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.text.Text;
/**
 * 
 * @author seong
 *
 */
public class WaiterPaymentViewController {

  @FXML
  private TabPane tabPane;

  @FXML
  private Text paidText;

  @FXML
  private Text notPaidText;

  ArrayList<Integer> assignedTables = new ArrayList<>();
  ArrayList<Order> orderList = new ArrayList<>();

  @FXML
  void initialize() {
    orderList = getOrderList();
    assignedTables = WaiterHomeViewController.getAssignedTables();
    setup();
  }

  /**
   * controller for the refresh button. This will set the orderList and
   * assignedTables and run setup()
   */
  public void refreshBtnController() {
    orderList = getOrderList();
    assignedTables = WaiterHomeViewController.getAssignedTables();
    setup();
  }

  public void backController() throws SQLException {
    ViewManager.getInstance().showWaiterHome();
  }
  /**
   * setup for the view.
   * adds tabs for all the assigned tables
   */
  private void setup() {
    Tab tab;
    tabPane.getTabs().clear();
    for (int t : assignedTables) {
      tab = createTableTab(t);
      tabPane.getTabs().add(tab);
    }
  }

  /**
   * tabExists.
   * 
   * @param tableNo
   *          the table number that you would like to check if tab exists for.
   * @return returns if the tab exists
   */
  private boolean tabExists(int tableNo) {
    boolean check = false;
    for (Tab t : tabPane.getTabs()) {
      if (t.getText().equals("Table " + tableNo)) {
        check = true;
      }
    }
    return check;
  }

  /**
   * createTableTab. creates a tab with the tablenumber and the orders for it
   * 
   * @param tableNo
   *          tablenumber you wish to make a tab for.
   * @return returns the tab with tablenumber and list of orders
   */
  private Tab createTableTab(int tableNo) {
    String name = "Table " + tableNo;
    Tab tableTab = new Tab(name);
    ListView<String> orderInfo = new ListView<>();
    ObservableList<String> orderObsList = FXCollections.observableArrayList();
    for (Order o : orderList) {
      if (o.getTableNumber() == tableNo) {
        orderObsList.add(String.valueOf(o.getOrderID()));
      }
    }

    orderInfo.setOnMouseClicked(new EventHandler<Event>() {
      @Override
      public void handle(Event t) {
        String selectedName = orderInfo.getSelectionModel().getSelectedItem();
        Order selectedOrder = getOrderByName(selectedName);
        if (selectedOrder.getPaid()) {
          paidText.setText("Paid!");
          notPaidText.setText("");
        } else {
          paidText.setText("");
          notPaidText.setText("Not Paid!");
        }
      }

    });

    tableTab.setContent(orderInfo);
    orderInfo.setItems(orderObsList);

    return tableTab;
  }

  /**
   * getTabByTableNo.
   * 
   * @param tableNo
   *          Table number you would like to get the tab for.
   * @return returns the tab with the int table number
   */
  public Tab getTabByTableNo(int tableNo) {
    Tab tab = new Tab();
    for (Tab t : tabPane.getTabs()) {
      if (t.getText().equals("Table " + tableNo)) {
        tab = t;
      }
    }
    return tab;
  }

  public boolean assignedTables(int tNo) {
    return assignedTables.contains(tNo);
  }

  private Order getOrderByName(String selectedName) {
    int orderId = Integer.parseInt(selectedName);
    Order retOrder = null;
    for (Order o : orderList) {
      if (orderId == o.getOrderID()) {
        retOrder = o;
      }
    }
    return retOrder;
  }

  /**
   * getOrderList from database
   * 
   * @return an arraylist of orders from the database
   */
  private ArrayList<Order> getOrderList() {
    ArrayList<Order> retList = new ArrayList<>();
    for (Order o : Model.getModel().getDatabase().getAllOrders()) {
      if (assignedTables(o.getTableNumber())) {
        retList.add(o);
      }
    }
    return retList;
  }
}
