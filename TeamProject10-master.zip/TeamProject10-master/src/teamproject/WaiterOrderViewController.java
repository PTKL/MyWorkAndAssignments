package teamproject;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.text.Text;
import javafx.util.Duration;
/**
 * 
 * @author seong
 *
 */
public class WaiterOrderViewController {

  @FXML
  private TabPane tabPane;

  @FXML
  private Text orderStatusText;
  @FXML
  private Text tableNo;

  @FXML
  private Text waiterBonus;

  // displays sales for the waiter.
  private int mySales = 0;

  ArrayList<Order> orderList = new ArrayList<>();
  ArrayList<Integer> assignedTables = new ArrayList<>();

  @FXML
  void initialize() {
    orderList = getOrderList();
    assignedTables = WaiterHomeViewController.getAssignedTables();
    setupOrders();
    mySales = AddMenuItemToOrderWaiterController.getTotalSales();
    waiterBonus.setText("    Your bonus is: " + mySales);
  }

  /**
   * setup view. create tab of orders list of orders contents in each tab
   */
  public void setupOrders() {
    Tab tab;
    tabPane.getTabs().clear();
    for (Order o : orderList) {
      //TODO
      if(assignedTables.contains(o.getTableNumber()) && !o.getOrderStatus().equals(OrderStatus.delivered)){
        tab = createOrderTab(o);
        tabPane.getTabs().add(tab);
      }
    }
  }

  public void addMenuItemBtnController() {
    if ((orderList.size()) < 1) {
      Alert alert = new Alert(AlertType.INFORMATION);
      alert.setTitle("No Orders");
      alert.setHeaderText(null);
      alert.setContentText("There are no orders to Modify!");
      alert.showAndWait();
    } else {
      int index = tabPane.getSelectionModel().getSelectedIndex();
      Order ord = orderList.get(index);
      AddMenuItemToOrderWaiterController.changeOrderWaiter = ord;
      Model.getModel().getDatabase().removeOrderFromOrderCJB(ord);
      ViewManager.getInstance().showAddMenuItemToOrder();
    }

  }
  /**
   * controller for confirm Order button will change orderstatus of the selected
   * order from ordering to ordered
   */
  public void confirmOrderBtnController() {
    int index = tabPane.getSelectionModel().getSelectedIndex();

    if (index > -1) {
      Order o = orderList.get(index);
      confirmOrder(o);
      ViewManager.getInstance().showWaiterOrder();
    } else {
      Alert alert = new Alert(AlertType.ERROR);
      alert.setTitle("Select an order!");
      alert.setHeaderText(null);
      alert.setContentText("Select an order you wish to confirm!");
      alert.showAndWait();
    }
  }

  /**
   * controller for the order delivered button. will change orderstatus of the
   * selected order from reday to delivered
   */
  public void orderDeliveredBtnController() {
    int index = tabPane.getSelectionModel().getSelectedIndex();

    if (index > -1) {
      Order o = orderList.get(index);
      deliverOrder(o);
      ViewManager.getInstance().showWaiterOrder();
    } else {
      Alert alert = new Alert(AlertType.ERROR);
      alert.setTitle("Select an order!");
      alert.setHeaderText(null);
      alert.setContentText("Select an order you have delivered!");
      alert.showAndWait();
    }
  }

  /**
   * controller for the refresh button. refresh the view alerted if order status
   * is changed or order is added/cancelled
   */
  public void refreshBtnController() {
    ArrayList<Order> check = getOrderList();
    Tab tab;
    // order added
    if (orderList.size() < check.size()) {
      for (Order o : check) {
        if (!orderList.contains(o)) {
          tab = createOrderTab(o);
          tabPane.getTabs().add(tab);

          Alert alert = new Alert(AlertType.INFORMATION);
          alert.setTitle("ORDER ADDED");
          alert.setHeaderText(null);
          alert.setContentText("Order " + o.getOrderID() + " has been added");
          alert.showAndWait();

          confirmOrder(o);
        }
      }
    }
    // order is cancelled
    if (orderList.size() > check.size()) {
      for (Order o : orderList) {
        if (!check.contains(o)) {

          Alert a = new Alert(AlertType.INFORMATION);
          a.setTitle("ORDER CANCELLED!");
          a.setHeaderText(null);
          a.setContentText("Order " + o.getOrderID() + " cancelled!");
          PauseTransition delay = new PauseTransition(Duration.seconds(3));
          delay.setOnFinished(event -> a.hide());
          delay.play();
          a.showAndWait();
          tab = getTabByOrder(o);
          tabPane.getTabs().remove(tab);
        }
      }
    }
    orderList = new ArrayList<Order>(check);
    checkReady();
  }

  /**
   * back button controller. changes view to the waiter home
   * @throws SQLException 
   */
  public void backController() throws SQLException {
    ViewManager.getInstance().showWaiterHome();
  }

  /**
   * 
   * controller for clicking on tab. shows information for the orders table
   * number and order status
   */
  public void tabClickController() {
    Tab tab = tabPane.getSelectionModel().getSelectedItem();
    Order o = getOrderByName(tab.getText());
    tableNo.setText("Table Number: " + o.getTableNumber());
    orderStatusText.setText("Order Status: " + o.getOrderStatus());
  }

  /**
   * check orderstatus is ready. check through all the orders in the orderlist
   * to see if the order status is ready alerts if it is ready
   */
  private void checkReady() {
    // if order is ready
    for (Order o : orderList) {
      if (isReady(o)) {
        Alert a = new Alert(AlertType.INFORMATION);
        a.setTitle("ORDER READY!");
        a.setHeaderText("Order " + o.getOrderID() + " ready!");
        a.setContentText("Please deliver to table " + o.getTableNumber());
        PauseTransition delay = new PauseTransition(Duration.seconds(3));
        delay.setOnFinished(event -> a.hide());
        delay.play();
        a.showAndWait();
      }
    }
  }

  /**
   * confirm order. if the orderstatus is 'ordering' will change to ordered if
   * not, will alert that it has already been confirmed
   * 
   * @param o
   *          order that you would like to confirm
   */
  private void confirmOrder(Order o) {
    if (isConfirm(o)) {
      Alert a = new Alert(AlertType.CONFIRMATION);
      a.setTitle("Confirmation Dialog");
      a.setHeaderText(null);
      a.setContentText("Would you like to confirm 'Order " + o.getOrderID() + "'?");
      ButtonType buttonTypeYes = new ButtonType("Yes");
      ButtonType buttonTypeNo = new ButtonType("No");
      a.getButtonTypes().setAll(buttonTypeYes, buttonTypeNo);
      mySales = mySales + AddMenuItemToOrderWaiterController.getTotalSales();
      Optional<ButtonType> result = a.showAndWait();
      if (result.get() == buttonTypeYes) {
        changeOrderStatus(o, OrderStatus.ordered);

        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("ORDER CONFIRMED");
        alert.setHeaderText(null);
        alert.setContentText("Order " + o.getOrderID() + " has been confirmed");
        alert.showAndWait();
      } else {
        a.close();
      }
    } else {
      Alert alert = new Alert(AlertType.ERROR);
      alert.setTitle("ERROR!");
      alert.setHeaderText(null);
      alert.setContentText("Order has already been confirmed");
      alert.showAndWait();
    }
  }

  /**
   * deliverOrder. if the orderstatus is 'ready' will change to delivered if
   * not, will alert that it has already been delivered
   * 
   * @param o
   *          the order that has been delivered
   */
  private void deliverOrder(Order o) {
    if (!isDelivered(o) && isReady(o)) {
      Alert a = new Alert(AlertType.CONFIRMATION);
      a.setTitle("Confirmation Dialog");
      a.setHeaderText(null);
      a.setContentText("'Order " + o.getOrderID() + "' delivered?");
      ButtonType buttonTypeYes = new ButtonType("Yes");
      ButtonType buttonTypeNo = new ButtonType("No");
      a.getButtonTypes().setAll(buttonTypeYes, buttonTypeNo);

      Optional<ButtonType> result = a.showAndWait();
      if (result.get() == buttonTypeYes) {
        changeOrderStatus(o, OrderStatus.delivered);
        Model.getModel().getDatabase().toggleReady(o.getOrderID());
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("ORDER DELIVERED");
        alert.setHeaderText(null);
        alert.setContentText("Order " + o.getOrderID() + " has been delivered");
        alert.showAndWait();
      } else {
        a.close();
      }
    } else {
      Alert alert = new Alert(AlertType.ERROR);
      alert.setTitle("ERROR!");
      alert.setHeaderText(null);
      alert.setContentText("Order is not ready yet or has already been delivered");
      alert.showAndWait();
    }
  }

  /**
   * changeOrderStatus. removes the order in the database, changes the
   * orderstatus adds to the database
   * 
   * @param o
   *          the Order to be changed
   * @param status
   *          status of the order to be changed
   */
  private void changeOrderStatus(Order o, OrderStatus status) {
    Model.getModel().getDatabase().removeOrderFromOrderCJB(o);
    o.setOrderStatus(status);
    Model.getModel().getDatabase().addOrderToOrderCJB(o);
  }

  /**
   * creates a order tab with order and adds info to the tab.
   * 
   * @param o
   *          order to create tab of
   * @return the newly created tab
   */
  private Tab createOrderTab(Order o) {
    Tab orderTab = new Tab(String.valueOf(o.getOrderID()));
    ListView<String> orderInfo = new ListView<>();
    ObservableList<String> orderObservableList = FXCollections.observableArrayList();

    for (MenuItem item : o.getMenuItems()) {
      orderObservableList.add(item.getName());
    }

    orderTab.setContent(orderInfo);
    orderInfo.setItems(orderObservableList);

    return orderTab;
  }

  private ArrayList<Order> getOrderList() {
    ArrayList<Order> retList = new ArrayList<>();
    for (Order o : Model.getModel().getDatabase().getAllOrders()) {
      if (isAssignedTable(o.getTableNumber())) {
        retList.add(o);
      }
    }
    return retList;
  }

  /**
   * check orderstatus is 'ordering'.
   * 
   * @param o
   *          Order to check status
   * @return true if order status is 'ordering'
   */
  private boolean isConfirm(Order o) {
    return o.getOrderStatus().equals(OrderStatus.ordering);
  }

  /**
   * check orderstatus is'ready'
   * 
   * @param o
   *          Order to check status
   * @return true if order status is 'ready'
   */
  private boolean isReady(Order o) {
    return o.getOrderStatus().equals(OrderStatus.ready);
  }

  /**
   * check orderstatus is 'delivered'
   * 
   * @param o
   *          Order to check status
   * @return true if order status is 'delivered'
   */
  private boolean isDelivered(Order o) {
    return o.getOrderStatus().equals(OrderStatus.delivered);
  }
  /**
   * check if waiter is assigned to that table number.
   * @param tNo the table number to check waiter is assigned to
   * @return true if the waiter is assigned to that table
   */
  public boolean isAssignedTable(int tNo) {
    return assignedTables.contains(tNo);
  }

  /**
   * get tab by the order.
   * @param o Order the get the tab 
   * @return Tab that contains the order
   */

  public Tab getTabByOrder(Order o) {
    Tab tab = new Tab();
    for (Tab t : tabPane.getTabs()) {
      if (t.getText().equals(String.valueOf(o.getOrderID()))) {
        tab = t;
      }
    }
    return tab;
  }
  /**
   * gets order with the same name
   * @param selectedName name of the order to get from orderlist
   * @return the Order of the name
   */
  private Order getOrderByName(String selectedName) {
    int orderId = Integer.parseInt(selectedName);
    Order retOrder = null;
    for (Order o : orderList) {
      if (orderId == o.getOrderID()) {
        retOrder = o;
      }
    }
    return retOrder;
  }
}
