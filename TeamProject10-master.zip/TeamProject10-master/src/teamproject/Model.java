package teamproject;

/**
 * Model is central part of the business logic. It is the Core of Model in MVC pattern.
 * 
 * @author Nikoloz
 *
 */
public class Model {

  /** Singleton of Model class. */
  private static Model model;

  /** Singleton of sqlJDBC */
  private sqlJDBC database;

  private Model() {
    database = sqlJDBC.getsqlJDBC();
/*
    database.resetOrderCJB();
    database.resetOrderReservationCJB();
    database.resetCustomerWaiterCalls();
    database.resetWaiterReadyCJB();
    */
  }

  public static Model getModel() {
    if (model == null) {
      model = new Model();
    }
    return model;
  }

  public sqlJDBC getDatabase() {
    return this.database;
  }

}
