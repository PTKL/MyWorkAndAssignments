package teamproject;

import javafx.beans.property.SimpleStringProperty;

public class ManagerViewLoginTable {
  private final SimpleStringProperty username;
  private final SimpleStringProperty logintype;
  private final SimpleStringProperty salt;
  private final SimpleStringProperty hash;

  public ManagerViewLoginTable(String username, String logintype, String salt, String hash) {
    this.username = new SimpleStringProperty(username);
    this.logintype = new SimpleStringProperty(logintype);
    this.salt = new SimpleStringProperty(salt);
    this.hash = new SimpleStringProperty(hash);
  }

  public String getLogintype() {
    return this.logintype.get();
  }

  public String getSalt() {
    return this.salt.get();
  }

  public String getHash() {
    return this.hash.get();
  }

  public String getUsername() {
    return this.username.get();
  }
}
