package teamproject;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

public class ManagerViewWaiterTable {
  private final SimpleStringProperty waiter;
  private final SimpleStringProperty tables;
  
  public ManagerViewWaiterTable(String waiter, String tables) {
    this.waiter = new SimpleStringProperty(waiter);
    this.tables = new SimpleStringProperty(tables);
  }
  
  public String getWaiter() {
    return this.waiter.get();
  }
  
  public String getTables() {
    return this.tables.get();
  }
}