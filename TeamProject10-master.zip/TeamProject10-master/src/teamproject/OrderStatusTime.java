package teamproject;

import java.util.Date;
import java.util.HashMap;

/**
 * @TODO JAVADOCS
 * @author callum
 */
public class OrderStatusTime {
  private HashMap<OrderStatus, Long> times;

  /**
   * @TODO JAVADOCS
   * @author callum
   */
  public OrderStatusTime() {
    this.times = new HashMap<OrderStatus, Long>();
  }

  /**
   * @TODO JAVADOCS
   * @author callum
   */
  public OrderStatusTime(HashMap<OrderStatus, Long> times) {
    this.times = times;
  }

  /**
   * @TODO JAVADOCS
   * @author callum
   */
  public void setOrderStatusTime(OrderStatus o) {
    Date date = new Date();
    this.times.put(o, date.getTime());
  }

  /**
   * @TODO JAVADOCS
   * @author callum
   */
  public long getOrderStatusTime(OrderStatus o) {
    return this.times.get(o);
  }

  /**
   * @TODO JAVADOCS
   * @author callum
   */
  public static long differenceInMins(long a, long b) {
    long returning = a - b;
    returning = returning / 1000;// into secs
    returning = returning / 60;// into mins

    return returning;
  }

  public String toString() {
    String returning = "OrderStatusTime{";
    for (OrderStatus o : this.times.keySet()) {
      returning += "Key{" + o.toString() + "," + this.times.get(o) + "}";
    }
    return (returning += "}");
  }

  public static OrderStatusTime toOrderStatusTime(String s) {
    if (s == null) {
      return null;
    }
    if (s.length() < 17) {
      return null;
    } // first 16 and last 1

    s = s.substring(16);
    s = s.substring(0, s.length() - 1);

    String split[] = s.split("Key");
    HashMap<OrderStatus, Long> temp = new HashMap<OrderStatus, Long>();
    for (int i = 1; i < split.length; i++) {
      String str = split[i];
      str = str.substring(1);
      str = str.substring(0, str.length() - 1);
      String split2[] = str.split(",");
      temp.put(OrderStatus.toOrderStatus(split2[0]), Long.parseLong(split2[1]));
    }

    return (new OrderStatusTime(temp));
  }

  /**
   * TODO
   * 
   * @author Callum
   */
  @Override
  public boolean equals(Object obj) {
    if (obj instanceof OrderStatusTime) {
      OrderStatusTime o = (OrderStatusTime) obj;
      return this.times.equals(o.times);
    }

    return false;
  }
}