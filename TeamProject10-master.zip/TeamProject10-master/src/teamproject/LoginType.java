package teamproject;

/**
 * An enum type which after a succeful login, determines which actor the user is within the systems.
 * To allow other classes to proceded differently depending on which actor they are.
 * 
 * @author Callum
 */
public enum LoginType {
  Customer, Waiter, Manager, Kitchen;

  /**
   * A function for returning a debug string of the current LoginType enum instance.
   * 
   * @return String The debug String of the LoginType.
   */
  public String toString() {
    if (this == LoginType.Customer) {
      return "Customer";
    } else if (this == LoginType.Waiter) {
      return "Waiter";
    } else if (this == LoginType.Manager) {
      return "Manager";
    } else if (this == LoginType.Kitchen) {
      return "Kitchen";
    }

    return null;
  }

  /**
   * A function which takes a string as a parametere and converted the LoginType.toString back into
   * the LoginType's toString String passed in.
   * 
   * @param s
   *          The toString you wish to get the LoginType for.
   * @return LoginType returns the LoginType of the toString() and null if the toString doesn't
   *         corrospond to any.
   */
  public static LoginType toLoginType(String s) {
    if (s.equalsIgnoreCase("Customer")) {
      return LoginType.Customer;
    } else if (s.equalsIgnoreCase("Waiter")) {
      return LoginType.Waiter;
    } else if (s.equalsIgnoreCase("Manager")) {
      return LoginType.Manager;
    } else if (s.equalsIgnoreCase("Kitchen")) {
      return LoginType.Kitchen;
    }

    return null;
  }
}
