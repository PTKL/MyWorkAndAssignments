package teamproject;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class AddAccountController {

  @FXML // ResourceBundle that was given to the FXMLLoader
  private ResourceBundle resources;

  @FXML // URL location of the FXML file that was given to the FXMLLoader
  private URL location;

  @FXML // fx:id="accountTypeDropdown"
  private ChoiceBox<String> accountTypeDropdown;

  @FXML // fx:id="TextFieldFx1
  private TextField TextFieldFx1; // Value injected by FXMLLoader

  @FXML // fx:id="TextFieldFx11"
  private TextField TextFieldFx11;// Value injected by FXMLLoader

  @FXML // fx:id="passField1"
  private PasswordField passField1;

  @FXML // fx:id="passField2"
  private PasswordField passField2;

  @FXML // fx:id="backToManager"
  private Button backToManager; // Value injected by FXMLLoader

  @FXML // fx:id="signUp"
  private Button signUp; // Value injected by FXMLLoader

  public static String SetUsername;
  public static String SetAccountType;

  @FXML // This method is called by the FXMLLoader when initialization is complete
  void initialize() {
    if (SetUsername != null && SetAccountType != null) {
      TextFieldFx1.setText(SetUsername);
      TextFieldFx11.setText(SetUsername);
      accountTypeDropdown.getSelectionModel().select(SetAccountType);
    }

    backToManager.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        ViewManager.getInstance().showManagerView();
      }
    });

    signUp.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (TextFieldFx1.getText().equalsIgnoreCase(TextFieldFx11.getText())) {
          if (passField1.getText().equalsIgnoreCase(passField2.getText())) {
            if (TextFieldFx1.getText().length() < 256) {
              if (TextFieldFx1.getText().length() > 0) {
                if (passField2.getText().length() > 0) {
                  if (accountTypeDropdown.getSelectionModel().getSelectedItem() != null) {
                    if (accountTypeDropdown.getSelectionModel().getSelectedItem()
                        .equalsIgnoreCase("Customer")) {
                      Model.getModel().getDatabase().addCustomerLogin(TextFieldFx1.getText(),
                          passField1.getText());
                    } else if (accountTypeDropdown.getSelectionModel().getSelectedItem()
                        .equalsIgnoreCase("Waiter")) {
                      Model.getModel().getDatabase().addWaiterLogin(TextFieldFx1.getText(),
                          passField1.getText());
                      addWaiter(TextFieldFx1.getText());
                    } else if (accountTypeDropdown.getSelectionModel().getSelectedItem()
                        .equalsIgnoreCase("Kitchen")) {
                      Model.getModel().getDatabase().addKitchenLogin(TextFieldFx1.getText(),
                          passField1.getText());
                    } else if (accountTypeDropdown.getSelectionModel().getSelectedItem()
                        .equalsIgnoreCase("Manager")) {
                      Model.getModel().getDatabase().addManagerLogin(TextFieldFx1.getText(),
                          passField1.getText());
                    }

                    Alert a = new Alert(AlertType.INFORMATION);
                    a.setTitle("REGISTERED!");
                    a.setHeaderText(null);
                    a.setContentText("" + TextFieldFx1.getText() + " is now register!");
                    a.showAndWait();
                    ViewManager.getInstance().showManagerView();
                  } else {
                    Alert a = new Alert(AlertType.INFORMATION);
                    a.setTitle("ERROR!");
                    a.setHeaderText(null);
                    a.setContentText("Select a account type!");
                    a.showAndWait();
                  }
                } else {
                  Alert a = new Alert(AlertType.INFORMATION);
                  a.setTitle("ERROR!");
                  a.setHeaderText(null);
                  a.setContentText("Password can't be empty!");
                  a.showAndWait();
                }
              } else {
                Alert a = new Alert(AlertType.INFORMATION);
                a.setTitle("ERROR!");
                a.setHeaderText(null);
                a.setContentText("Username can't be empty");
                a.showAndWait();
              }
            } else {
              Alert a = new Alert(AlertType.INFORMATION);
              a.setTitle("ERROR!");
              a.setHeaderText(null);
              a.setContentText("Username needs to be 255 characters or less!");
              a.showAndWait();
            }

          } else {
            Alert a = new Alert(AlertType.INFORMATION);
            a.setTitle("ERROR!");
            a.setHeaderText(null);
            a.setContentText("Passwords don't match!");
            a.showAndWait();
          }
        } else {
          Alert a = new Alert(AlertType.INFORMATION);
          a.setTitle("ERROR!");
          a.setHeaderText(null);
          a.setContentText("Emails don't match!");
          a.showAndWait();
        }
      }
    });
  }
  public void addWaiter(String name) {
    ArrayList<Integer> list = new ArrayList<>();
    Waiter waiter = new Waiter(name, 0, list, 0);
    Model.getModel().getDatabase().addWaiter(waiter);
  }
}
