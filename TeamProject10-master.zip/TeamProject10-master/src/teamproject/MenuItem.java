package teamproject;

public class MenuItem {

  private String itemName;
  private int itemPrice, itemCost, calories;
  private Ingredient[] ingredients;
  private Category[] categories;
  private String imageURL;

  public MenuItem(String itemName, String imageURL, int itemPrice, Ingredient[] ingredients,
      Category[] categories) {
    this.itemName = itemName;
    this.itemPrice = itemPrice;
    this.ingredients = ingredients;
    this.itemCost = workOutCost();
    this.calories = workOutCalories();
    this.categories = categories;
    this.imageURL = imageURL;
  }

  private int workOutCost() {
    int cost = 0;

    if (this.ingredients != null) {
      for (Ingredient currentIngredient : this.ingredients) {
        cost += currentIngredient.getCost();
      }
    }

    return cost;
  }

  private int workOutCalories() {
    int calories = 0;

    if (this.ingredients != null) {
      for (Ingredient currentIngredient : this.ingredients) {
        calories += currentIngredient.getCalories();
      }
    }

    return calories;
  }

  public String getName() {
    return this.itemName;
  }

  public Category[] getCatergories() {
    return this.categories;
  }

  public int getCost() {
    return this.itemCost;
  }

  public int getPrice() {
    return this.itemPrice;
  }

  public int getCalories() {
    return this.calories;
  }

  public Ingredient[] getIngredients() {
    return this.ingredients;
  }

  public String getImageURL() {
    return imageURL;
  }

  /**
   * TODO
   * 
   * @param isCategory
   * @return
   * @author Callum
   */
  public boolean is(Category isCategory) {
    for (Category cat : this.categories) {
      if (isCategory.equals(cat)) {
        return true;
      }
    }
    return false;
  }

  /**
   * A function which returns a string containing debug information for the menuItem instance for
   * which it was called from.<br>
   * 
   * @return A debug string for the menuItem instance.
   * @author Callum
   */
  public String toString() {
    return "MenuItem{" + this.itemName + "," + this.imageURL + "," + this.itemPrice + ","
        + this.itemCost + "," + this.calories + "," + Category.toString(categories) + ","
        + Ingredient.toString(ingredients) + "}";
  }

  /**
   * TODO
   * 
   * @param s
   * @return
   * @author Callum
   */
  public static MenuItem toMenuItem(String s) {
    if (s == null) {
      return null;
    }

    if (s.length() < 10) {
      return null;
    }

    if (!s.startsWith("MenuItem{")) {
      return null;
    }

    s = s.substring(9);
    s = s.substring(0, s.length() - 1);
    String[] splitString = s.split("Ingredients");

    String IngredientString = null;
    if (splitString.length > 1) {
      IngredientString = "Ingredients" + splitString[1];
    }

    // remove ,
    String stringWithRemovedIngredients = splitString[0].substring(0, splitString[0].length() - 1);

    String[] splitString2 = stringWithRemovedIngredients.split("Categories");

    String CategoryString = null;
    if (splitString2.length > 1) {
      CategoryString = "Categories" + splitString2[1];
    }

    String stringWithRemovedIngredientsAndCategory = splitString2[0].substring(0,
        splitString2[0].length() - 1);// remove the colon left
    String[] splitString3 = stringWithRemovedIngredientsAndCategory.split(",");

    String itemName = splitString3[0];
    String imageUrl = splitString3[1];
    if (itemName.equals("null")) {
      itemName = null;
    }
    if (imageUrl.equals("null")) {
      imageUrl = null;
    }

    return new MenuItem(itemName, imageUrl, Integer.parseInt(splitString3[2]),
        Ingredient.toIngredientArray(IngredientString), Category.toCategoryArray(CategoryString));
  }

  /**
   * TODO
   * 
   * @author Callum
   */
  public static String toString(MenuItem[] items) {
    if (items == null) {
      return null;
    }
    String returning = "MenuItems{";
    for (int i = 0; i < items.length; i++) {
      returning += items[i].toString();
      if (i != (items.length - 1)) {
        returning += ",";
      }
    }

    return (returning + "}");
  }

  /**
   * //TODO
   * 
   * @author Callum
   */
  public static MenuItem[] toMenuItemArray(String s) {
    if (s == null) {
      return null;
    }

    if (s.length() < 11) {
      return null;
    } // wouldnt be able to sub first 10 and last 1

    if (!(s.startsWith("MenuItems{"))) {
      return null;
    } // isnt an Allergy[] toString as doesnt start with 'Allergies{'

    s = s.substring(10);
    s = s.substring(0, s.length() - 1);
    String[] splitString = s.split("MenuItem");
    // -1 length as first is blank so only have length -1 ingredients
    MenuItem[] returning = new MenuItem[splitString.length - 1];

    // start at 1 as [0] is blank
    // so start at 1 to skip blank,
    for (int i = 1; i < splitString.length; i++) {
      // returning is -1, as it has one less that the split length and we start i at 1
      if (i != (splitString.length - 1)) {
        returning[i - 1] = MenuItem
            .toMenuItem(("MenuItem" + splitString[i].substring(0, splitString[i].length() - 1)));
      } else {
        // as last ingredient in array doesnt have comma after it
        returning[i - 1] = MenuItem.toMenuItem(("MenuItem" + splitString[i]));
      }
    }

    return returning;
  }

  /**
   * TODO
   * 
   * @author Callum
   */
  @Override
  public boolean equals(Object obj) {
    if (obj instanceof MenuItem) {
      MenuItem temp = (MenuItem) obj;
      if ((temp.itemName == null && this.itemName == null) || temp.itemName.equals(this.itemName)) {
        return true;
      }

    }

    return false;
  }

  /**
   * TODO
   * 
   * @author Callum
   */
  @Override
  public int hashCode() {
    return (this.itemName.hashCode());
  }

  /**
   * TODO
   * 
   * @param i
   * @return
   */
  public int compareTo(MenuItem i) {
    return this.itemName.compareTo(i.getName());
  }

}
