package teamproject;
/**
 * @author emil
 */
import javafx.beans.property.SimpleStringProperty;

public class ManagerViewEmployeeDataTable {
  private final SimpleStringProperty id;
  private final SimpleStringProperty username;
  private final SimpleStringProperty responcetime;
  private final SimpleStringProperty numberoforders;
  
  public ManagerViewEmployeeDataTable(String id, String username,String responcetime, String numberoforders){
    this.id = new SimpleStringProperty(id);
    this.username = new SimpleStringProperty(username);
    this.responcetime = new SimpleStringProperty(responcetime);
    this.numberoforders = new SimpleStringProperty(numberoforders);
  }

  public String getId() {
    return this.id.get();
  }

  public String getUsername() {
    return this.username.get();
  }

  public String getResponcetime() {
    return this.responcetime.get();
  }

  public String getNumberoforders() {
    return this.numberoforders.get();
  }
}

