package teamproject;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @author emil
 */

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class ManagerViewController {

  @FXML // ResourceBundle that was given to the FXMLLoader
  private ResourceBundle resources;

  @FXML // URL location of the FXML file that was given to the FXMLLoader
  private URL location;

  @FXML
  private ListView<String> reservedList = new ListView<String>();

  ObservableList<String> reserved;

  @FXML
  private ListView<String> orderList = new ListView<String>();

  ObservableList<String> orders;

  @FXML
  private ListView<String> serviceList = new ListView<String>();

  ObservableList<String> services;

  @FXML // fx:id="Stock"
  private Tab Stock; // Value injected by FXMLLoader

  @FXML // fx:id="stockTable"
  private TableView<ManagerViewStockTable> stockTable; // Value injected by
  // FXMLLoader

  @FXML // fx:id="itemCol"
  private TableColumn<ManagerViewStockTable, String> itemCol; // Value
  // injected by
  // FXMLLoader

  @FXML // fx:id="remaningUnitsCol"
  private TableColumn<ManagerViewStockTable, String> remaningUnitsCol; // Value
  
  @FXML // fx:id="rmAmountStock"
  private Button emailClients;

  @FXML // fx:id="addAmountStock"
  private Button addAmountStock; // Value injected by FXMLLoader

  @FXML // fx:id="rmAmountStock"
  private Button rmAmountStock;

  @FXML // fx:id="addStock
  private TextField addStock; // Value injected by FXMLLoader

  @FXML // fx:id="delIngredient
  private Button delIngredient; // Value injected by FXMLLoader

  @FXML
  private Button addIngredient;

  @FXML
  private Button modIngredient;

  @FXML // fx:id="employeeTable"
  private TableView<ManagerViewEmployeeDataTable> employeeTable; // Value
                                                                 // injected
                                                                 // by
  // FXMLLoader

  @FXML // fx:id="id"
  private TableColumn<ManagerViewEmployeeDataTable, String> id; // Value
                                                                // injected
                                                                // by
                                                                // FXMLLoader

  @FXML // fx:id="username"
  private TableColumn<ManagerViewEmployeeDataTable, String> username; // Value
                                                                      // injected
                                                                      // by
                                                                      // FXMLLoader

  @FXML // fx:id="responcetime"
  private TableColumn<ManagerViewEmployeeDataTable, String> responcetime; // Value
                                                                          // injected
                                                                          // by
                                                                          // FXMLLoader

  @FXML // fx:id="numberoforders"
  private TableColumn<ManagerViewEmployeeDataTable, String> numberoforders; // Value
                                                                            // injected
                                                                            // by
                                                                            // FXMLLoader

  @FXML // fx:id="userDataTable"
  private TableView<ManagerViewUserDataTable> userDataTable; // Value
                                                             // injected
                                                             // by
  // FXMLLoader

  @FXML // fx:id="usernameUser"
  private TableColumn<ManagerViewUserDataTable, String> usernameUser; // Value
  // injected
  // by
  // FXMLLoader

  @FXML // fx:id="usertype"
  private TableColumn<ManagerViewUserDataTable, String> usertype; // Value
                                                                  // injected
                                                                  // by
                                                                  // FXMLLoader

  @FXML // fx:id="email"
  private TableColumn<ManagerViewUserDataTable, String> email; // Value
                                                               // injected
                                                               // by
                                                               // FXMLLoader

  @FXML // fx:id="Stock"
  private Tab Logins; // Value injected by FXMLLoader

  @FXML
  private Tab waiterTab;

  @FXML
  private TableView<ManagerViewWaiterTable> waiterTable;

  @FXML
  private TableColumn<ManagerViewWaiterTable, String> tableCol;
  ObservableList<String> obsTableCol = FXCollections.observableArrayList();

  @FXML
  private TableColumn<ManagerViewWaiterTable, String> waiterCol;
  ObservableList<String> obsWaiterCol = FXCollections.observableArrayList();

  @FXML
  private ListView<Integer> tableList = new ListView<>();
  ObservableList<Integer> obsTableList = FXCollections.observableArrayList();

  @FXML // fx:id="stockTable"
  private TableView<ManagerViewLoginTable> loginTable; // Value injected by
  // FXMLLoader

  @FXML // fx:id="itemCol"
  private TableColumn<ManagerViewLoginTable, String> usernameCol; // Value
  // injected
  // by
  // FXMLLoader

  @FXML // fx:id="itemCol"
  private TableColumn<ManagerViewLoginTable, String> loginTypeCol; // Value
  // injected
  // by
  // FXMLLoader

  @FXML // fx:id="itemCol"
  private TableColumn<ManagerViewLoginTable, String> saltCol; // Value
  // injected by
  // FXMLLoader

  @FXML // fx:id="itemCol"
  private TableColumn<ManagerViewLoginTable, String> hashCol; // Value
  // injected by
  // FXMLLoader


  @FXML // fx:id="addAccount"
  private Button addLogin; // Value injected by FXMLLoader

  @FXML // fx:id="addAccount"
  private Button delLogin; // Value injected by FXMLLoader

  @FXML // fx:id="addAccount"
  private Button modLogin; // Value injected by FXMLLoader

  @FXML // fx:id="userData"
  private Tab Menu; // Value injected by FXMLLoader

  @FXML // fx:id="userDataTable"
  private TableView<ManagerViewMenuTable> menuTable; // Value injected by
  // FXMLLoader

  @FXML // fx:id="user"
  private TableColumn<ManagerViewMenuTable, String> menuName; // Value
  // injected by
  // FXMLLoader

  @FXML // fx:id="user"
  private TableColumn<ManagerViewMenuTable, String> menuSPrice; // Value
  // injected
  // by
  // FXMLLoader

  @FXML // fx:id="user"
  private TableColumn<ManagerViewMenuTable, String> menuPrice; // Value
  // injected
  // by
  // FXMLLoader

  @FXML // fx:id="user"
  private TableColumn<ManagerViewMenuTable, String> menuCalories; // Value
  // injected
  // by
  // FXMLLoader

  @FXML // fx:id="user"
  private TableColumn<ManagerViewMenuTable, String> MenuIng; // Value injected
  // by FXMLLoader

  @FXML // fx:id="delAccountUser"
  private Button addMenu; // Value injected by FXMLLoader

  @FXML // fx:id="delAccountUser"
  private Button modMenu; // Value injected by FXMLLoader

  @FXML // fx:id="delAccountUser"
  private Button delMenu; // Value injected by FXMLLoader

  @FXML
  private Button assignTableBtn;

  @FXML // fx:id="logout"
  private Button logout; // Value injected by FXMLLoader

  @FXML // This method is called by the FXMLLoader when initialization is
  // complete
  void initialize() {
    ////
    addMenu.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        MenuCreationController.modding = null;
        ViewManager.getInstance().showMenuCreation();
      }
    });

    delMenu.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (selectedMenuItem != null) {
          Model.getModel().getDatabase().removeMenuItemFromMenuItemsCJB(selectedMenuItem);
          setupMenu();
        }
      }
    });

    modMenu.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (selectedMenuItem != null) {
          MenuCreationController.modding = selectedMenuItem;
          ViewManager.getInstance().showMenuCreation();
        }
      }
    });

    ////
    addLogin.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        AddAccountController.SetAccountType = null;
        AddAccountController.SetUsername = null;
        ViewManager.getInstance().showAddAccount();
      }
    });

    delLogin.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (selectedUser != null) {
          Model.getModel().getDatabase().removeLogin(selectedUser);
          setupLogin();
        }
      }
    });

    modLogin.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        AddAccountController.SetAccountType = selectedType;
        AddAccountController.SetUsername = selectedUser;
        Model.getModel().getDatabase().removeLogin(selectedUser);
        ViewManager.getInstance().showAddAccount();
      }
    });
    ////

    delIngredient.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (selectedIng != null) {
          try {
            Model.getModel().getDatabase().removeIngredientFromIngredientCJB(selectedIng);
            setupStock();
          } catch (Exception e) {
          }
        }
      }
    });

    addAmountStock.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (selectedIng != null) {
          try {
            int adding = Integer.parseInt(addStock.getText());
            Model.getModel().getDatabase().addToIngredientStockLevel(adding, selectedIng);
            setupStock();
          } catch (Exception e) {
          }
        }
      }
    });

    rmAmountStock.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (selectedIng != null) {
          try {
            int removing = Integer.parseInt(addStock.getText());
            Model.getModel().getDatabase().deductFromIngredientStockLevel(removing, selectedIng);
            setupStock();
          } catch (Exception e) {
          }
        }
      }
    });

    addIngredient.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        AddIngredientViewController.modding = null;
        ViewManager.getInstance().showAddIngredient();
      }
    });

    modIngredient.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (selectedIng != null) {
          AddIngredientViewController.modding = selectedIng;
          ViewManager.getInstance().showAddIngredient();
        } else {
          Alert a = new Alert(AlertType.INFORMATION);
          a.setTitle("Select an Ingredient!");
          a.setHeaderText(null);
          a.setContentText("Selected an Ingredient to modify!");
          a.showAndWait();
        }
      }
    });
    
    emailClients.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        ViewManager.getInstance().showEmailView();
      }
    });
    ////

    logout.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        ViewManager.getInstance().showLoginScreen();
      }
    });

    setupStock();
    setupOrder();
    setupLogin();
    setupMenu();
    setupServices();
    setupReserved();
    setupEmployee();
    setupUser();
    try {
      setupWaiter();
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }

  /**
   * @author emil
   */
  public void setupEmployee() {
    employeeTable.setEditable(true);
    ObservableList<ManagerViewEmployeeDataTable> data =
        Model.getModel().getDatabase().displayEmployeeDataTable();

    id.setCellValueFactory(new PropertyValueFactory<ManagerViewEmployeeDataTable, String>("id"));

    username.setCellValueFactory(
        new PropertyValueFactory<ManagerViewEmployeeDataTable, String>("username"));

    responcetime.setCellValueFactory(
        new PropertyValueFactory<ManagerViewEmployeeDataTable, String>("responcetime"));

    numberoforders.setCellValueFactory(
        new PropertyValueFactory<ManagerViewEmployeeDataTable, String>("numberoforders"));

    employeeTable.setItems(data);
  }

  /**
   * @author emil
   */
  public void setupUser() {
    userDataTable.setEditable(true);
    ObservableList<ManagerViewUserDataTable> data =
        Model.getModel().getDatabase().displayUserDataTable();

    usertype.setCellValueFactory(
        new PropertyValueFactory<ManagerViewUserDataTable, String>("usertype"));

    email.setCellValueFactory(new PropertyValueFactory<ManagerViewUserDataTable, String>("email"));

    userDataTable.setItems(data);
  }

  public void setupMenu() {
    menuTable.setEditable(true);
    ObservableList<ManagerViewMenuTable> data = FXCollections.observableArrayList();

    for (MenuItem m : Model.getModel().getDatabase().getAllMenuItems()) {
      String ing = "";
      for (Ingredient i : m.getIngredients()) {
        ing += " " + i.getName();
      }

      data.add(new ManagerViewMenuTable(m.getName(), "" + (m.getCost() * 1.6), "" + m.getPrice(),
          "" + m.getCalories(), ing));
    }

    menuName.setCellValueFactory(new PropertyValueFactory<ManagerViewMenuTable, String>("name"));
    menuSPrice.setCellValueFactory(
        new PropertyValueFactory<ManagerViewMenuTable, String>("suggestPrice"));
    menuPrice.setCellValueFactory(new PropertyValueFactory<ManagerViewMenuTable, String>("price"));
    menuCalories
        .setCellValueFactory(new PropertyValueFactory<ManagerViewMenuTable, String>("calories"));
    MenuIng
        .setCellValueFactory(new PropertyValueFactory<ManagerViewMenuTable, String>("ingredients"));

    menuTable.setItems(data);
  }

  public void setupLogin() {
    loginTable.setEditable(true);
    ObservableList<ManagerViewLoginTable> data = Model.getModel().getDatabase().displayLoginTable();

    usernameCol
        .setCellValueFactory(new PropertyValueFactory<ManagerViewLoginTable, String>("username"));

    loginTypeCol
        .setCellValueFactory(new PropertyValueFactory<ManagerViewLoginTable, String>("logintype"));

    saltCol.setCellValueFactory(new PropertyValueFactory<ManagerViewLoginTable, String>("salt"));

    hashCol.setCellValueFactory(new PropertyValueFactory<ManagerViewLoginTable, String>("hash"));

    loginTable.setItems(data);
  }

  public void setupStock() {
    stockTable.setEditable(true);
    ObservableList<ManagerViewStockTable> data = FXCollections.observableArrayList();

    for (Ingredient i : Model.getModel().getDatabase().getAllIngredients()) {
      data.add(new ManagerViewStockTable(i.getName(),
          "" + Model.getModel().getDatabase().getIngredientStockLevel(i)));
    }

    itemCol.setCellValueFactory(new PropertyValueFactory<ManagerViewStockTable, String>("name"));

    remaningUnitsCol
        .setCellValueFactory(new PropertyValueFactory<ManagerViewStockTable, String>("level"));

    stockTable.setItems(data);
  }

  public void setupOrder() {
    orderList.setEditable(true);
    orders = FXCollections.observableArrayList();

    for (Order o : Model.getModel().getDatabase().getAllOrders()) {
    	if(o.getPaid() && o.getOrderStatus().equals(OrderStatus.delivered)){	
    	}else{
    	      String menuItemsString = "";
    	      for (MenuItem menuItem : o.getMenuItems()) {
    	        menuItemsString += menuItem.getName() + ", ";
    	      }
    	      orders.add("Order ID:" + o.getOrderID() + " Customer:" + o.getCustomer() + " Table:"
    	          + o.getTableNumber() + " Status:" + o.getOrderStatus() + " Price:" + o.getPrice()
    	          + " Paid:" + o.getPaid() + "  " + menuItemsString);
    	}

    }

    orderList.setItems(orders);
  }

  public void setupReserved() {
    reservedList.setEditable(true);
    reserved = FXCollections.observableArrayList();

    for (Order o : Model.getModel().getDatabase().getAllOrderReservationCJB()) {
      String menuItemsString = "";
      for (MenuItem menuItem : o.getMenuItems()) {
        menuItemsString += menuItem.getName() + ", ";
      }
      reserved.add("Order ID:" + o.getOrderID() + "  " + menuItemsString);
    }

    reservedList.setItems(reserved);
  }

  public void setupServices() {
    serviceList.setEditable(true);
    services = FXCollections.observableArrayList();

    for (int i : Model.getModel().getDatabase().getCustomerWaiterCalls()) {
    	Date d = new Date(); 
        services.add("TableNumber " + i+"   "+OrderStatusTime.differenceInMins(d.getTime(), Model.getModel().getDatabase().getTableNumberTimeCalled(i))+"mins ago");
    }

    serviceList.setItems(services);
  }

  Ingredient selectedIng;
  String selectedUser;
  String selectedType;
  MenuItem selectedMenuItem;

  public void stockTableController() {
    selectedIng = getIngredientByName(stockTable.getSelectionModel().getSelectedItem().getName());
  }

  public void loginTableController() {
    selectedUser = loginTable.getSelectionModel().getSelectedItem().getUsername();
    selectedType = loginTable.getSelectionModel().getSelectedItem().getLogintype();
  }

  public void menuTableController() {
    selectedMenuItem = getMenuItemByName(menuTable.getSelectionModel().getSelectedItem().getName());
  }

  public void setTableBtnController() throws IOException {
    String tableNo = "";

    List<String> choices = new ArrayList<>();
    choices.add("1");
    choices.add("2");
    choices.add("3");
    choices.add("4");
    choices.add("5");
    choices.add("6");

    ChoiceDialog<String> dialog = new ChoiceDialog<>("1", choices);
    dialog.setTitle("Assign table number");
    dialog.setHeaderText("Please choose the number for this table");
    dialog.setContentText("Choose the table number:");

    Optional<String> result = dialog.showAndWait();
    if (result.isPresent()) {
      PrintWriter output = new PrintWriter(new FileWriter("tableNumber.txt"));
      result.ifPresent(number -> output.println(number));
      output.close();
    }
  }

  // TODO
  public void addTableController() throws SQLException {
    ManagerViewWaiterTable item = waiterTable.getSelectionModel().getSelectedItem();
    Waiter waiter = Model.getModel().getDatabase().getWaiter(item.getWaiter());
    List<String> choices = new ArrayList<>();
    for(int i = 1; i <= 6; i++) {
      if(!waiter.getAssignedTables().contains(i)) {
        choices.add("" +  i);
      }
    }

    ChoiceDialog<String> dialog = new ChoiceDialog<>("1", choices);
   
    System.out.println(waiter.getUsername());
    dialog.setTitle("Assign table number");
    dialog.setHeaderText("Please choose the table to assign to this waiter");
    dialog.setContentText("Choose the table number:");

    Optional<String> result = dialog.showAndWait();
    if (result.isPresent()) {
      Model.getModel().getDatabase().removeWaiter(waiter);
      waiter.addTable(Integer.valueOf(result.get()));
      Model.getModel().getDatabase().addWaiter(waiter);
      setupWaiter();
    }
  }

  public void removeTableController() throws SQLException {
    ManagerViewWaiterTable item = waiterTable.getSelectionModel().getSelectedItem();
    Waiter waiter = Model.getModel().getDatabase().getWaiter(item.getWaiter());
    List<String> choices = new ArrayList<>();
    for(int i : waiter.getAssignedTables()) {
      choices.add(""+i);
    }
    ChoiceDialog<String> dialog = new ChoiceDialog<>("1", choices);
    dialog.setTitle("Assign table number");
    dialog.setHeaderText("Please choose the table to remove from this waiter");
    dialog.setContentText("Choose the table number:");

    Optional<String> result = dialog.showAndWait();
    if (result.isPresent()) {
      Model.getModel().getDatabase().removeWaiter(waiter);
      waiter.removeTable(Integer.valueOf(result.get()));
      Model.getModel().getDatabase().addWaiter(waiter);
      setupWaiter();
    }
  }

  private void setupWaiter() throws SQLException {
    waiterTable.setEditable(true);
    ObservableList<ManagerViewWaiterTable> data = FXCollections.observableArrayList();
    
    for(Waiter w : Model.getModel().getDatabase().getAllWaiters()) {
      data.add(new ManagerViewWaiterTable(w.getUsername(), ""+w.getAssignedTables()));
    }
    
    waiterCol.setCellValueFactory(new PropertyValueFactory<ManagerViewWaiterTable, String>("waiter"));
    tableCol.setCellValueFactory(new PropertyValueFactory<ManagerViewWaiterTable, String>("tables"));
    
    waiterTable.setItems(data);
    
  }

  public Ingredient getIngredientByName(String itemName) {
    Ingredient i = null;
    for (Ingredient i2 : Model.getModel().getDatabase().getAllIngredients()) {
      if (itemName.equals(i2.getName())) {
        i = i2;
      }
    }
    return i;
  }

  public MenuItem getMenuItemByName(String itemName) {
    MenuItem m = null;
    for (MenuItem m2 : Model.getModel().getDatabase().getAllMenuItems()) {
      if (itemName.equals(m2.getName())) {
        m = m2;
      }
    }
    return m;
  }
}
