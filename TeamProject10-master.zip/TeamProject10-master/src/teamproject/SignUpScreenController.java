package teamproject;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class SignUpScreenController {

  @FXML // ResourceBundle that was given to the FXMLLoader
  private ResourceBundle resources;

  @FXML // URL location of the FXML file that was given to the FXMLLoader
  private URL location;

  @FXML // fx:id="TextFieldFx1
  private TextField TextFieldFx1; // Value injected by FXMLLoader

  @FXML // fx:id="TextFieldFx11"
  private TextField TextFieldFx11;// Value injected by FXMLLoader

  @FXML // fx:id="passField1"
  private PasswordField passField1;

  @FXML // fx:id="passField2"
  private PasswordField passField2;

  @FXML // fx:id="signUp"
  private Button backToLogin; // Value injected by FXMLLoader

  @FXML // fx:id="signUp"
  private Button signUp; // Value injected by FXMLLoader

  //
  @FXML // This method is called by the FXMLLoader when initialization is complete
  void initialize() {

    signUp.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        // TODO
        if (!(Model.getModel().getDatabase().containsUsername(TextFieldFx1.getText()))) {
          if (TextFieldFx1.getText().equalsIgnoreCase(TextFieldFx11.getText())) {
            if (passField1.getText().equalsIgnoreCase(passField2.getText())) {
              if (TextFieldFx1.getText().length() < 256) {
                if (TextFieldFx1.getText().length() > 0) {
                  if (passField2.getText().length() > 0) {
                    Model.getModel().getDatabase().addCustomerLogin(TextFieldFx1.getText(),
                        passField1.getText());

                    Alert a = new Alert(AlertType.INFORMATION);
                    a.setTitle("REGISTERED!");
                    a.setHeaderText(null);
                    a.setContentText("" + TextFieldFx1.getText() + " is now register!");
                    a.showAndWait();
                  } else {
                    Alert a = new Alert(AlertType.INFORMATION);
                    a.setTitle("ERROR!");
                    a.setHeaderText(null);
                    a.setContentText("Password can't be empty!");
                    a.showAndWait();
                  }
                } else {
                  Alert a = new Alert(AlertType.INFORMATION);
                  a.setTitle("ERROR!");
                  a.setHeaderText(null);
                  a.setContentText("Username can't be empty");
                  a.showAndWait();
                }
              } else {
                Alert a = new Alert(AlertType.INFORMATION);
                a.setTitle("ERROR!");
                a.setHeaderText(null);
                a.setContentText("Username needs to be 255 characters or less!");
                a.showAndWait();
              }

            } else {
              Alert a = new Alert(AlertType.INFORMATION);
              a.setTitle("ERROR!");
              a.setHeaderText(null);
              a.setContentText("Passwords don't match!");
              a.showAndWait();
            }
          } else {
            Alert a = new Alert(AlertType.INFORMATION);
            a.setTitle("ERROR!");
            a.setHeaderText(null);
            a.setContentText("Emails don't match!");
            a.showAndWait();
          }
        } else {
          Alert a = new Alert(AlertType.INFORMATION);
          a.setTitle("ERROR!");
          a.setHeaderText(null);
          a.setContentText("" + TextFieldFx1.getText() + " is already used!");
          a.showAndWait();
        }
      }
    });

    backToLogin.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        ViewManager.getInstance().showLoginScreen();
      }
    });
  }
}
