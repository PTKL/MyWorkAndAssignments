package teamproject;

/**
 *  Skeleton for 'WaiterTableView.fxml' Controller Class
 */

/**
* @author emil
*/

import java.net.URL;
import java.sql.SQLException;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.ToggleButton;

public class WaiterTableViewController {

  @FXML // ResourceBundle that was given to the FXMLLoader
  private ResourceBundle resources;

  @FXML // URL location of the FXML file that was given to the FXMLLoader
  private URL location;

  @FXML
  private ListView<String> deliverList;
  ObservableList<String> deliver;
  
  @FXML
  private ListView<String> otherDeliverList;
  ObservableList<String> otherDeliver;
  
  @FXML
  private ListView<String> otherWaiterCallList;
  ObservableList<String> otherWaiterCall;
  
  @FXML
  private ListView<String> waiterCallList;
  ObservableList<String> waiterCall;

  @FXML // fx:id="back"
  private Button back; // Value injected by FXMLLoader

  @FXML // This method is called by the FXMLLoader when initialization is complete
  void initialize() {
	  
	  
    back.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        try {
          ViewManager.getInstance().showWaiterHome();
        } catch (SQLException e) {
          e.printStackTrace();
        }
      }
    });
    
    setupReady();
    setupCalls();
  }
  
  public void setupReady(){
	  otherDeliverList.setEditable(true);
	  otherDeliver = FXCollections.observableArrayList();
	  
	  deliverList.setEditable(true);
	  deliver = FXCollections.observableArrayList();
	  
	  for(int i : Model.getModel().getDatabase().getWaiterReadyCJBIDS()){
		  Date d = new Date(); 
//		  if(){ //get assigned tables //TODO
		  deliver.add("#:" + i+"   "+OrderStatusTime.differenceInMins(d.getTime(), Model.getModel().getDatabase().getReadyTimeCalled(i))+"mins ago");
//		  }else{
		  otherDeliver.add("#:" + i+"   "+OrderStatusTime.differenceInMins(d.getTime(), Model.getModel().getDatabase().getReadyTimeCalled(i))+"mins ago");
//		  }
	  }
	  
	  otherDeliverList.setItems(otherDeliver);
	  deliverList.setItems(deliver);
  }
  
  public void setupCalls(){
	  otherWaiterCallList.setEditable(true);
	  otherWaiterCall = FXCollections.observableArrayList();
	  
	  waiterCallList.setEditable(true);
	  waiterCall = FXCollections.observableArrayList();
	  
	  for(int i : Model.getModel().getDatabase().getCustomerWaiterCalls()){
	    	Date d = new Date(); 
		  //if(){ //get assigned tables //TODO
			  waiterCall.add("#:" + i+"   "+OrderStatusTime.differenceInMins(d.getTime(), Model.getModel().getDatabase().getTableNumberTimeCalled(i))+"mins ago");
		  //}else{
			  otherWaiterCall.add("#:" + i+"   "+OrderStatusTime.differenceInMins(d.getTime(), Model.getModel().getDatabase().getTableNumberTimeCalled(i))+"mins ago");
		 // }
	  }

	  waiterCallList.setItems(waiterCall);
	  otherWaiterCallList.setItems(otherWaiterCall);
  }
}
