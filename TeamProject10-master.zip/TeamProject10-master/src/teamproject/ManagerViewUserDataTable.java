package teamproject;

/**
 * @author emil
 */
import javafx.beans.property.SimpleStringProperty;

public class ManagerViewUserDataTable {



  private final SimpleStringProperty usernameUser;
  private final SimpleStringProperty usertype;
  private final SimpleStringProperty email;

  public ManagerViewUserDataTable(String usernameUser, String usertype, String email) {
    this.usernameUser = new SimpleStringProperty(usernameUser);
    this.usertype = new SimpleStringProperty(usertype);
    this.email = new SimpleStringProperty(email);

  }

  public String getUser() {
    return this.usernameUser.get();
  }

  public String getUserType() {
    return this.usertype.get();

  }

  public String getEmail() {
    return this.email.get();
  }
}

