package teamproject;

/**
 * TODO JAVADOCS
 * 
 * @author Callum
 */
public enum OrderStatus {
  ordering, ordered, underway, ready, delivered;

  /**
   * TODO JAVADOCS
   * 
   * @author Callum
   */
  public String toString() {
    if (this.equals(OrderStatus.ordered)) {
      return "ordered";
    } else if (this.equals(OrderStatus.underway)) {
      return "underway";
    } else if (this.equals(OrderStatus.ready)) {
      return "ready";
    } else if (this.equals(OrderStatus.delivered)) {
      return "delivered";
    } else if (this.equals(OrderStatus.ordering)) {
      return "ordering";
    }
    return null;
  }

  /**
   * TODO JAVADOCS
   * 
   * @author Callum
   */
  public static OrderStatus toOrderStatus(String s) {
    if (s == null) {
      return null;
    }

    if (s.equals("ordered")) {
      return OrderStatus.ordered;
    } else if (s.equals("underway")) {
      return OrderStatus.underway;
    } else if (s.equals("ready")) {
      return OrderStatus.ready;
    } else if (s.equals("delivered")) {
      return OrderStatus.delivered;
    } else if (s.equals("ordering")) {
      return OrderStatus.ordering;
    }
    return null;
  }
}
