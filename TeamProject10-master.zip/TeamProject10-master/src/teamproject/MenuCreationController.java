package teamproject;

/**
*@author emil
*/

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class MenuCreationController {

  @FXML // ResourceBundle that was given to the FXMLLoader
  private ResourceBundle resources;

  @FXML // URL location of the FXML file that was given to the FXMLLoader
  private URL location;

  @FXML // fx:id="back"
  private Button back; // Value injected by FXMLLoader

  @FXML // fx:id="addMU"
  private Button addMU; // Value injected by FXMLLoader

  @FXML // fx:id="addIng"
  private Button addIng; // Value injected by FXMLLoader

  @FXML // fx:id="delIng"
  private Button delIng; // Value injected by FXMLLoader

  @FXML // fx:id="addIng"
  private Button addCat; // Value injected by FXMLLoader

  @FXML // fx:id="delIng"
  private Button delCat; // Value injected by FXMLLoader

  @FXML
  private ListView<String> availableIngredientsList = new ListView<String>();

  @FXML
  private ListView<String> selectedIngredientsList = new ListView<String>();

  @FXML
  private ListView<String> availableCategoriesList = new ListView<String>();

  @FXML
  private ListView<String> selectedCategoriesList = new ListView<String>();

  @FXML
  private TextField name;

  @FXML
  private TextField url;

  @FXML
  private TextField price;

  ObservableList<String> availableIngredients;
  ObservableList<String> selectedIngredients;
  ObservableList<String> availableCategories;
  ObservableList<String> selectedCategories;

  static MenuItem modding;

  @FXML // This method is called by the FXMLLoader when initialization is complete
  void initialize() {
    back.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        ViewManager.getInstance().showManagerView();
      }
    });

    addIng.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (selectedAvailableIng != null) {
          selectedIngredients.add(selectedAvailableIng);
          selectedIngredientsList.setItems(selectedIngredients);
        }
      }
    });

    delIng.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (selectedSelectedIng != null) {
          selectedIngredients.remove(selectedSelectedIng);
          selectedIngredientsList.setItems(selectedIngredients);
        }
      }
    });

    addCat.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (selectedAvailableCat != null && !selectedCategories.contains(selectedAvailableCat)) {
          selectedCategories.add(selectedAvailableCat);
          selectedCategoriesList.setItems(selectedCategories);
        }
      }
    });

    delCat.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (selectedSelectedCat != null) {
          selectedCategories.remove(selectedSelectedCat);
          selectedCategoriesList.setItems(selectedCategories);
        }
      }
    });

    addMU.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        MenuItem newItem = new MenuItem(name.getText(), url.getText(),
            Integer.parseInt(price.getText()), constructIngredientArray(),
            constructCategoryArray());
        
        if(modding != null){
        	Model.getModel().getDatabase().modifyMenuItemInMenuItemsCJB(modding, newItem);
        }else{
        	Model.getModel().getDatabase().addMenuItemToMenuItemsCJB(newItem);
        }
        
        Alert a = new Alert(AlertType.INFORMATION);
        a.setTitle("REGISTERED!");
        a.setHeaderText(null);
        a.setContentText("MenuItem added to database!");
        a.showAndWait();

        // reload page
        MenuCreationController.modding = null;
        ViewManager.getInstance().showMenuCreation();

      }
    });

    setupAvailableIngredients();
    setupSelectedIngredients();
    setupAvailableCategories();
    setupSelectedCategories();

    if (modding != null) {
      name.setText(modding.getName());
      url.setText(modding.getImageURL());
      price.setText(""+modding.getPrice());

      selectedIngredients = FXCollections.observableArrayList();
      selectedIngredientsList.setEditable(true);
      for (Ingredient i : modding.getIngredients()) {
        selectedIngredients.add(i.getName());
      }
      selectedIngredientsList.setItems(selectedIngredients);

      selectedCategories = FXCollections.observableArrayList();
      selectedCategoriesList.setEditable(true);
      for (Category c : modding.getCatergories()) {
        selectedCategories.add(c.toString());
      }
      selectedCategoriesList.setItems(selectedCategories);
    }
  }

  public void setupAvailableCategories() {
    availableCategories = FXCollections.observableArrayList();
    availableCategoriesList.setEditable(true);

    for (Category cat : Category.values()) {
      availableCategories.add(cat.toString());
    }

    availableCategoriesList.setItems(availableCategories);
  }

  public void setupSelectedCategories() {
    selectedCategories = FXCollections.observableArrayList();
    selectedCategoriesList.setEditable(true);
    selectedCategoriesList.setItems(selectedCategories);
  }

  public void setupAvailableIngredients() {
    availableIngredients = FXCollections.observableArrayList();
    availableIngredientsList.setEditable(true);

    for (Ingredient ing : Model.getModel().getDatabase().getAllIngredients()) {
      availableIngredients.add(ing.getName());
    }

    availableIngredientsList.setItems(availableIngredients);
  }

  public void setupSelectedIngredients() {
    selectedIngredients = FXCollections.observableArrayList();
    selectedIngredientsList.setEditable(true);
    selectedIngredientsList.setItems(selectedIngredients);
  }

  public Category[] constructCategoryArray() {
    ArrayList<Category> returning = new ArrayList<Category>();

    for (String s : selectedCategories) {
      returning.add(Category.toCategory(s));
    }

    Category[] returning2 = new Category[returning.size()];
    for (int i = 0; i < returning2.length; i++) {
      returning2[i] = returning.get(i);
    }

    return returning2;
  }

  public Ingredient[] constructIngredientArray() {
    ArrayList<Ingredient> returning = new ArrayList<Ingredient>();

    for (String s : selectedIngredients) {
      returning.add(getIngredientByName(s));
    }

    Ingredient[] returning2 = new Ingredient[returning.size()];
    for (int i = 0; i < returning2.length; i++) {
      returning2[i] = returning.get(i);
    }

    return returning2;
  }

  public Ingredient getIngredientByName(String ing) {
    Ingredient ingr = null;
    for (Ingredient i : Model.getModel().getDatabase().getAllIngredients()) {
      if (ing.equals(i.getName())) {
        ingr = i;
      }
    }
    return ingr;
  }

  String selectedSelectedIng = null;
  String selectedAvailableIng = null;
  String selectedSelectedCat = null;
  String selectedAvailableCat = null;

  public void availableIngredientsController() {
    selectedAvailableIng = availableIngredientsList.getSelectionModel().getSelectedItem();
  }

  public void selectedIngredientsController() {
    selectedSelectedIng = selectedIngredientsList.getSelectionModel().getSelectedItem();
  }

  public void selectedCategoriesController() {
    selectedSelectedCat = selectedCategoriesList.getSelectionModel().getSelectedItem();
  }

  public void availableCategoriesController() {
    selectedAvailableCat = availableCategoriesList.getSelectionModel().getSelectedItem();
  }

}
