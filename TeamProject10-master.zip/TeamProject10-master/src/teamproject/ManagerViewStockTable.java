package teamproject;

import javafx.beans.property.SimpleStringProperty;

public class ManagerViewStockTable {
  private final SimpleStringProperty name;
  private final SimpleStringProperty level;

  public ManagerViewStockTable(String name, String level) {
    this.name = new SimpleStringProperty(name);
    this.level = new SimpleStringProperty(level);
  }

  public String getName() {
    return this.name.get();
  }

  public String getLevel() {
    return this.level.get();
  }

}
