package teamproject;

/**
 * A Allergy class is used as a attribute of an Ingredient class instance. To hold allergy
 * information about the ingredient. Which in the menuItem all Ingredient attributes of the menuItem
 * will have their allergies accumulated to give the customer the needed Allergy information about
 * the MenuItem. <br>
 * 
 * @author Callum
 */
public enum Allergy {
  Milk, Egg, Wheat, Nut, Fish, Shellfish;

  /**
   * Returns a debug string for the current Enum instance. Which representatives the value the Enum
   * holds. Passing this debug string to Allergy.toAllergy(debugString) will return an Enum from
   * which this debug string was created and has the corresponds values off.<br>
   * <br>
   * <b>Therefore:</b><br>
   * Allergy.test1 == Allergy.toAllergy(Allergy.test1.toString()) <br>
   * 
   * @return <b>String</b><br>
   *         A debug string, representative of the Enum value.<br>
   * @author Callum
   */
  public String toString() {
    if (this.equals(Allergy.Milk)) {
      return "Milk";
    } else if (this.equals(Allergy.Egg)) {
      return "Egg";
    } else if (this.equals(Allergy.Wheat)) {
      return "Wheat";
    } else if (this.equals(Allergy.Nut)) {
      return "Nut";
    } else if (this.equals(Allergy.Fish)) {
      return "Fish";
    } else if (this.equals(Allergy.Shellfish)) {
      return "Shellfish";
    }

    return null;// will only ever be "" if we forget to add an enum to the elif's
  }

  /**
   * Is a function which takes an Allergy array and compiles a debug string containing the debug
   * string of each element in the array. It will begin the debug String with 'Allergies{' and end
   * it with '}'. Each debug String of each Allergy will be separated by a colon.<br>
   * <br>
   * <b>Therefore:</b><br>
   * Allergy[] alg = {Allergy.test1,Allergy.test2,Allergy.test3};<br>
   * alg == Allergy.toAllergyArray(Allergy.toString(alg));<br>
   * 
   * @param Allergy
   *          [] <br>
   *          The Allergy Array you wish to compile a debug String for.
   * @return <b>String</b><br>
   *         A debug String, containing debug info for each Allergy in the array.<br>
   *         <b>format:</b>Allergies{debugString,debugString....}
   * @author Callum
   */
  public static String toString(Allergy[] allergies) {
    if (allergies == null) {
      return null;
    }

    String returning = "Allergies{";
    // not using for each so know when to add the comma
    for (int i = 0; i < allergies.length; i++) {
      if (allergies[i] != null && allergies[i].toString() != null) {
        returning += allergies[i].toString();
        if (i != (allergies.length - 1)) {
          returning += ",";
        }
      }
    }
    return (returning += "}");
  }

  /**
   * Is a function which takes a String and converts the debug string back into the Allergy; the
   * debug string was created from. If the debug string can't be parsed back into a Allergy then it
   * will return null.<br>
   * <br>
   * <b>Therefore:</b><br>
   * Allergy.test1 == Allergy.toAllergy(Allergy.test1.toString())<br>
   * 
   * @param String
   *          <br>
   *          Allergy debug string you wish to convert back to an Allergy Enum.
   * @return <b>Allergy</b><br>
   *         Returns an Allergy Enum, which corresponds to the debug String. If one isn't found;
   *         returns null.
   * @author Callum
   */
  public static Allergy toAllergy(String stringToAllergy) {
    if (stringToAllergy == null) {
      return null;
    }

    if (stringToAllergy.equalsIgnoreCase("Milk")) {
      return Allergy.Milk;
    } else if (stringToAllergy.equalsIgnoreCase("Egg")) {
      return Allergy.Egg;
    } else if (stringToAllergy.equalsIgnoreCase("Fish")) {
      return Allergy.Fish;
    } else if (stringToAllergy.equalsIgnoreCase("Nut")) {
      return Allergy.Nut;
    } else if (stringToAllergy.equalsIgnoreCase("Shellfish")) {
      return Allergy.Shellfish;
    } else if (stringToAllergy.equalsIgnoreCase("Wheat")) {
      return Allergy.Wheat;
    }

    return null;
  }

  /**
   * Is a function which takes a String and converts the debug string, back into the Allergy Array
   * the debug string was created from. Will return null if it can't be parsed. Returned Arrays may
   * have elements which are null.<br>
   * <br>
   * <b>Therefore:</b><br>
   * Allergy[] alg = {Allergy.test1,Allergy.test2,Allergy.test3};<br>
   * alg == Allergy.toAllergyArray(Allergy.toString(alg));<br>
   * 
   * @param String
   *          <br>
   *          Allergy Array debug string you wish to convert back to a Allergy array.
   * @return <b>Allergy[]</b><br>
   *         Returns an Allergy Array which corresponds to the debug String input.
   * @author Callum
   */
  public static Allergy[] toAllergyArray(String stringToAllergyArray) {
    if (stringToAllergyArray == null) {
      return null;
    }

    if (stringToAllergyArray.length() < 11) {
      return null;
    } // wouldnt be able to sub first 10 and last 1

    if (!(stringToAllergyArray.startsWith("Allergies{"))) {
      return null;
    } // isnt an Allergy[] toString as doesnt start with 'Allergies{'

    // removes the Allergies{
    stringToAllergyArray = stringToAllergyArray.substring(10);
    // remove the last {
    stringToAllergyArray = stringToAllergyArray.substring(0, stringToAllergyArray.length() - 1);

    String[] splitStringToAllergyArray = stringToAllergyArray.split(",");
    Allergy[] returning = new Allergy[splitStringToAllergyArray.length];

    int pos = 0;
    for (int i = 0; i < splitStringToAllergyArray.length; i++) {
      Allergy temp = Allergy.toAllergy(splitStringToAllergyArray[i]);
      if (temp == null || temp.equals("")) {
      } else {
        returning[pos] = temp;
        pos++;
      }
    }

    return (resizeArray(returning, pos));
  }

  /**
   * A function which takes an array and resizes it to a smaller size. With the array you wish to
   * resized values.
   * 
   * @param resizing
   *          The array to resize to a smaller size.
   * @param to
   *          Size to resize the array to, should be smaller than resizing.length()
   * @return <b>Allergy[]</b> Resized array.
   * @Author Callum
   */
  public static Allergy[] resizeArray(Allergy[] resizing, int to) {
    if (to > resizing.length) {
      // incorrect usage
      return null;
    } else {
      Allergy returning[] = new Allergy[to];

      for (int i = 0; i < to; i++) {
        returning[i] = resizing[i];
      }

      return returning;
    }
  }
}
