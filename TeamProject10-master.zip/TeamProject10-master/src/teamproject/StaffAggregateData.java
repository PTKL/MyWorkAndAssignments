/**
 * 
 */
package teamproject;
import java.util.*;
/**
 * @author Anton Morev
 *
 */
public class StaffAggregateData {
	private int NumberOfOrders;
	private long AverageResponseTime;
	private String Name; 
	private String Surname;
	public static int nextID;
	private int ID;
	ArrayList<Long> ResponseTime = new ArrayList<Long>();
	
	//Constructor for new restaurant staff who dont yet have any data
	
	public StaffAggregateData(String Name, String Surname){
		this.Name = Name;
		this.Surname = Surname;
		this.ID = nextID++;
	}
	//Constructor for staff previously in the restaurant
	
	public StaffAggregateData(String Name, String Surname, int ID){
		this.Name = Name;
		this.Surname = Surname;
		this.ID = ID;
	}
	
	public void setNumberOfOrders(int n){
		this.NumberOfOrders= n;
	}
	
	public int getNumberOfOrders(){
		return this.NumberOfOrders;
	}
	
	
	public int getID(){
		return this.ID;
	}
	
	public void addResponseTime(Order o){
		long start;
		long end;
		long responseTime;
		
		start = o.getTimeOrderChanged(OrderStatus.ordered);
		end = o.getTimeOrderChanged(OrderStatus.underway);
		
		responseTime = end - start;
		
		this.ResponseTime.add(responseTime);
		
	}
	public void workoutAverageResponseTime(){
		long avg;
		long totalTime = 0;
		
		for(int i=0; i <= this.ResponseTime.size(); i++){
			totalTime = totalTime + this.ResponseTime.get(i);
		}
			
		avg = totalTime/this.ResponseTime.size();
		
		this.AverageResponseTime = avg;
	}

	public String getAverageResponseTime(){
		return ""+ this.AverageResponseTime;
	}
	
	public String toString(){
		return "Aggregate Data of "+ this.Name + " " + this.Surname + 
				"ID: "+ this.ID + "/n Number of orders:"+ this.NumberOfOrders
				+ "Average response time:"+ this.AverageResponseTime;
	}
	
	
}
