package teamproject;

import java.util.ArrayList;

/**
 * TODO javadocs
 * 
 * @author callum
 */
public class Order {
  public static int orderIdNext;
  private OrderStatus orderStatus;
  private MenuItem[] items;
  private int orderId;
  private int tableNumber;
  private String customer;
  private OrderStatusTime orderStatusTime;
  private boolean paid;

  // TODO order times

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public Order(MenuItem[] items, int tableNumber, String customer) {
    this.items = items;
    //as others might have ordered from when you set it
    Model.getModel().getDatabase().setOrderID();
    this.orderId = orderIdNext++;
    this.tableNumber = tableNumber;
    this.orderStatusTime = new OrderStatusTime();
    setOrderStatus(OrderStatus.ordering);
    this.customer = customer;
    this.paid = false;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public Order(MenuItem[] items, int tableNumber, String customer, int orderID,
      OrderStatusTime orderStatusTime, OrderStatus orderStatus, boolean paid) {
    this.items = items;
    this.orderId = orderID;
    this.tableNumber = tableNumber;
    this.orderStatus = orderStatus;
    this.orderStatusTime = orderStatusTime;
    this.customer = customer;
    this.paid = paid;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public MenuItem[] getMenuItems() {
    return this.items;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public void setPaid(boolean paid) {
    this.paid = paid;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public boolean getPaid() {
    return this.paid;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public OrderStatus getOrderStatus() {
    return this.orderStatus;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public void setOrderStatus(OrderStatus o) {
    this.orderStatusTime.setOrderStatusTime(o);
    this.orderStatus = o;
  }

  /**
   * TODO JAVADOCS
   * 
   * @author Anton
   */
  public OrderStatus NextStep() {
    if (this.getOrderStatus().equals(OrderStatus.ordering)) {
      setOrderStatus(OrderStatus.ordered);
      return OrderStatus.ordered;
    } else if (this.getOrderStatus().equals(OrderStatus.ordered)) {
      setOrderStatus(OrderStatus.underway);
      return OrderStatus.underway;
    } else if (this.getOrderStatus().equals(OrderStatus.underway)) {
      setOrderStatus(OrderStatus.ready);
      return OrderStatus.ready;
    } else if (this.getOrderStatus().equals(OrderStatus.ready)) {
      setOrderStatus(OrderStatus.delivered);
      return OrderStatus.delivered;
    } else if (this.getOrderStatus().equals(OrderStatus.delivered)) {
      return OrderStatus.delivered;
    }
    return null;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public long getTimeOrderChanged(OrderStatus o) {
    return this.orderStatusTime.getOrderStatusTime(o);
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public int getOrderID() {
    return this.orderId;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public void setOrderID(int i) {
    this.orderId = i;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public int getTableNumber() {
    return this.tableNumber;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public void setTableNumber(int i) {
    this.tableNumber = i;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  private int workoutPrice() {
    int price = 0;
    for (MenuItem m : this.items) {
      price += m.getPrice();
    }
    return price;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public int getPrice() {
    return workoutPrice();
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public String getCustomer() {
    return this.customer;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public void setCustomer(String customer) {
    this.customer = customer;
  }

  public void addMenuItem(MenuItem m) {
    MenuItem[] newItems = new MenuItem[this.items.length + 1];
    for (int i = 0; i < this.items.length; i++) {
      newItems[i] = items[i];
    }
    newItems[this.items.length] = m;
    this.items = newItems;
  }

  public void removeMenuItem(MenuItem m) {
    ArrayList<MenuItem> temp = new ArrayList<MenuItem>();
    for (MenuItem m2 : this.items) {
      temp.add(m2);
    }
    temp.remove(m);
    MenuItem[] newItems = new MenuItem[temp.size()];
    for (int i = 0; i < temp.size(); i++) {
      newItems[i] = temp.get(i);
    }
    this.items = newItems;
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public String toString() {
    return "Order{" + this.orderId + "," + orderStatus.toString() + "," + this.tableNumber + ","
        + this.customer + "," + this.paid + "," + this.orderStatusTime + ","
        + MenuItem.toString(items) + "}";
  }

  /**
   * TODO javadocs
   * 
   * @author callum
   */
  public static Order toOrder(String s) {
    if (s == null) {
      return null;
    }

    if (s.length() < 7) {
      return null;
    }

    if (!s.startsWith("Order{")) {
      return null;
    }

    s = s.substring(6);
    s = s.substring(0, s.length() - 1);

    String splitString[] = s.split("MenuItems");
    String menuItems = null;
    if (splitString.length > 1) {
      menuItems = "MenuItems" + splitString[1];
    }

    // remove ,
    s = splitString[0].substring(0, splitString[0].length() - 1);

    String splitString2[] = s.split("OrderStatusTime");
    String orderStatusTime = null;
    if (splitString2.length > 1) {
      if (splitString.length == 1) {
        splitString2[1] = splitString2[1].substring(0, splitString2[1].length() - 4);
      }
      orderStatusTime = "OrderStatusTime" + splitString2[1];
    }

    s = splitString2[0].substring(0, splitString2[0].length() - 1);
    String splitString3[] = s.split(",");

    Order returning = new Order(MenuItem.toMenuItemArray(menuItems),
        Integer.parseInt(splitString3[2]), splitString3[3], Integer.parseInt(splitString3[0]),
        OrderStatusTime.toOrderStatusTime(orderStatusTime),
        OrderStatus.toOrderStatus(splitString3[1]), Boolean.parseBoolean(splitString3[4]));

    return returning;
  }

  /**
   * TODO
   * 
   * @author Callum
   */
  @Override
  public boolean equals(Object obj) {
    if (obj instanceof Order) {
      Order o = (Order) obj;
      if (this.orderId == o.orderId) {
        return true;
      }
    }

    return false;
  }

  /**
   * TODO
   * 
   * @author Callum
   */
  @Override
  public int hashCode() {
    return (this.orderId);
  }

  /**
   * TODO
   * 
   * @param i
   * @return
   */
  public int compareTo(Order o) {
    return (this.orderId - o.orderId);
  }
}
