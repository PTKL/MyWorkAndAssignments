package teamproject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Optional;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class PaymentController {

  @FXML
  private ListView<String> orderSummaryListLeft = new ListView<String>();;

  @FXML
  private TextField cardholderName;

  @FXML
  private TextField cardNumber;

  @FXML
  private TextField securityCode;

  @FXML
  private ChoiceBox<String> choiceMonth;

  @FXML
  private ChoiceBox<String> choiceYear;

  @FXML
  private AnchorPane paymentAnchor;

  @FXML
  private Button cancelBtn;

  @FXML
  private Text requiredName;

  @FXML
  private Text requiredCardNum;

  @FXML
  private Text requiredSec;

  @FXML
  private Text requiredExp;

  @FXML
  private Text orderTotalPrice;

  final ObservableList<String> observableSummaryOrders = FXCollections.observableArrayList();
  final ObservableList<String> observableSummaryItems = FXCollections.observableArrayList();

  public static Order o;

  Stage stage;

  NumberFormat formatter = new DecimalFormat("#0.00");

  void initialize() {

    stage = (Stage) paymentAnchor.getScene().getWindow();
    stage.setHeight(425);
    stage.setWidth(575);

    choiceMonth.setItems(FXCollections.observableArrayList("01", "02", "03", "04", "05", "06", "07",
        "08", "09", "10", "11", "12"));
    choiceYear.setItems(
        FXCollections.observableArrayList("2016", "2017", "2018", "2019", "2020", "2021", "2022"));
    addTextLimiter(cardNumber, 16);
    addTextLimiter(securityCode, 3);

    /*
     * for (MenuItem item : summaryArray) { observableSummaryItems.add(item.getName()); price +=
     * item.getPrice(); } orderSummaryListRight.setItems(observableSummaryItems);
     */
    double price = o.getPrice();
    for (MenuItem m : o.getMenuItems()) {
      observableSummaryOrders.add(m.getName());
    }

    orderSummaryListLeft.setItems(observableSummaryOrders);
    orderTotalPrice.setText("�" + String.valueOf(formatter.format(price)));

    cancelBtn.setOnAction(new EventHandler<ActionEvent>() {

      @Override
      public void handle(ActionEvent event) {
        ViewManager.getInstance().showCustomerHome();
      }

    });

  }

  public void submitBtnController() {
    if (checkName() && checkCardNumber() && checkSec() && checkExpDate()) {
      Alert alert = new Alert(AlertType.INFORMATION);
      alert.setTitle("Payment Successful!");
      alert.setHeaderText(null);
      alert.setContentText("The Payment was successful!");

      Model.getModel().getDatabase().removeOrderFromOrderCJB(o);
      o.setPaid(true);
      Model.getModel().getDatabase().addOrderToOrderCJB(o);

      Optional<ButtonType> result = alert.showAndWait();
      if (result.get() == ButtonType.OK) {
        ViewManager.getInstance().showCustomerHome();
      }
    }
    if (!checkName()) {
      Alert alert = new Alert(AlertType.ERROR);
      alert.setTitle("Name");
      alert.setHeaderText("Card rejected");
      alert.setContentText("Please check if the name is correct!");

      alert.showAndWait();
    }
    if (!checkCardNumber()) {
      Alert alert = new Alert(AlertType.ERROR);
      alert.setTitle("Card number");
      alert.setHeaderText("Card number rejected");
      alert.setContentText("Please check if the card number is correct!");

      alert.showAndWait();
    }
    if (!checkSec()) {
      Alert alert = new Alert(AlertType.ERROR);
      alert.setTitle("Security code");
      alert.setHeaderText("Security code rejected");
      alert.setContentText("Please check if the security code is correct!");

      alert.showAndWait();
    }
    if (!checkExpDate()) {
      Alert alert = new Alert(AlertType.ERROR);
      alert.setTitle("Expiry date");
      alert.setHeaderText("Empty Expiry date");
      alert.setContentText("Please check if the expiry date is correct!");

      alert.showAndWait();
    }
  }

  public boolean checkName() {
    String name = cardholderName.getText();
    if (name.matches("[a-zA-Z\\s\'\"]+")) {
      return true;
    } else {
      requiredName.setText("* required");
      return false;
    }
  }

  public boolean checkCardNumber() {
    String num = cardNumber.getText();
    if (num.matches("[0-9]+")) {
      // test reject cardNumber
      if (num.equals("9999999999999999")) {
        return false;
      }
      return true;
    } else {
      requiredCardNum.setText("* required");
      return false;
    }
  }

  public boolean checkSec() {
    String secCode = securityCode.getText();
    if (secCode.matches("[0-9]+")) {
      // test reject security code
      if (secCode.equals("111")) {
        return false;
      }
      return true;
    } else {
      requiredSec.setText("* required");
      return false;
    }
  }

  public boolean checkExpDate() {
    if (choiceYear.getValue() != null && choiceMonth.getValue() != null) {
      return true;
    } else {
      requiredExp.setText("* required");
      return false;
    }
  }

  public static void addTextLimiter(final TextField tf, final int maxLength) {
    tf.textProperty().addListener(new ChangeListener<String>() {
      @Override
      public void changed(final ObservableValue<? extends String> ov, final String oldValue,
          final String newValue) {
        if (tf.getText().length() > maxLength) {
          String s = tf.getText().substring(0, maxLength);
          tf.setText(s);
        }
      }
    });
  }

  // WIP Only letter limiter
  /*
   * public static void addOnlyLetterLimiter(final TextField tf) { tf.textProperty().addListener(new
   * ChangeListener<String>() {
   * 
   * @Override public void changed(final ObservableValue<? extends String> ov, final String
   * oldValue, final String newValue) { if (!tf.getText().matches("[a-zA-Z\\s\'\"]+")) { String s =
   * null; char[] ch = tf.getText().toCharArray(); for (char c : ch) { if(!Character.isLetter(c)){
   * ch. } } tf.setText(s); } } }); }
   */

}
