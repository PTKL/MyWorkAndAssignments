package teamproject;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class AddIngredientViewController {

	// background
	@FXML
	private ResourceBundle resources;
	@FXML
	private URL location;

	// scene objects (match fx:id's in AddIngredientView.fxml)
	@FXML
	private TextField ingredientTextField;
	@FXML
	private TextField costTextField;
	@FXML
	private TextField caloryTextField;
	@FXML
	private CheckBox nutsCheckbox;
	@FXML
	private CheckBox wheatCheckbox;
	@FXML
	private CheckBox eggCheckbox;
	@FXML
	private CheckBox fishCheckbox;
	@FXML
	private CheckBox shellfishCheckbox;
	@FXML
	private Button backButton;
	@FXML
	private Button addButton;

	public int calculateArraySize() {
		int arraySize = 0;
		if (nutsCheckbox.equals(true)) {
			arraySize++;
		}
		if (wheatCheckbox.equals(true)) {
			arraySize++;
		}
		if (eggCheckbox.equals(true)) {
			arraySize++;
		}
		if (fishCheckbox.equals(true)) {
			arraySize++;
		}
		if (shellfishCheckbox.equals(true)) {
			arraySize++;
		}

		return arraySize;
	}

	public Allergy[] createAllergyArray() {
		Allergy[] allergies = new Allergy[calculateArraySize()];
		int i = 0;
		if (nutsCheckbox.equals(true)) {
			allergies[i++] = Allergy.Nut;
		}
		if (wheatCheckbox.equals(true)) {
			allergies[i++] = Allergy.Wheat;
		}
		if (eggCheckbox.equals(true)) {
			allergies[i++] = Allergy.Egg;
		}
		if (fishCheckbox.equals(true)) {
			allergies[i++] = Allergy.Fish;
		}
		if (shellfishCheckbox.equals(true)) {
			allergies[i++] = Allergy.Shellfish;
		}
		return allergies;

	}

	public boolean checkParsing() {
		boolean parseSuccess = true;
		try {
			Integer.parseInt(costTextField.getText());
		} catch (NumberFormatException nfe) {
			parseSuccess = false;
		}
		return parseSuccess;

	}

	static Ingredient modding;

	public void initialize() {
		if (modding != null) {
			costTextField.setText("" + modding.getCost());
			ingredientTextField.setText(modding.getName());			
			caloryTextField.setText("" + modding.getCalories());

			ArrayList<Allergy> temp = new ArrayList<Allergy>();
			for (Allergy a : modding.getAllergies()) {
				temp.add(a);
			}

			if (temp.contains(Allergy.Nut)) {
				nutsCheckbox.setSelected(true);
			}
			if (temp.contains(Allergy.Wheat)) {
				wheatCheckbox.setSelected(true);
			}
			if (temp.contains(Allergy.Egg)) {
				eggCheckbox.setSelected(true);
			}
			if (temp.contains(Allergy.Fish)) {
				fishCheckbox.setSelected(true);
			}
			if (temp.contains(Allergy.Shellfish)) {
				shellfishCheckbox.setSelected(true);
			}
		}

		backButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				ViewManager.getInstance().showManagerView();
			}
		});

		addButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {

				boolean parseSuccess = true;
				try {
					Integer.parseInt(costTextField.getText());
				} catch (NumberFormatException nfe) {
					parseSuccess = false;
				}

				if (parseSuccess == false) {
					costTextField.setText("Number could not be translated...");
				}

				else if (ingredientTextField.getText() == "") {
					ingredientTextField.setText("Ingredient must be given a name to be created...");
				}

				else {
					Allergy[] allergies = new Allergy[calculateArraySize()];
					int i = 0;

					if (nutsCheckbox.equals(true)) {
						allergies[i++] = Allergy.Nut;
					}
					if (wheatCheckbox.equals(true)) {
						allergies[i++] = Allergy.Wheat;
					}
					if (eggCheckbox.equals(true)) {
						allergies[i++] = Allergy.Egg;
					}
					if (fishCheckbox.equals(true)) {
						allergies[i++] = Allergy.Fish;
					}
					if (shellfishCheckbox.equals(true)) {
						allergies[i++] = Allergy.Shellfish;
					}
					Ingredient ingredient = new Ingredient(ingredientTextField.getText(),
							Integer.parseInt(costTextField.getText()), Integer.parseInt(caloryTextField.getText()),
							allergies);

					if (modding != null) {
						int stock = Model.getModel().getDatabase().getIngredientStockLevel(modding);
						Model.getModel().getDatabase().modifyIngredientInIngredientsCJB(modding, ingredient);
						Model.getModel().getDatabase().setIngredientStockLevel(stock, ingredient);
					} else {
						Model.getModel().getDatabase().addIngredientToIngredientCJB(ingredient);
					}
					
			        Alert a = new Alert(AlertType.INFORMATION);
			        a.setTitle("REGISTERED!");
			        a.setHeaderText(null);
			        a.setContentText("Ingredient added to database!");
			        a.showAndWait();

			        // reload page
			        AddIngredientViewController.modding = null;
			        ViewManager.getInstance().showAddIngredient();
				}
			}
		});

	}

}
