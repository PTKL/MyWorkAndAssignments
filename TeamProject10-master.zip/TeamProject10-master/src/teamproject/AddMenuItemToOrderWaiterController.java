package teamproject;

import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * This class is used by the waiter to modify already ordered items before
 * confirming them. It is opened by pressing add MenuItem to Order. It will
 * respond with alert message if there are no orders. This class heavily
 * interacts with the database. It is also responsible for calculating
 * additional sales of the waiter.
 * 
 * @see MenuItem
 * @see Order
 * @see sqlJDBC
 * @see WaiterOrderViewController
 * 
 */
public class AddMenuItemToOrderWaiterController implements Initializable {

  @FXML
  private AnchorPane mainAnchorWaiter;

  @FXML
  private Button backBtn;

  /** ListView of MenuItems used in FXML, it consists of Strings. */
  @FXML
  private ListView<String> menuItemsList = new ListView<String>();
  /**
   * ObservableList used to be set as a model for menuItemsList, also consists
   * of Strings.
   */
  ObservableList<String> menuItems;

  /** ListView of orders used in FXML, it consists of Strings */
  @FXML
  private ListView<String> orderListWaiter = new ListView<String>();
  /**
   * ObservableList used to be set as a model for orderListWaiter, also consists
   * of Strings
   */
  ObservableList<String> orderItemsWaiter;

  /** ArrayList of MenuItem, it displays all the items that are available */
  ArrayList<MenuItem> allMenuItemsArrayWaiter;

  /** stage of the waiter */
  Stage stageWaiter;
  /** Selected item from menu that waiter can add or remove from the order */
  MenuItem selectedItemWaiter;
  /** order that will be used to modify the Order from previous view */
  Order orderWaiter;
  /** Order that is taken from previous view in order to modify */
  public static Order changeOrderWaiter;
  /** Total additional sales amount */
  static int totalSales = 0;


  /**
   * Initializes the stage, Gets menu items from the order, orderItemsWaiter is
   * populated. Menu is setUp etc.
   */
  public void initialize() {

    stageWaiter = (Stage) mainAnchorWaiter.getScene().getWindow();
    stageWaiter.setHeight(625);
    stageWaiter.setWidth(810);

    allMenuItemsArrayWaiter = Model.getModel().getDatabase().getAllMenuItems();
    orderItemsWaiter = FXCollections.observableArrayList();
    // order should be equal to one chosen from the (WaiterHomeView)
    orderWaiter = changeOrderWaiter;

    for (MenuItem mItem : orderWaiter.getMenuItems()) {
      orderItemsWaiter.add(mItem.getName());
    }
    orderListWaiter.setItems(orderItemsWaiter);
    setupMenuInWaiter();
  }

  /**
   * populate the menu ListView and display it in user friendly manner
   */
  public void setupMenuInWaiter() {
    menuItemsList.setEditable(true);
    menuItems = FXCollections.observableArrayList();

    for (MenuItem item : allMenuItemsArrayWaiter) {
      if (StockRoom.getInstance().haveIngredients(item)) {
        Category[] category = item.getCatergories();
        menuItems.add(item.getName() + ">>>>>>> " + category[0]);
      }
    }

    menuItemsList.setItems(menuItems);
  }


  /**
   * Controller for the list displayed in the menu ListView, It checks if item
   * was selected, so that it can be added to the orderItemsWaiter and displayed
   * in orderListWaiter
   */
  public void menuItemsWaiterListViewController() {
    if (menuItemsList.getSelectionModel().getSelectedIndex() != -1) {
      String targetItem = menuItemsList.getSelectionModel().getSelectedItem();
      selectedItemWaiter = getItemByName(targetItem);
    } else {
      selectedItemWaiter = null;
      Alert alert = new Alert(AlertType.INFORMATION);
      alert.setTitle("Nothing chosen!");
      alert.setHeaderText(null);
      alert.setContentText("Choose Something!");
      alert.showAndWait();
    }

  }

  /**
   * Controller for the List displayed in the order ListView, It checks if item
   * was selected, so that proper item will be removed from it.
   */
  public void ordersWaiterListViewController() {
    if (orderListWaiter.getSelectionModel().getSelectedIndex() != -1) {
      String targetItemWaiter = orderListWaiter.getSelectionModel().getSelectedItem();
      selectedItemWaiter = getItemByName(targetItemWaiter);
    } else {
      selectedItemWaiter = null;
      Alert alert = new Alert(AlertType.INFORMATION);
      alert.setTitle("Nothing chosen!");
      alert.setHeaderText(null);
      alert.setContentText("Choose Something From Order!");
      alert.showAndWait();
    }
  }

  /**
   * Updates the database to insert order that was deleted, when changing to
   * this view then Returns back to WaiterOrderView
   */
  public void backToOrdersWaiterBtnController() {
    Model.getModel().getDatabase().addOrderToOrderCJB(orderWaiter);
    ViewManager.getInstance().showWaiterOrder();
  }

  /**
   * Controller for add to order button it adds MenuItems to order ListView and
   * updates the database accordingly. Also cost is added to totalSales
   */
  public void addToOrderWaiterBtnController() {
    // adding selected MenuItem to the Order
    if (orderWaiter.getMenuItems().length != 0) {
      StockRoom.getInstance().update();
      try {
      StockRoom.getInstance().unreserveIngredients(orderWaiter);
      } catch (NullPointerException npe) {
        System.out
            .println(
                "\nThere was a null pointer exception, while adding. Reason might be no item was chosen");
        npe.printStackTrace();
      }
      Model.getModel().getDatabase().removeOrderFromOrderReservationCJB(orderWaiter);
    }
    if (selectedItemWaiter != null) {
    orderItemsWaiter.add(selectedItemWaiter.getName());
    orderWaiter.addMenuItem(selectedItemWaiter);
    StockRoom.getInstance().reserveIngredients(orderWaiter);
    Model.getModel().getDatabase().addOrderToOrderReservationCJB(orderWaiter);
    StockRoom.getInstance().update();
    orderListWaiter.setItems(orderItemsWaiter);
      totalSales = totalSales + selectedItemWaiter.getPrice();
    } else {
      Alert alert = new Alert(AlertType.INFORMATION);
      alert.setTitle("MenuItem should be Selected!");
      alert.setHeaderText(null);
      alert.setContentText("Choose Something From Menu to add to the Order!");
      alert.showAndWait();
    }
  }

  /**
   * Controller for remove from order button it removes MenuItems from order
   * ListView and updates the database accordingly. Also cost is subtracted from
   * totalSales
   */
  public void removeFromOrderWaiterBtnController() {
    StockRoom.getInstance().update();
    try {
      StockRoom.getInstance().unreserveIngredients(orderWaiter);
    } catch (NullPointerException npe) {
      System.out
          .println(
              "\nThere was a null pointer exception while removing reason, no item was chosen");
    }
    Model.getModel().getDatabase().removeOrderFromOrderReservationCJB(orderWaiter);
    orderItemsWaiter.remove(selectedItemWaiter.getName());
    orderWaiter.removeMenuItem(selectedItemWaiter);
    if (orderWaiter.getMenuItems().length != 0) {
      StockRoom.getInstance().reserveIngredients(orderWaiter);
      Model.getModel().getDatabase().addOrderToOrderReservationCJB(orderWaiter);
      totalSales = totalSales - selectedItemWaiter.getPrice();
    } else if (selectedItemWaiter == null) {
      Alert alert = new Alert(AlertType.INFORMATION);
      alert.setTitle("MenuItem should be Selected!");
      alert.setHeaderText(null);
      alert.setContentText("Choose Something From Order to Remove it");
      alert.showAndWait();
    } else {
      Alert alert = new Alert(AlertType.INFORMATION);
      alert.setTitle("Nothing can be removed!");
      alert.setHeaderText(null);
      alert.setContentText("Choose Something From Order!");
      alert.showAndWait();
    }
    StockRoom.getInstance().update();

    orderListWaiter.setItems(orderItemsWaiter);
  }

  public void saveModifiedOrderWaiterBtnController() {
    Model.getModel().getDatabase().addOrderToOrderCJB(orderWaiter);
    ViewManager.getInstance().showWaiterOrder();
  }

  /**
   * Returns MenuItem, by the name that was selected from ListViews.
   * 
   * @param itemName
   *          From ListView String is selected
   * @return corresponding MenuItem is returned
   */
  public MenuItem getItemByName(String itemName) {
    MenuItem item = null;
    String realName;
    if (itemName.contains(">")) {
      realName = itemName.substring(0, itemName.indexOf(">"));
    }
    else {
      realName = itemName;
    }
    for (MenuItem mItem : allMenuItemsArrayWaiter) {
      if (realName.equals(mItem.getName())) {
        item = mItem;
      }
    }
    return item;
  }

  /**
   * 
   * @return returns 10% of totalSales, which is cost of every item added by the
   *         waiter
   */
  public static int getTotalSales() {
    return (int) (totalSales / 10);
  }

  @Override
  /** Inherited method that does nothing except keeping errors away */
  public void initialize(URL location, ResourceBundle resources) {
    // TODO Auto-generated method stub

  }


}
