package teamproject;

import java.util.HashMap;

public class IngredientReservation {
  public MenuItem[] menuitems;
  HashMap<Ingredient, Integer> reserved;
  public int orderID;

  public IngredientReservation(Order o) {
    this.reserved = new HashMap<Ingredient, Integer>();
    this.menuitems = o.getMenuItems();

    for (MenuItem m : menuitems) {
      for (Ingredient i : m.getIngredients()) {
        if (reserved.containsKey(i)) {
          reserved.put(i, (reserved.get(i) + 1));
        } else {
          reserved.put(i, 1);
        }
      }
    }
  }
}
