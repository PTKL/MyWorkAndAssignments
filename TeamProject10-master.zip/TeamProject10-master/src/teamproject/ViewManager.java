package teamproject;

import java.io.IOException;
import java.sql.SQLException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class ViewManager {
  private static ViewManager instance;
  private static Scene scene;

  private ViewManager() {

  }

  public static ViewManager getInstance() {
    if (instance == null) {
      instance = new ViewManager();
    }

    return instance;
  }

  public void setScene(Scene scene) {
    ViewManager.scene = scene;
  }

  public void showEmailView() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("EmailView.fxml"));
      scene.setRoot((Parent) loader.load());
      EmailViewController controller = loader.<EmailViewController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }
  
  public void showSignUp() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("SignUpScreen.fxml"));
      scene.setRoot((Parent) loader.load());
      SignUpScreenController controller = loader.<SignUpScreenController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showCustomerHome() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("CustomerHomeView.fxml"));
      scene.setRoot((Parent) loader.load());
      CustomerHomeViewController controller = loader.<CustomerHomeViewController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showAddMenuItemToOrder() {
    try {
      FXMLLoader loader = new FXMLLoader(
          getClass().getResource("AddMenuItemToOrderWaiter.fxml"));
      scene.setRoot((Parent) loader.load());
      AddMenuItemToOrderWaiterController controller = loader
          .<AddMenuItemToOrderWaiterController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showAddAccount() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("AddAccount.fxml"));
      scene.setRoot((Parent) loader.load());
      AddAccountController controller = loader.<AddAccountController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showKitchenHome() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("KitchenHomeView.fxml"));
      scene.setRoot((Parent) loader.load());
      KitchenHomeViewController controller = loader.<KitchenHomeViewController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showLoginScreen() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("LoginScreen.fxml"));
      scene.setRoot((Parent) loader.load());
      LoginScreenController controller = loader.<LoginScreenController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showManagerView() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("ManagerView.fxml"));
      scene.setRoot((Parent) loader.load());
      ManagerViewController controller = loader.<ManagerViewController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showMenuCreation() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuCreation.fxml"));
      scene.setRoot((Parent) loader.load());
      MenuCreationController controller = loader.<MenuCreationController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showMenuView() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuView.fxml"));
      scene.setRoot((Parent) loader.load());
      MenuViewController controller = loader.<MenuViewController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showOrderInformation() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("OrderInformation.fxml"));
      scene.setRoot((Parent) loader.load());
      OrderInformationController controller = loader.<OrderInformationController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showTableInfo() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("TableInfoView.fxml"));
      scene.setRoot((Parent) loader.load());
      TableInfoViewController controller = loader.<TableInfoViewController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showTableList() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("TableList.fxml"));
      scene.setRoot((Parent) loader.load());
      TableListController controller = loader.<TableListController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showWaiterTable() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("WaiterTableView.fxml"));
      scene.setRoot((Parent) loader.load());
      WaiterTableViewController controller = loader.<WaiterTableViewController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showWaiterHome() throws SQLException {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("WaiterHomeView.fxml"));
      scene.setRoot((Parent) loader.load());
      WaiterHomeViewController controller = loader.<WaiterHomeViewController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showWaiterOrder() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("WaiterOrderView.fxml"));
      scene.setRoot((Parent) loader.load());
      WaiterOrderViewController controller = loader.<WaiterOrderViewController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showWaiterPay() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("WaiterPaymentView.fxml"));
      scene.setRoot((Parent) loader.load());
      WaiterPaymentViewController controller = loader.<WaiterPaymentViewController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showPayView() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("PaymentView.fxml"));
      scene.setRoot((Parent) loader.load());
      PaymentController controller = loader.<PaymentController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  public void showAddIngredient() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("AddIngredientView.fxml"));
      scene.setRoot((Parent) loader.load());
      AddIngredientViewController controller = loader.<AddIngredientViewController> getController();
      controller.initialize();
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }
}
