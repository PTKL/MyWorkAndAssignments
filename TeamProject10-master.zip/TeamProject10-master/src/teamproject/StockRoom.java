package teamproject;

import java.util.HashMap;

/**
 * The singleton container for retaining all the information on the stocklevel of the ingredients
 * within the restraunt.
 * 
 * @author callum
 */
public class StockRoom {

  public static StockRoom instance;
  public HashMap<Integer, IngredientReservation> reservations;

  private StockRoom() {
    reservations = new HashMap<Integer, IngredientReservation>();
    update();
  }

  public void update() {
    for (IngredientReservation ir : reservations.values()) {
      for (Ingredient i : ir.reserved.keySet()) {
        Model.getModel().getDatabase().addToIngredientStockLevel(ir.reserved.get(i), i);
      }
    }

    reservations = new HashMap<Integer, IngredientReservation>();

    for (Order o : Model.getModel().getDatabase().getAllOrderReservationCJB()) {
      this.reserveIngredients(o);
    }

  }

  public static StockRoom getInstance() {
    if (instance == null) {
      instance = new StockRoom();
    }

    return instance;
  }

  /**
   * TODO JAVADOC & TEST
   * 
   * @param m
   * @return
   * @author callum
   */
  public boolean haveIngredients(MenuItem m) {
    boolean hasIngredients = true;
    HashMap<Ingredient, Integer> needed = new HashMap<Ingredient, Integer>();

    for (Ingredient i : m.getIngredients()) {
      if (needed.containsKey(i)) {
        needed.put(i, (needed.get(i) + 1));
      } else {
        needed.put(i, 1);
      }
    }

    for (Ingredient i : needed.keySet()) {
      if (needed.get(i) > Model.getModel().getDatabase().getIngredientStockLevel(i)) {
        hasIngredients = false;
      }
    }

    return hasIngredients;
  }

  /**
   * TODO JAVADOC & TEST
   * 
   * @param m
   * @return
   * @author callum
   */
  public boolean haveIngredients(MenuItem[] array) {
    boolean hasIngredients = true;

    for (MenuItem m : array) {
      if (!(haveIngredients(m))) {
        hasIngredients = false;
      }
    }

    return hasIngredients;
  }

  /**
   * TODO JAVADOC & TEST
   * 
   * @param m
   * @return
   * @author callum
   */
  public boolean reserveIngredients(Order o) {
    if (!(haveIngredients(o.getMenuItems()))) {
      return false;
    }

    IngredientReservation reservation = new IngredientReservation(o);
    reservations.put(o.getOrderID(), reservation);
    for (Ingredient i : reservation.reserved.keySet()) {
      Model.getModel().getDatabase().deductFromIngredientStockLevel(reservation.reserved.get(i), i);
    }

    return true;
  }

  /**
   * TODO JAVADOC & TEST
   * 
   * @param m
   * @return
   * @author callum
   */
  public void unreserveIngredients(Order o) {
    IngredientReservation reservation = reservations.get(o.getOrderID());

    for (Ingredient i : reservation.reserved.keySet()) {
      Model.getModel().getDatabase().addToIngredientStockLevel(reservation.reserved.get(i), i);
    }
    reservations.remove(o.getOrderID());
  }

  /**
   * TODO JAVADOC & TEST
   * 
   * @param m
   * @return
   * @author callum
   */
  public void orderStarted(Order o) {
    reservations.remove(o.getOrderID());
  }
}
