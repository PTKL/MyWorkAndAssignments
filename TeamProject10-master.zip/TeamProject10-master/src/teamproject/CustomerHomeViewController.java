package teamproject;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.SplitPane;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * @author emil
 */
public class CustomerHomeViewController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="createOrder"
	private Button createOrder; // Value injected by FXMLLoader

	@FXML // fx:id="cancelOrder"
	private Button cancelOrder; // Value injected by FXMLLoader

	@FXML // fx:id="changeOrder"
	private Button changeOrder; // Value injected by FXMLLoader

	@FXML // fx:id="callWaiter"
	private ToggleButton callWaiter; // Value injected by FXMLLoader

	@FXML
	private AnchorPane custHomeAnchor;

	@FXML
	private Button payBtn;

	@FXML
	private Button logout;

	@FXML
	private Text paymentSuccess;

	@FXML
	private Text paymentFail;

	@FXML
	private SplitPane custSplitPane;

	@FXML
	private Pane custPaneLeft;

	@FXML
	private Pane CustPaneRight;

	@FXML
	private ListView<String> custPaneListLeft = new ListView<String>();;

	@FXML
	private ListView<String> custPaneListRight = new ListView<String>();;

	@FXML
	private Text loginName;

	@FXML
	private Text orderStatusText;
	@FXML
	private Text tableNo;

	@FXML // fx:id="editPreferences"
	private Button editPreferences; // Value injected by FXMLLoader

	@FXML // fx:id="progressBar"
	private ProgressBar progressBar; // Value injected by FXMLLoader

	/**
	 * @author Chris
	 */
	Stage stage;

	ObservableList<String> observableItemList = FXCollections.observableArrayList();
	ObservableList<String> observableOrdersList = FXCollections.observableArrayList();

	ArrayList<Order> allOrders = new ArrayList<Order>();

	public static String customer;

	public static int tableNumber;

	// @FXML // This method is called by the FXMLLoader when initialization is
	// complete
	void initialize() throws FileNotFoundException {
		stage = (Stage) custHomeAnchor.getScene().getWindow();
		stage.setHeight(450);
		stage.setWidth(600);

		Scanner scanner = new Scanner(new FileReader("tableNumber.txt"));
		tableNumber = scanner.nextInt();
		scanner.close();

		paymentSuccess.setText("");
		paymentFail.setText("");

		loginName.setText("Logged in as: " + customer);
		tableNo.setText("Table number: " + tableNumber);

		for (Order o : Model.getModel().getDatabase().getAllOrders()) {
			if (o.getTableNumber() == tableNumber && o.getCustomer().equals(customer)) {
				if (!o.getPaid()) {
					allOrders.add(o);
				} else {
					if (o.getOrderStatus() != OrderStatus.delivered) {
						allOrders.add(o);
					}
				}
			}
		}

		for (Order o : allOrders) {
			observableOrdersList.add("Order " + String.valueOf(o.getOrderID()));
		}

		custPaneListLeft.setItems(observableOrdersList);

		createOrder.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				ViewManager.getInstance().showMenuView();
			}

		});

		changeOrder.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (custPaneListLeft.getSelectionModel().getSelectedIndex() > -1) {

					int index = custPaneListLeft.getSelectionModel().getSelectedIndex();
					Order o = allOrders.get(index);
					if (!o.getPaid()) {
						if (o.getOrderStatus().equals(OrderStatus.ordered)
								|| o.getOrderStatus().equals(OrderStatus.ordering)) {

							Model.getModel().getDatabase().removeOrderFromOrderCJB(o);
							Model.getModel().getDatabase().removeOrderFromOrderReservationCJB(o);
							o.setOrderStatus(OrderStatus.ordering);
							Model.getModel().getDatabase().addOrderToOrderReservationCJB(o);

							MenuViewController.changeOrder = o;
							ViewManager.getInstance().showMenuView();
						} else {
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("Cant Change!");
							alert.setHeaderText(null);
							alert.setContentText("Order is already underway!");
							alert.showAndWait();
						}
					} else {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("Cant Change!");
						alert.setHeaderText(null);
						alert.setContentText("Order is already paid for!");
						alert.showAndWait();
					}
				} else {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Select an order!");
					alert.setHeaderText(null);
					alert.setContentText("Select an order you wish to change!");
					alert.showAndWait();
				}

			}

		});

		cancelOrder.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (custPaneListLeft.getSelectionModel().getSelectedIndex() > -1) {
					int index = custPaneListLeft.getSelectionModel().getSelectedIndex();
					Order o = allOrders.get(index);

					Alert a = new Alert(AlertType.CONFIRMATION);
					a.setTitle("Confirmation Dialog");
					a.setHeaderText(null);
					a.setContentText("Are you sure you would like to cancel 'Order " + o.getOrderID() + "'?");
					ButtonType buttonTypeYes = new ButtonType("Yes");
					ButtonType buttonTypeNo = new ButtonType("No");
					a.getButtonTypes().setAll(buttonTypeYes, buttonTypeNo);

					Optional<ButtonType> result = a.showAndWait();
					if (result.get() == buttonTypeYes) {
						if (o.getOrderStatus().equals(OrderStatus.ordering)
								|| o.getOrderStatus().equals(OrderStatus.ordered)) {
							if (o.getPaid() == false) {
								// if not confirmed by kitchen, order can be
								// cancelled
								StockRoom.getInstance().update();
								StockRoom.getInstance().unreserveIngredients(o);
								Model.getModel().getDatabase().removeOrderFromOrderReservationCJB(o);
								Model.getModel().getDatabase().removeOrderFromOrderCJB(o);
								Alert alert = new Alert(AlertType.INFORMATION);
								alert.setTitle("ORDER CANCELLED");
								alert.setHeaderText(null);
								alert.setContentText("Order " + o.getOrderID() + " has been cancelled!");
								alert.showAndWait();

								allOrders.remove(index);
								observableOrdersList.remove(index);
								currentOrdersController();
							} else {
								Alert alert = new Alert(AlertType.INFORMATION);
								alert.setTitle("CANCEL FAILED!");
								alert.setHeaderText(null);
								alert.setContentText("Sorry, we were unable to cancel order " + o.getOrderID()
										+ " as you've already paid for it!");
								alert.showAndWait();
							}
						} else {
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("CANCEL FAILED!");
							alert.setHeaderText(null);
							alert.setContentText("Sorry, we were unable to cancel order " + o.getOrderID());
							alert.showAndWait();
						}
					} else {
						a.close();
					}
				} else {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Select an order!");
					alert.setHeaderText(null);
					alert.setContentText("Select an order you wish to cancel!");
					alert.showAndWait();
				}

			}
		});

		logout.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				ViewManager.getInstance().showLoginScreen();

			}
		});

		payBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (custPaneListLeft.getSelectionModel().getSelectedIndex() > -1) {
					if (!allOrders.get(custPaneListLeft.getSelectionModel().getSelectedIndex()).getPaid()) {
						PaymentController.o = allOrders.get(custPaneListLeft.getSelectionModel().getSelectedIndex());
						ViewManager.getInstance().showPayView();
					} else {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("Order Paid For!");
						alert.setHeaderText(null);
						alert.setContentText("This order has already been paid for!");
						alert.showAndWait();
					}
				} else {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Select an order!");
					alert.setHeaderText(null);
					alert.setContentText("Select an order you wish to pay for!");
					alert.showAndWait();
				}

			}
		});

		callWaiter.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				Model.getModel().getDatabase().toggleCall(tableNumber);
				if (Model.getModel().getDatabase().getCustomerWaiterCalls().contains(tableNumber)) {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Waiter called!");
					alert.setHeaderText(null);
					alert.setContentText("We have called your waiter!");
					alert.showAndWait();
				} else {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Waiter canceled!");
					alert.setHeaderText(null);
					alert.setContentText("We removed your request to see your waiter!");
					alert.showAndWait();
				}

			}

		});

	}

	public void currentOrdersController() {
		observableItemList.clear();
		int index = custPaneListLeft.getSelectionModel().getSelectedIndex();
		if(index != -1){
			if (allOrders.get(index).getOrderStatus().equals(OrderStatus.ordering)) {
				progressBar.setProgress(0f);
			} else if (allOrders.get(index).getOrderStatus().equals(OrderStatus.ordered)) {
				progressBar.setProgress(0.25f);
			} else if (allOrders.get(index).getOrderStatus().equals(OrderStatus.underway)) {
				progressBar.setProgress(0.5f);
			} else if (allOrders.get(index).getOrderStatus().equals(OrderStatus.ready)) {
				progressBar.setProgress(0.75f);
			} else if (allOrders.get(index).getOrderStatus().equals(OrderStatus.delivered)) {
				progressBar.setProgress(1f);
			}

			orderStatusText.setText("Order Status: " + allOrders.get(index).getOrderStatus());

			for (MenuItem item : allOrders.get(index).getMenuItems()) {
				observableItemList.add(item.getName());
			}
			if (allOrders.get(index).getPaid()) {
				paymentSuccess.setText("Paid!");
				paymentFail.setText("");
			} else {
				paymentSuccess.setText("");
				paymentFail.setText("Not Paid!");
			}
			custPaneListRight.setItems(observableItemList);
		}
	}

	public boolean checkTableNumber(Order o) {
		return o.getTableNumber() == tableNumber;
	}
}
