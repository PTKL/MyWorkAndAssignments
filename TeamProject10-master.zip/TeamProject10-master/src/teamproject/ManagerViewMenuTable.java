package teamproject;

import javafx.beans.property.SimpleStringProperty;

public class ManagerViewMenuTable {
  private final SimpleStringProperty name;
  private final SimpleStringProperty suggestPrice;
  private final SimpleStringProperty price;
  private final SimpleStringProperty calories;
  private final SimpleStringProperty ingredients;

  public ManagerViewMenuTable(String name, String suggestPrice, String price, String calories,
      String ingredients) {
    this.name = new SimpleStringProperty(name);
    this.suggestPrice = new SimpleStringProperty(suggestPrice);
    this.price = new SimpleStringProperty(price);
    this.calories = new SimpleStringProperty(calories);
    this.ingredients = new SimpleStringProperty(ingredients);
  }

  public String getName() {
    return this.name.get();
  }

  public String getSuggestPrice() {
    return this.suggestPrice.get();
  }

  public String getPrice() {
    return this.price.get();
  }

  public String getCalories() {
    return this.calories.get();
  }

  public String getIngredients() {
    return this.ingredients.get();
  }

}
