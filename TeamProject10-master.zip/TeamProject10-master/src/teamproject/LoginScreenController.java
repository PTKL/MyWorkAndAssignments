package teamproject;

/**
*@author emil
*/

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class LoginScreenController {

  @FXML // ResourceBundle that was given to the FXMLLoader
  private ResourceBundle resources;

  @FXML // URL location of the FXML file that was given to the FXMLLoader
  private URL location;

  @FXML // fx:id="logIn"
  private Button logIn; // Value injected by FXMLLoader

  @FXML // fx:id="passField"
  private PasswordField passField; // Value injected by FXMLLoader

  @FXML // fx:id="textField"
  private TextField textField; // Value injected by FXMLLoader

  @FXML // fx:id="signUp"
  private Button signUp; // Value injected by FXMLLoader

  @FXML // fx:id="guest"
  private Button guest; // Value injected by FXMLLoader

  @FXML // fx:id="guest"
  private ImageView logo; // Value injected by FXMLLoader

  @FXML // fx:id="guest"
  private Pane pane; // Value injected by FXMLLoader

  @FXML // This method is called by the FXMLLoader when initialization is
        // complete
  void initialize() {

    logo = new ImageView();
    logo.setImage(new Image(
        "http://1.bp.blogspot.com/_ZddDlRQIWp8/S74rAeOLc5I/AAAAAAAAA3A/DmnaTTnrmkE/s1600/chicks,+salsa2.gif"));
    logo.setFitWidth(200);
    logo.setPreserveRatio(true);
    // logo.setSmooth(true);
    logo.setCache(true);
    pane.getChildren().add(logo);

    logIn.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (Model.getModel().getDatabase().validLogin(textField.getText(), passField.getText())) {
          LoginType lt = Model.getModel().getDatabase().getLoginType(textField.getText());
          if (lt.equals(LoginType.Customer)) {
            CustomerHomeViewController.customer = textField.getText();
            ViewManager.getInstance().showCustomerHome();
          } else if (lt.equals(LoginType.Kitchen)) {
            ViewManager.getInstance().showKitchenHome();
          } else if (lt.equals(LoginType.Manager)) {
            ViewManager.getInstance().showManagerView();

          } else if (lt.equals(LoginType.Waiter)) {
            WaiterHomeViewController.waiterName = textField.getText();
            try {
              ViewManager.getInstance().showWaiterHome();
            } catch (SQLException e) {
              e.printStackTrace();
            }
          }
        } else {
          // not valid login
          Alert alert = new Alert(AlertType.ERROR);
          alert.setTitle("Login Failed");
          alert.setHeaderText("Not Valid Login");
          alert.setContentText("Please check if you have entered the right username and password!");
          alert.showAndWait();
        }
      }
    });

    signUp.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        ViewManager.getInstance().showSignUp();
      }
    });

    guest.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        CustomerHomeViewController.customer = "guest";
        ViewManager.getInstance().showCustomerHome();
      }
    });
  }

}
