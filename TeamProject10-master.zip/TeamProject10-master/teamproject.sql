--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: customercjb; Type: TABLE; Schema: public; Owner: zavc530; Tablespace: 
--

CREATE TABLE customercjb (
    username character varying(255) NOT NULL
);


ALTER TABLE public.customercjb OWNER TO zavc530;

--
-- Name: customerdata; Type: TABLE; Schema: public; Owner: zyvb263; Tablespace: 
--

CREATE TABLE customerdata (
    username character varying(255) NOT NULL,
    usertype character varying(255),
    email character varying(255)
);


ALTER TABLE public.customerdata OWNER TO zyvb263;

--
-- Name: customerwaitercallscjb; Type: TABLE; Schema: public; Owner: manager; Tablespace: 
--

CREATE TABLE customerwaitercallscjb (
    tbl integer NOT NULL,
    "time" bigint
);


ALTER TABLE public.customerwaitercallscjb OWNER TO manager;

--
-- Name: ingredients; Type: TABLE; Schema: public; Owner: zbac002; Tablespace: 
--

CREATE TABLE ingredients (
    id integer,
    ingredient_name character varying(50) NOT NULL,
    cost double precision,
    quantity integer
);


ALTER TABLE public.ingredients OWNER TO zbac002;

--
-- Name: ingredientscjb; Type: TABLE; Schema: public; Owner: zavc530; Tablespace: 
--

CREATE TABLE ingredientscjb (
    stocklevel integer,
    ingredient character varying(2048) NOT NULL
);


ALTER TABLE public.ingredientscjb OWNER TO zavc530;

--
-- Name: loginscjb; Type: TABLE; Schema: public; Owner: zavc530; Tablespace: 
--

CREATE TABLE loginscjb (
    username character varying(255) NOT NULL,
    salt character varying(255),
    hash character varying(2048) NOT NULL,
    usertype character varying(256) NOT NULL
);


ALTER TABLE public.loginscjb OWNER TO zavc530;

--
-- Name: meal_allergies; Type: TABLE; Schema: public; Owner: zbac002; Tablespace: 
--

CREATE TABLE meal_allergies (
    id integer,
    meal_name character varying(50) NOT NULL,
    ingredient_name character varying(50) NOT NULL
);


ALTER TABLE public.meal_allergies OWNER TO zbac002;

--
-- Name: meal_ingredients; Type: TABLE; Schema: public; Owner: zbac002; Tablespace: 
--

CREATE TABLE meal_ingredients (
    id integer,
    meal_name character varying(50) NOT NULL,
    ingredient_name character varying(50) NOT NULL,
    amount integer
);


ALTER TABLE public.meal_ingredients OWNER TO zbac002;

--
-- Name: menuitems; Type: TABLE; Schema: public; Owner: zbac002; Tablespace: 
--

CREATE TABLE menuitems (
    id integer,
    meal_name character varying(50) NOT NULL,
    meal_url character varying(50),
    deal_type character varying(30),
    menu_type character varying(30),
    food_type character varying(30),
    callories integer,
    price real
);


ALTER TABLE public.menuitems OWNER TO zbac002;

--
-- Name: menuitemscjb; Type: TABLE; Schema: public; Owner: zavc530; Tablespace: 
--

CREATE TABLE menuitemscjb (
    menuitem character varying(2048) NOT NULL
);


ALTER TABLE public.menuitemscjb OWNER TO zavc530;

--
-- Name: ordercjb; Type: TABLE; Schema: public; Owner: manager; Tablespace: 
--

CREATE TABLE ordercjb (
    ord character varying(16384) NOT NULL
);


ALTER TABLE public.ordercjb OWNER TO manager;

--
-- Name: orderreservationcjb; Type: TABLE; Schema: public; Owner: manager; Tablespace: 
--

CREATE TABLE orderreservationcjb (
    ord character varying(16384) NOT NULL
);


ALTER TABLE public.orderreservationcjb OWNER TO manager;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: zyvb263; Tablespace: 
--

CREATE TABLE orders (
    id integer NOT NULL,
    ord character varying(16384)
);


ALTER TABLE public.orders OWNER TO zyvb263;

--
-- Name: staffdata; Type: TABLE; Schema: public; Owner: zyvb263; Tablespace: 
--

CREATE TABLE staffdata (
    id integer NOT NULL,
    username character varying(255),
    responcetime integer,
    numberoforders integer
);


ALTER TABLE public.staffdata OWNER TO zyvb263;

--
-- Name: tablenumbercjb; Type: TABLE; Schema: public; Owner: manager; Tablespace: 
--

CREATE TABLE tablenumbercjb (
    tbl integer NOT NULL
);


ALTER TABLE public.tablenumbercjb OWNER TO manager;

--
-- Name: userprefrefs; Type: TABLE; Schema: public; Owner: zyvb263; Tablespace: 
--

CREATE TABLE userprefrefs (
    email integer NOT NULL,
    orders character varying(255),
    prefs character varying(255)
);


ALTER TABLE public.userprefrefs OWNER TO zyvb263;

--
-- Name: waitercjb; Type: TABLE; Schema: public; Owner: zavc530; Tablespace: 
--

CREATE TABLE waitercjb (
    username character varying(255) NOT NULL
);


ALTER TABLE public.waitercjb OWNER TO zavc530;

--
-- Name: waiterreadycjb; Type: TABLE; Schema: public; Owner: manager; Tablespace: 
--

CREATE TABLE waiterreadycjb (
    tbl integer NOT NULL,
    "time" bigint
);


ALTER TABLE public.waiterreadycjb OWNER TO manager;

--
-- Name: waitertablecjb; Type: TABLE; Schema: public; Owner: manager; Tablespace: 
--

CREATE TABLE waitertablecjb (
    username character varying(255) NOT NULL,
    id integer,
    assignedtables character varying(255),
    waitersale integer
);


ALTER TABLE public.waitertablecjb OWNER TO manager;

--
-- Data for Name: customercjb; Type: TABLE DATA; Schema: public; Owner: zavc530
--

COPY customercjb (username) FROM stdin;
\.


--
-- Data for Name: customerdata; Type: TABLE DATA; Schema: public; Owner: zyvb263
--

COPY customerdata (username, usertype, email) FROM stdin;
TestTest	customer	test@test
\.


--
-- Data for Name: customerwaitercallscjb; Type: TABLE DATA; Schema: public; Owner: manager
--

COPY customerwaitercallscjb (tbl, "time") FROM stdin;
1	1458833960856
\.


--
-- Data for Name: ingredients; Type: TABLE DATA; Schema: public; Owner: zbac002
--

COPY ingredients (id, ingredient_name, cost, quantity) FROM stdin;
1	aubergine	1.5	20
2	beef	8.5	5
3	butter	2.5	2
4	chicken breast	4.5	14
5	duck	4.79999999999999982	0
6	cucumber	0.989999999999999991	7
7	potatoes	0.5	20
8	salmon	7.99000000000000021	0
9	sweet potatoes	0.599999999999999978	50
10	honey	5.79999999999999982	0
\.


--
-- Data for Name: ingredientscjb; Type: TABLE DATA; Schema: public; Owner: zavc530
--

COPY ingredientscjb (stocklevel, ingredient) FROM stdin;
255	Ingredient{Rice,1,1,Allergies{}}
342	Ingredient{Vodka,1,20,Allergies{}}
487	Ingredient{Red Onion,1,10,Allergies{}}
50	Ingredient{White Onion,1,28,Allergies{}}
83	Ingredient{BBQ sauce,1,30,Allergies{}}
300	Ingredient{Beans,1,200,Allergies{}}
60	Ingredient{Cayenne Pepper,2,12,Allergies{}}
500	Ingredient{Black pepper,5,4,Allergies{}}
40	Ingredient{Habanero sauce,2,11,Allergies{}}
60	Ingredient{Lettuce,20,50,Allergies{}}
188	Ingredient{Quessadilla,2,100,Allergies{}}
461	Ingredient{Fajita bread,1,80,Allergies{}}
84	Ingredient{Flour,10,500,Allergies{}}
30	Ingredient{Beef Mince,2,300,Allergies{}}
100	Ingredient{Packet of nuts,50,700,Allergies{}}
233	Ingredient{Egg,1,20,Allergies{}}
50	Ingredient{Coke 500ml,1,100,Allergies{}}
83	Ingredient{Ancho Chilli,8,20,Allergies{}}
68	Ingredient{Avocado,20,100,Allergies{}}
48	Ingredient{Black Beans,15,30,Allergies{}}
51	Ingredient{Minced Beef,40,79,Allergies{}}
83	Ingredient{Dark Chocolate,10,18,Allergies{}}
16	Ingredient{Garlic,4,25,Allergies{}}
51	Ingredient{Red Pepper,5,20,Allergies{}}
51	Ingredient{Paprika,1,48,Allergies{}}
83	Ingredient{Cinnamon,5,3,Allergies{}}
51	Ingredient{Sugar,10,90,Allergies{}}
28	Ingredient{Taco Shell,2,30,Allergies{}}
998	Ingredient{Salsa,1,10,Allergies{}}
189	Ingredient{Tomato,10,200,Allergies{}}
98	Ingredient{Cheddar,20,40,Allergies{}}
81	Ingredient{Tortilla,20,40,Allergies{}}
71	Ingredient{Chicken piece,200,1000,Allergies{}}
1	Ingredient{Pork,2,200,Allergies{}}
40	Ingredient{Sweet onion,2,10,Allergies{}}
50	Ingredient{Fish Fillet,2,300,Allergies{}}
60	Ingredient{Chilli Powder,1,8,Allergies{}}
60	Ingredient{Potatoe,1,80,Allergies{}}
509	Ingredient{Tequila,1,20,Allergies{}}
43	Ingredient{Hot pepper,3,1,Allergies{}}
\.


--
-- Data for Name: loginscjb; Type: TABLE DATA; Schema: public; Owner: zavc530
--

COPY loginscjb (username, salt, hash, usertype) FROM stdin;
kitchen	[B@1a53e36	79a5cf22cc180c1f6960439b2c206dc0591b6440498c8c65ddc72f341719eec1672b728078d97541bd2c702be8c68f5dcddce004551134a05fddc51660747820	Kitchen
manager	[B@1cb753e	0feb5c2ccad1935a3c4dbea2d40b1faeadd65300e2e809f373dc5314b58d31a18f14ff2a821c2fba2724d8e6ef7e354c7b0faa8ecab60673d1ff041327216f28	Manager
waiterNew	[B@57150cf8	f08b707084e9317fb175476efd66634910f4c06ab7b4eb1e1f7f4b4069cda17dd3be613a1021f25ce658274b838587af9239f2876f19788e866e9bd4c42a2e9c	Waiter
waiter1	[B@c0f48f7	cc9da226368056d163eb2efddae7c8bdef6db40f0eec7809a2c9f5ad6cbc8fb05834394fdcac306e9cfda5fa2bd59430a8c0deec67f44b8c917bd2da3a9ccc34	Waiter
waiter	[B@16164222	568d936b23d1f59b267beb6242597d92edb140523916b336fd4965086361250355554e580e97497a919adfd8ea99168fafedd53d06350cf9c305c0151764f93a	Waiter
test@gmail.com	[B@36c4079b	9224753b688440df330b2655fdc666c882f83fa55e87d03b7328102ce0ddc83e166e9c1f8ee3259ea4fb55257b4fb93d547e7b185b4b07d316107f96f6ff8011	Customer
customer	[B@1a140084	afd0fe4994434692752171a6ac3fee37171dc79e0655b12e7a35502de7857d2aac0bc7f6c7cb714608312304292219079f9bdb3c64d575fcaeee7bcef19f6549	Customer
\.


--
-- Data for Name: meal_allergies; Type: TABLE DATA; Schema: public; Owner: zbac002
--

COPY meal_allergies (id, meal_name, ingredient_name) FROM stdin;
\.


--
-- Data for Name: meal_ingredients; Type: TABLE DATA; Schema: public; Owner: zbac002
--

COPY meal_ingredients (id, meal_name, ingredient_name, amount) FROM stdin;
\.


--
-- Data for Name: menuitems; Type: TABLE DATA; Schema: public; Owner: zbac002
--

COPY menuitems (id, meal_name, meal_url, deal_type, menu_type, food_type, callories, price) FROM stdin;
1	banana split	miscFiles/banana split.jpeg	REGULAR_MENU	DESSERT	NON_VEGETARIAN	800	19.9899998
2	chicken with rice	miscFiles/chicken with rice.jpeg	REGULAR_MENU	MAIN	DIABETIC	500	11.9899998
3	noodles	miscFiles/noodles.jpeg	REGULAR_MENU	MAIN	NON_VEGETARIAN	750	14.9899998
4	puding	miscFiles/puding.jpeg	REGULAR_MENU	DESSERT	NON_VEGETARIAN	1000	20
5	ice cream	miscFiles/ice cream.jpeg	REGULAR_MENU	DESSERT	NON_VEGETARIAN	800	29
6	smoothie	miscFiles/smoothie.jpeg	REGULAR_MENU	DESSERT	NON_VEGETARIAN	200	40
\.


--
-- Data for Name: menuitemscjb; Type: TABLE DATA; Schema: public; Owner: zavc530
--

COPY menuitemscjb (menuitem) FROM stdin;
MenuItem{Rice,http://i.imgur.com/SwrGLsb.jpg,10,1,1,Categories{Vegetarian,Starter},Ingredients{Ingredient{Rice,1,1,Allergies{}}}}
MenuItem{Vodquila,http://i.imgur.com/zHLfS1O.jpg,5,2,40,Categories{Alcohol,Drink},Ingredients{Ingredient{Vodka,1,20,Allergies{}},Ingredient{Tequila,1,20,Allergies{}}}}
MenuItem{Mexican Potatoes,http://www.bbcgoodfood.com/sites/default/files/styles/recipe/public/recipe_images/recipe-image-legacy-id--219594_11.jpg?itok=10veQZSm,15,10,112,Categories{Starter,Vegetarian},Ingredients{Ingredient{Cayenne Pepper,4,12,Allergies{}},Ingredient{Red Pepper,5,20,Allergies{}},Ingredient{Potatoe,1,80,Allergies{}}}}
MenuItem{Breakfast platter,http://i.imgur.com/5pbuHXY.jpg,10,42,307,Categories{Starter,Main},Ingredients{Ingredient{White Onion,1,28,Allergies{}},Ingredient{Beans,1,200,Allergies{}},Ingredient{Minced Beef,40,79,Allergies{}}}}
MenuItem{Mexican chicken stew,http://www.bbcgoodfood.com/sites/default/files/styles/recipe/public/user-collections/my-colelction-image/2015/12/recipe-image-legacy-id--1068489_11.jpg?itok=chmu8P5m,10,209,1254,Categories{Main},Ingredients{Ingredient{White Onion,1,28,Allergies{}},Ingredient{Chicken piece,200,1000,Allergies{}},Ingredient{Hot pepper,3,1,Allergies{}},Ingredient{Garlic,4,25,Allergies{}},Ingredient{Beans,1,200,Allergies{}}}}
MenuItem{Tequila,http://i.imgur.com/FItmsnC.jpg,1,1,20,Categories{Drink,Alcohol},Ingredients{Ingredient{Tequila,1,20,Allergies{}}}}
MenuItem{Vodka,http://i.imgur.com/QoMM9sQ.jpg,3,1,20,Categories{Alcohol,Drink,Vegetarian},Ingredients{Ingredient{Vodka,1,20,Allergies{}}}}
MenuItem{Mexican potatoes,http://www.bbcgoodfood.com/sites/default/files/styles/recipe/public/recipe_images/recipe-image-legacy-id--219594_11.jpg?itok=10veQZSm,5,7,112,Categories{},Ingredients{Ingredient{Potatoe,1,80,Allergies{}},Ingredient{White Onion,1,28,Allergies{}},Ingredient{Black pepper,5,4,Allergies{}}}}
MenuItem{Burrito,http://i.imgur.com/f7d6Apj.jpg,25,150,1260,Categories{Main,Starter},Ingredients{Ingredient{Fajita bread,40,50,Allergies{}},Ingredient{Beef piece,50,1000,Allergies{}},Ingredient{Tomato,10,200,Allergies{}},Ingredient{Salad,50,10,Allergies{}}}}
MenuItem{Cake,http://i.imgur.com/d39TtTz.jpg,50,11,600,Categories{Dessert},Ingredients{Ingredient{Flour,10,500,Allergies{}},Ingredient{Egg,1,100,Allergies{}}}}
MenuItem{Salad,http://i.imgur.com/eEW0ON3.jpg,1,50,10,Categories{Vegetarian,Starter},Ingredients{Ingredient{Salad,50,10,Allergies{}}}}
MenuItem{Chicken paella,http://i.imgur.com/fPX42KJ.jpg,22,261,1211,Categories{Main},Ingredients{Ingredient{Rice,1,1,Allergies{}},Ingredient{Chicken piece,200,1000,Allergies{}},Ingredient{Salad,50,10,Allergies{}},Ingredient{Tomato,10,200,Allergies{}}}}
MenuItem{Taco,https://maryebecker.files.wordpress.com/2015/04/taco-bell-tacos.jpg,15,123,1910,Categories{Main},Ingredients{Ingredient{Quessadilla,2,100,Allergies{}},Ingredient{Beef piece,50,1000,Allergies{}},Ingredient{Tomato,10,200,Allergies{}},Ingredient{Salad,50,10,Allergies{}},Ingredient{Egg,1,100,Allergies{}},Ingredient{Flour,10,500,Allergies{}}}}
MenuItem{Smoky Pork & Bean Tacos,http://www.bbcgoodfood.com/sites/default/files/styles/recipe/public/recipe_images/recipe-image-legacy-id--1287459_7.jpg?itok=N3v0fF49,30,60,170,Categories{Main},Ingredients{Ingredient{Red Onion,20,10,Allergies{}},Ingredient{Taco Shell,5,30,Allergies{}},Ingredient{Black Beans,15,30,Allergies{}},Ingredient{Avocado,20,100,Allergies{}}}}
MenuItem{Chicken Enchiladas,http://www.bbcgoodfood.com/sites/default/files/styles/recipe/public/recipe_images/recipe-image-legacy-id--1298_11.jpg?itok=Bo4YMboW,10,251,1109,Categories{Starter},Ingredients{Ingredient{Chicken piece,200,1000,Allergies{}},Ingredient{Dark Chocolate,10,18,Allergies{}},Ingredient{Cinnamon,5,3,Allergies{}},Ingredient{Ancho Chilli,8,20,Allergies{}},Ingredient{Onion,8,28,Allergies{}},Ingredient{Tortilla,20,40,Allergies{}}}}
MenuItem{Chicken Nacho Grills,http://www.bbcgoodfood.com/sites/default/files/styles/recipe/public/recipe_images/recipe-image-legacy-id--338829_12.jpg?itok=ByQOkyoc,12,241,1090,Categories{Starter},Ingredients{Ingredient{Salsa,1,10,Allergies{}},Ingredient{Cheddar,20,40,Allergies{}},Ingredient{Tortilla,20,40,Allergies{}},Ingredient{Chicken piece,200,1000,Allergies{}}}}
MenuItem{Chilli con carne,http://www.bbcgoodfood.com/sites/default/files/styles/recipe/public/recipe_images/recipe-image-legacy-id--1001451_6.jpg?itok=UV2FygMI,18,84,290,Categories{Dessert,Starter},Ingredients{Ingredient{Onion,8,28,Allergies{}},Ingredient{Red Pepper,5,20,Allergies{}},Ingredient{Garlic,4,25,Allergies{}},Ingredient{Paprika,17,48,Allergies{}},Ingredient{Sugar,10,90,Allergies{}},Ingredient{Minced Beef,40,79,Allergies{}}}}
MenuItem{Pulled Pork,http://i.imgur.com/0OjLDll.jpg,40,145,484,Categories{Main},Ingredients{Ingredient{Pork,60,200,Allergies{}},Ingredient{BBQ sauce,10,30,Allergies{}},Ingredient{Hot pepper,3,1,Allergies{}},Ingredient{Garlic,4,25,Allergies{}},Ingredient{Onion,8,28,Allergies{}},Ingredient{Pork,60,200,Allergies{}}}}
\.


--
-- Data for Name: ordercjb; Type: TABLE DATA; Schema: public; Owner: manager
--

COPY ordercjb (ord) FROM stdin;
Order{1,delivered,1,guest,true,OrderStatusTime{Key{ordered,1458833326309}Key{ordering,1458833288478}Key{delivered,1458833361965}Key{underway,1458833344382}Key{ready,1458833345420}},MenuItems{MenuItem{Vodquila,http://i.imgur.com/zHLfS1O.jpg,100,700,2500,Categories{Alcohol,Starter,Main,Dessert,Drink,Vegetarian},Ingredients{Ingredient{Vodka,500,1000,Allergies{}},Ingredient{Tequila,200,1500,Allergies{}}}}}}
Order{1,ready,1,guest,false,OrderStatusTime{Key{ordered,1458833374339}Key{ordering,1458833288478}Key{ready,1458834024180}Key{underway,1458834022296}},MenuItems{MenuItem{Vodquila,http://i.imgur.com/zHLfS1O.jpg,100,700,2500,Categories{Alcohol,Starter,Main,Dessert,Drink,Vegetarian},Ingredients{Ingredient{Vodka,500,1000,Allergies{}},Ingredient{Tequila,200,1500,Allergies{}}}},MenuItem{Chicken Nacho Grills,http://www.bbcgoodfood.com/sites/default/files/styles/recipe/public/recipe_images/recipe-image-legacy-id--338829_12.jpg?itok=ByQOkyoc,12,241,1090,Categories{Starter},Ingredients{Ingredient{Salsa,1,10,Allergies{}},Ingredient{Cheddar,20,40,Allergies{}},Ingredient{Tortilla,20,40,Allergies{}},Ingredient{Chicken piece,200,1000,Allergies{}}}}}}
\.


--
-- Data for Name: orderreservationcjb; Type: TABLE DATA; Schema: public; Owner: manager
--

COPY orderreservationcjb (ord) FROM stdin;
Order{1,ordering,1,guest,false,OrderStatusTime{Key{ordering,1458833288478}},MenuItems{MenuItem{Vodquila,http://i.imgur.com/zHLfS1O.jpg,100,700,2500,Categories{Alcohol,Starter,Main,Dessert,Drink,Vegetarian},Ingredients{Ingredient{Vodka,500,1000,Allergies{}},Ingredient{Tequila,200,1500,Allergies{}}}},MenuItem{Chicken Nacho Grills,http://www.bbcgoodfood.com/sites/default/files/styles/recipe/public/recipe_images/recipe-image-legacy-id--338829_12.jpg?itok=ByQOkyoc,12,241,1090,Categories{Starter},Ingredients{Ingredient{Salsa,1,10,Allergies{}},Ingredient{Cheddar,20,40,Allergies{}},Ingredient{Tortilla,20,40,Allergies{}},Ingredient{Chicken piece,200,1000,Allergies{}}}}}}
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: zyvb263
--

COPY orders (id, ord) FROM stdin;
\.


--
-- Data for Name: staffdata; Type: TABLE DATA; Schema: public; Owner: zyvb263
--

COPY staffdata (id, username, responcetime, numberoforders) FROM stdin;
1	test Emp	10	50
2	test Emp2	20	20
\.


--
-- Data for Name: tablenumbercjb; Type: TABLE DATA; Schema: public; Owner: manager
--

COPY tablenumbercjb (tbl) FROM stdin;
\.


--
-- Data for Name: userprefrefs; Type: TABLE DATA; Schema: public; Owner: zyvb263
--

COPY userprefrefs (email, orders, prefs) FROM stdin;
\.


--
-- Data for Name: waitercjb; Type: TABLE DATA; Schema: public; Owner: zavc530
--

COPY waitercjb (username) FROM stdin;
\.


--
-- Data for Name: waiterreadycjb; Type: TABLE DATA; Schema: public; Owner: manager
--

COPY waiterreadycjb (tbl, "time") FROM stdin;
1	1458834024192
\.


--
-- Data for Name: waitertablecjb; Type: TABLE DATA; Schema: public; Owner: manager
--

COPY waitertablecjb (username, id, assignedtables, waitersale) FROM stdin;
test	0		0
waiter1	0	32	0
waiterNew	0	1	0
waiter	0	123456	0
\.


--
-- Name: customercjb_pkey; Type: CONSTRAINT; Schema: public; Owner: zavc530; Tablespace: 
--

ALTER TABLE ONLY customercjb
    ADD CONSTRAINT customercjb_pkey PRIMARY KEY (username);


--
-- Name: customerdata_pkey; Type: CONSTRAINT; Schema: public; Owner: zyvb263; Tablespace: 
--

ALTER TABLE ONLY customerdata
    ADD CONSTRAINT customerdata_pkey PRIMARY KEY (username);


--
-- Name: customerwaitercallscjb_pkey; Type: CONSTRAINT; Schema: public; Owner: manager; Tablespace: 
--

ALTER TABLE ONLY customerwaitercallscjb
    ADD CONSTRAINT customerwaitercallscjb_pkey PRIMARY KEY (tbl);


--
-- Name: ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: zbac002; Tablespace: 
--

ALTER TABLE ONLY ingredients
    ADD CONSTRAINT ingredients_pkey PRIMARY KEY (ingredient_name);


--
-- Name: ingredientscjb_pkey; Type: CONSTRAINT; Schema: public; Owner: zavc530; Tablespace: 
--

ALTER TABLE ONLY ingredientscjb
    ADD CONSTRAINT ingredientscjb_pkey PRIMARY KEY (ingredient);


--
-- Name: loginscjb_pkey; Type: CONSTRAINT; Schema: public; Owner: zavc530; Tablespace: 
--

ALTER TABLE ONLY loginscjb
    ADD CONSTRAINT loginscjb_pkey PRIMARY KEY (username);


--
-- Name: meal_allergies_pkey; Type: CONSTRAINT; Schema: public; Owner: zbac002; Tablespace: 
--

ALTER TABLE ONLY meal_allergies
    ADD CONSTRAINT meal_allergies_pkey PRIMARY KEY (meal_name, ingredient_name);


--
-- Name: meal_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: zbac002; Tablespace: 
--

ALTER TABLE ONLY meal_ingredients
    ADD CONSTRAINT meal_ingredients_pkey PRIMARY KEY (meal_name, ingredient_name);


--
-- Name: menuitems_pkey; Type: CONSTRAINT; Schema: public; Owner: zbac002; Tablespace: 
--

ALTER TABLE ONLY menuitems
    ADD CONSTRAINT menuitems_pkey PRIMARY KEY (meal_name);


--
-- Name: menuitemscjb_pkey; Type: CONSTRAINT; Schema: public; Owner: zavc530; Tablespace: 
--

ALTER TABLE ONLY menuitemscjb
    ADD CONSTRAINT menuitemscjb_pkey PRIMARY KEY (menuitem);


--
-- Name: ordercjb_pkey; Type: CONSTRAINT; Schema: public; Owner: manager; Tablespace: 
--

ALTER TABLE ONLY ordercjb
    ADD CONSTRAINT ordercjb_pkey PRIMARY KEY (ord);


--
-- Name: orderreservationcjb_pkey; Type: CONSTRAINT; Schema: public; Owner: manager; Tablespace: 
--

ALTER TABLE ONLY orderreservationcjb
    ADD CONSTRAINT orderreservationcjb_pkey PRIMARY KEY (ord);


--
-- Name: orders_pkey; Type: CONSTRAINT; Schema: public; Owner: zyvb263; Tablespace: 
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: staffdata_pkey; Type: CONSTRAINT; Schema: public; Owner: zyvb263; Tablespace: 
--

ALTER TABLE ONLY staffdata
    ADD CONSTRAINT staffdata_pkey PRIMARY KEY (id);


--
-- Name: tablenumbercjb_pkey; Type: CONSTRAINT; Schema: public; Owner: manager; Tablespace: 
--

ALTER TABLE ONLY tablenumbercjb
    ADD CONSTRAINT tablenumbercjb_pkey PRIMARY KEY (tbl);


--
-- Name: userprefrefs_pkey; Type: CONSTRAINT; Schema: public; Owner: zyvb263; Tablespace: 
--

ALTER TABLE ONLY userprefrefs
    ADD CONSTRAINT userprefrefs_pkey PRIMARY KEY (email);


--
-- Name: waitercjb_pkey; Type: CONSTRAINT; Schema: public; Owner: zavc530; Tablespace: 
--

ALTER TABLE ONLY waitercjb
    ADD CONSTRAINT waitercjb_pkey PRIMARY KEY (username);


--
-- Name: waiterreadycjb_pkey; Type: CONSTRAINT; Schema: public; Owner: manager; Tablespace: 
--

ALTER TABLE ONLY waiterreadycjb
    ADD CONSTRAINT waiterreadycjb_pkey PRIMARY KEY (tbl);


--
-- Name: waitertablecjb_pkey; Type: CONSTRAINT; Schema: public; Owner: manager; Tablespace: 
--

ALTER TABLE ONLY waitertablecjb
    ADD CONSTRAINT waitertablecjb_pkey PRIMARY KEY (username);


--
-- Name: meal_allergies_ingredient_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zbac002
--

ALTER TABLE ONLY meal_allergies
    ADD CONSTRAINT meal_allergies_ingredient_name_fkey FOREIGN KEY (ingredient_name) REFERENCES ingredients(ingredient_name);


--
-- Name: meal_allergies_meal_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zbac002
--

ALTER TABLE ONLY meal_allergies
    ADD CONSTRAINT meal_allergies_meal_name_fkey FOREIGN KEY (meal_name) REFERENCES menuitems(meal_name);


--
-- Name: meal_ingredients_ingredient_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zbac002
--

ALTER TABLE ONLY meal_ingredients
    ADD CONSTRAINT meal_ingredients_ingredient_name_fkey FOREIGN KEY (ingredient_name) REFERENCES ingredients(ingredient_name);


--
-- Name: meal_ingredients_meal_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: zbac002
--

ALTER TABLE ONLY meal_ingredients
    ADD CONSTRAINT meal_ingredients_meal_name_fkey FOREIGN KEY (meal_name) REFERENCES menuitems(meal_name);


--
-- Name: public; Type: ACL; Schema: -; Owner: zbva488
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM zbva488;
GRANT ALL ON SCHEMA public TO zbva488;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: customercjb; Type: ACL; Schema: public; Owner: zavc530
--

REVOKE ALL ON TABLE customercjb FROM PUBLIC;
REVOKE ALL ON TABLE customercjb FROM zavc530;
GRANT ALL ON TABLE customercjb TO zavc530;
GRANT ALL ON TABLE customercjb TO manager;
GRANT ALL ON TABLE customercjb TO zyvb263;
GRANT ALL ON TABLE customercjb TO zbva017;


--
-- Name: customerdata; Type: ACL; Schema: public; Owner: zyvb263
--

REVOKE ALL ON TABLE customerdata FROM PUBLIC;
REVOKE ALL ON TABLE customerdata FROM zyvb263;
GRANT ALL ON TABLE customerdata TO zyvb263;
GRANT ALL ON TABLE customerdata TO manager;


--
-- Name: ingredientscjb; Type: ACL; Schema: public; Owner: zavc530
--

REVOKE ALL ON TABLE ingredientscjb FROM PUBLIC;
REVOKE ALL ON TABLE ingredientscjb FROM zavc530;
GRANT ALL ON TABLE ingredientscjb TO zavc530;
GRANT ALL ON TABLE ingredientscjb TO manager;
GRANT ALL ON TABLE ingredientscjb TO zyvb263;
GRANT ALL ON TABLE ingredientscjb TO zbva017;


--
-- Name: loginscjb; Type: ACL; Schema: public; Owner: zavc530
--

REVOKE ALL ON TABLE loginscjb FROM PUBLIC;
REVOKE ALL ON TABLE loginscjb FROM zavc530;
GRANT ALL ON TABLE loginscjb TO zavc530;
GRANT ALL ON TABLE loginscjb TO manager;
GRANT ALL ON TABLE loginscjb TO staff;
GRANT ALL ON TABLE loginscjb TO zyvb263;
GRANT ALL ON TABLE loginscjb TO zbva017;


--
-- Name: menuitemscjb; Type: ACL; Schema: public; Owner: zavc530
--

REVOKE ALL ON TABLE menuitemscjb FROM PUBLIC;
REVOKE ALL ON TABLE menuitemscjb FROM zavc530;
GRANT ALL ON TABLE menuitemscjb TO zavc530;
GRANT ALL ON TABLE menuitemscjb TO manager;
GRANT ALL ON TABLE menuitemscjb TO zyvb263;
GRANT ALL ON TABLE menuitemscjb TO zbva017;


--
-- Name: orders; Type: ACL; Schema: public; Owner: zyvb263
--

REVOKE ALL ON TABLE orders FROM PUBLIC;
REVOKE ALL ON TABLE orders FROM zyvb263;
GRANT ALL ON TABLE orders TO zyvb263;
GRANT ALL ON TABLE orders TO manager;


--
-- Name: staffdata; Type: ACL; Schema: public; Owner: zyvb263
--

REVOKE ALL ON TABLE staffdata FROM PUBLIC;
REVOKE ALL ON TABLE staffdata FROM zyvb263;
GRANT ALL ON TABLE staffdata TO zyvb263;
GRANT ALL ON TABLE staffdata TO manager;


--
-- Name: userprefrefs; Type: ACL; Schema: public; Owner: zyvb263
--

REVOKE ALL ON TABLE userprefrefs FROM PUBLIC;
REVOKE ALL ON TABLE userprefrefs FROM zyvb263;
GRANT ALL ON TABLE userprefrefs TO zyvb263;
GRANT ALL ON TABLE userprefrefs TO manager;


--
-- Name: waitercjb; Type: ACL; Schema: public; Owner: zavc530
--

REVOKE ALL ON TABLE waitercjb FROM PUBLIC;
REVOKE ALL ON TABLE waitercjb FROM zavc530;
GRANT ALL ON TABLE waitercjb TO zavc530;
GRANT ALL ON TABLE waitercjb TO manager;
GRANT ALL ON TABLE waitercjb TO zyvb263;
GRANT ALL ON TABLE waitercjb TO zbva017;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: zbva488
--

ALTER DEFAULT PRIVILEGES FOR ROLE zbva488 IN SCHEMA public REVOKE ALL ON TABLES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE zbva488 IN SCHEMA public REVOKE ALL ON TABLES  FROM zbva488;
ALTER DEFAULT PRIVILEGES FOR ROLE zbva488 IN SCHEMA public GRANT SELECT ON TABLES  TO staff;
ALTER DEFAULT PRIVILEGES FOR ROLE zbva488 IN SCHEMA public GRANT SELECT ON TABLES  TO manager;


--
-- PostgreSQL database dump complete
--

