import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import teamproject.Allergy;
import teamproject.Category;
import teamproject.Ingredient;
import teamproject.MenuItem;

/**
 * JUnit tests for MenuItem.
 * 
 * @author Callum
 */
public class MenuItemTest {

  MenuItem mi1, mi2, mi3, mi4, mi5, mi6, mi7, mi8, mi9;
  MenuItem[] mia1, mia2, mia3;

  @Before
  public void preset() {
    Allergy[] alg1 = { Allergy.Fish, Allergy.Nut };
    Allergy[] alg2 = { Allergy.Milk };
    Allergy[] alg3 = { Allergy.Wheat, Allergy.Shellfish };
    Allergy[] alg4 = {};
    Allergy[] alg5 = null;

    Ingredient i1 = new Ingredient("i1", 420, 420, alg1);
    Ingredient i2 = new Ingredient("i2", 420, 420, alg2);
    Ingredient i3 = new Ingredient("i3", 420, 420, alg2);
    Ingredient i4 = new Ingredient("i4", 420, 420, alg3);
    Ingredient i5 = new Ingredient("i5", 420, 420, alg1);
    Ingredient i6 = new Ingredient("i6", 420, 420, alg4);
    Ingredient i7 = new Ingredient("i7", 420, 420, alg5);

    Ingredient[] il1 = { i1 };
    Ingredient[] il2 = { i1, i3, i4 };
    Ingredient[] il3 = { i5, i2, i3 };
    Ingredient[] il4 = { i6 };
    Ingredient[] il5 = { i7 };
    Ingredient[] il6 = {};
    Ingredient[] il7 = null;

    Category[] cat1 = { Category.Starter, Category.Drink };
    Category[] cat2 = { Category.Main };
    Category[] cat3 = { Category.Dessert, Category.Main };
    Category[] cat4 = {};
    Category[] cat5 = null;

    mi1 = new MenuItem("mi1", "url1", 420, il1, cat1);
    mi2 = new MenuItem("mi2", "url2", 420, il2, cat2);
    mi3 = new MenuItem("mi3", "url3", 420, il3, cat3);
    mi4 = new MenuItem("mi3", "url3", 420, il3, cat4);
    mi5 = new MenuItem("mi3", "url3", 420, il3, cat5);
    mi6 = new MenuItem("mi3", "url3", 420, il4, cat4);
    mi7 = new MenuItem("mi3", "url3", 420, il5, cat5);
    mi8 = new MenuItem("mi3", "url3", 420, il6, cat5);
    mi9 = new MenuItem("mi3", "url3", 420, il7, cat5);
    String s = null;
    mi9 = new MenuItem(s, s, 7, il7, cat5);

    mia1 = new MenuItem[0];
    mia2 = new MenuItem[3];
    mia2[0] = mi1;
    mia2[1] = mi2;
    mia2[2] = mi3;
    mia3 = new MenuItem[1];
    mia3[0] = mi3;
  }

  /**
   * 
   */
  @Test
  public void equalsTest() {
    if (mi1.equals(mi2)) {
      fail("");
    }

    if (mi2.equals(mi3)) {
      fail("");
    }

    if (!(mi1.equals(mi1))) {
      fail("");
    }

    if (!(mi2.equals(mi2))) {
      fail("");
    }

    if (!(mi3.equals(mi3))) {
      fail("");
    }
  }

  /**
   * 
   */
  @Test
  public void hashCodeTest() {
    if (mi1.hashCode() == mi2.hashCode()) {
      fail("");
    }

    if (mi2.hashCode() == mi3.hashCode()) {
      fail("");
    }

    if (!(mi1.hashCode() == mi1.hashCode())) {
      fail("");
    }

    if (!(mi2.hashCode() == mi2.hashCode())) {
      fail("");
    }

    if (!(mi3.hashCode() == mi3.hashCode())) {
      fail("");
    }
  }

  /**
   * equals and hascode needa be done before can test toMenuItem() //TODO
   */
  @Test
  public void toStringToMenuItem() {
    assertEquals(mi1, MenuItem.toMenuItem(mi1.toString()));
    assertEquals(mi2, MenuItem.toMenuItem(mi2.toString()));
    assertEquals(mi3, MenuItem.toMenuItem(mi3.toString()));
    assertEquals(mi4, MenuItem.toMenuItem(mi4.toString()));
    assertEquals(mi5, MenuItem.toMenuItem(mi5.toString()));
    assertEquals(mi6, MenuItem.toMenuItem(mi6.toString()));
    assertEquals(mi7, MenuItem.toMenuItem(mi7.toString()));
    assertEquals(mi8, MenuItem.toMenuItem(mi8.toString()));
    assertEquals(mi9, MenuItem.toMenuItem(mi9.toString()));
    
    assertEquals(mi1.toString(), MenuItem.toMenuItem(mi1.toString()).toString());
    assertEquals(mi2.toString(), MenuItem.toMenuItem(mi2.toString()).toString());
  }

  /**
   * TODO
   */
  @Test
  public void toStringToMenuItemArray() {
    assertArrayEquals(mia1, MenuItem.toMenuItemArray(MenuItem.toString(mia1)));
    assertArrayEquals(mia2, MenuItem.toMenuItemArray(MenuItem.toString(mia2)));
    assertArrayEquals(mia3, MenuItem.toMenuItemArray(MenuItem.toString(mia3)));
  }

  /**
   * 
   */
  @Test
  public void isTest() {
    if (mi1.is(Category.Dessert)) {
      fail("");
    }

    if (!(mi1.is(Category.Starter))) {
      fail("");
    }

    if (!(mi2.is(Category.Main))) {
      fail("");
    }

    if (!(mi3.is(Category.Main))) {
      fail("");
    }

    if (mi3.is(Category.Drink)) {
      fail("");
    }
  }
}
