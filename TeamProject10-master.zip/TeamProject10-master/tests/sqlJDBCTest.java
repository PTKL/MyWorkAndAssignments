import java.sql.SQLException;
import java.util.ArrayList;

import teamproject.Allergy;
import teamproject.Category;
import teamproject.Ingredient;
import teamproject.MenuItem;
import teamproject.Model;
import teamproject.Order;
import teamproject.sqlJDBC;

/**
 * JUnit tests for sqlJDBC class.
 * 
 * @author Callum
 */
public class sqlJDBCTest {

  static sqlJDBC instance;

  public static void main(String[] args) {
    Model.getModel();
    instance = sqlJDBC.getsqlJDBC();

    getAllMenuItemsTest();
    getAllIngredientsTest();
    getStockLevelTest();

    // now do the tests
    if (!hashTest()) {
      System.out.println("----FAIL----");
    }

    if (!modifyIngredientTest()) {
      System.out.println("----FAIL----");
    }

    if (!modifyMenuItemTest()) {
      System.out.println("----FAIL----");
    }

    if (!MenuItemAddRemoveTest()) {
      System.out.println("----FAIL----");
    }

    if (!IngredientAddRemoveTest()) {
      System.out.println("----FAIL----");
    }

    if (!stockLevelAddTest()) {
      System.out.println("----FAIL----");
    }

    if (!stockLevelDeductTest()) {
      System.out.println("----FAIL----");
    }

    if (!stockLevelSetTest()) {
      System.out.println("----FAIL----");
    }

//    Allergy[] alg1 = { Allergy.Fish, Allergy.Nut };
//    Allergy[] alg2 = { Allergy.Milk };
//    Allergy[] alg3 = { Allergy.Wheat, Allergy.Shellfish };
//
//    Ingredient i1 = new Ingredient("i1", 420, 420, alg1);
//    Ingredient i2 = new Ingredient("i2", 420, 420, alg2);
//    Ingredient i3 = new Ingredient("i3", 420, 420, alg2);
//    Ingredient i4 = new Ingredient("i4", 420, 420, alg3);
//    Ingredient i5 = new Ingredient("i5", 420, 420, alg1);
//
//    Ingredient[] il1 = { i1 };
//    Ingredient[] il2 = { i1, i3, i4 };
//    Ingredient[] il3 = { i5, i2, i3 };
//
//    Category[] cat1 = { Category.Starter, Category.Drink };
//    Category[] cat2 = { Category.Main };
//    Category[] cat3 = { Category.Dessert, Category.Main };
//
//    MenuItem mi1 = new MenuItem("mi1", "url1", 420, il1, cat1);
//    MenuItem mi2 = new MenuItem("mi2", "url2", 420, il2, cat2);
//    MenuItem mi3 = new MenuItem("mi3", "url3", 420, il3, cat3);
//    
//    MenuItem[] mia2 = new MenuItem[3];
//    mia2[0] = mi1;
//    mia2[1] = mi2;
//    mia2[2] = mi3;
//    MenuItem[] mia3 = new MenuItem[1];
//    mia3[0] = mi3;
//    
//    Order o = new Order(mia2,3,"Ted@me.com");
//    Order o1 = new Order(mia3,3,"Susan@me.com");
//    Order o2 = new Order(mia2,3,"Jason@me.com");
//    Order o3 = new Order(mia2,3,"Alex@me.com");
//    
//    instance.addOrderToOrderCJB(o);
//    instance.addOrderToOrderCJB(o1);
//    instance.addOrderToOrderCJB(o2);
//    instance.addOrderToOrderCJB(o3);
    
    // instance.resetLoginsCJB();
    // temp test
    // instance.addManagerLogin("manager", "manager");
    // instance.addManagerLogin("kitchen", "kitchen");
    try {
      sqlJDBC.printResult(instance.executeSelect("SELECT * FROM loginsCJB"));
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }

  /**
   * This test ensures that for the same input the same hash is return and that for different inputs
   * the different hashes are returned. To ensure the hash function was implemented properly.
   * 
   * @author Callum
   */
  public static boolean hashTest() {
    // String hash1 = sqlJDBC.hash("testing123");
    // String hash2 = sqlJDBC.hash("1234567890");
    // String hash3 = sqlJDBC.hash("DonaldDuck");
    // String hash4 = sqlJDBC.hash("testing123");
    //
    // if (!(hash1.equals(hash4))) {
    // System.out.println("hash1 and hash4 should be equal.");
    // return false;
    // }
    //
    // if (hash2.equals(hash3)) {
    // System.out.println("hash2 and hash3 shouldn't be equal");
    // return false;
    // }
    //
    // if (hash1.equals(hash2)) {
    // System.out.println("hash1 and hash2 shouldn't be equal");
    // return false;
    // }
    //
    // if (hash1.equals(hash3)) {
    // System.out.println("hash1 and hash3 shouldn't be equal");
    // return false;
    // }

    return true;
  }

  /**
   * This test ensures that the getAllMenuItems function functions and prints all the MenuItems in
   * the ArrayList that were returned.
   * 
   * @author Callum
   */
  public static void getAllMenuItemsTest() {
    ArrayList<MenuItem> returned = instance.getAllMenuItems();
    for (MenuItem m : returned) {
      System.out.println("" + m.toString());
    }
  }

  /**
   * This test ensures that the getAllIngredients function functions and prints all the Ingredients
   * in the ArrayList that were returned.
   * 
   * @author Callum
   */
  public static void getAllIngredientsTest() {
    ArrayList<Ingredient> returned = instance.getAllIngredients();
    for (Ingredient i : returned) {
      System.out.println("" + i.toString());
    }
  }

  /**
   * This test ensures that for all Ingredients getStockLevel functions and prints all the
   * Ingredients in along with their stock level.
   * 
   * @author Callum
   */
  public static void getStockLevelTest() {
    ArrayList<Ingredient> returned = instance.getAllIngredients();
    for (Ingredient i : returned) {
      System.out.println(instance.getIngredientStockLevel(i) + " : " + i.toString());
    }
  }

  /**
   * This test ensures that the modifyMenuItem function functions correctly. That the old MenuItem
   * is no longer contained within the database and has been replaced by the new MenuItem.
   * 
   * @author Callum
   */
  public static boolean modifyMenuItemTest() {
    Ingredient[] ing = null;
    Category[] cat = null;

    MenuItem oldM = new MenuItem("oldItem", "", 3, ing, cat);
    MenuItem newM = new MenuItem("newItem", "", 3, ing, cat);

    ArrayList<MenuItem> all = instance.getAllMenuItems();

    if (!(all.contains(oldM))) {
      instance.addMenuItemToMenuItemsCJB(oldM);
    }
    if (all.contains(newM)) {
      instance.removeMenuItemFromMenuItemsCJB(newM);
    }

    instance.modifyMenuItemInMenuItemsCJB(oldM, newM);
    all = instance.getAllMenuItems();

    if (all.contains(oldM)) {
      System.out.println("Shouldn't contain the old menuitem at this point.");
      return false;
    }

    if (!(all.contains(newM))) {
      System.out.println("Should contain the new menuitem at this point.");
      return false;
    }

    instance.removeMenuItemFromMenuItemsCJB(newM);
    return true;
  }

  /**
   * This test ensures that the modifyIngredient function functions correctly. That the old
   * Ingredient is no longer contained within the database and has been replaced by the new
   * Ingredient.
   * 
   * @author Callum
   */
  public static boolean modifyIngredientTest() {
    Allergy[] alg = null;

    Ingredient oldI = new Ingredient("oldItem", 3, 3, alg);
    Ingredient newI = new Ingredient("newItem", 3, 3, alg);

    ArrayList<Ingredient> all = instance.getAllIngredients();

    if (!(all.contains(oldI))) {
      instance.addIngredientToIngredientCJB(oldI);
    }
    if (all.contains(newI)) {
      instance.removeIngredientFromIngredientCJB(newI);
    }

    instance.modifyIngredientInIngredientsCJB(oldI, newI);
    all = instance.getAllIngredients();

    if (all.contains(oldI)) {
      System.out.println("Shouldn't contain the old menuitem at this point.");
      return false;
    }

    if (!(all.contains(newI))) {
      System.out.println("Should contain the new menuitem at this point.");
      return false;
    }

    instance.removeIngredientFromIngredientCJB(newI);
    return true;
  }

  /**
   * This test ensures that both addMenuItemToMenuItemsCJB and removeMenuItemFromMenuItemsCJB both
   * function correctly and add or remove the MenuItem passed into them.
   * 
   * @author Callum
   */
  public static boolean MenuItemAddRemoveTest() {
    MenuItem m = new MenuItem("testmenuitem", "", 7, null, null);

    ArrayList<MenuItem> allMenuItems = instance.getAllMenuItems();

    if (allMenuItems.contains(m)) {
      // remove then add
      instance.removeMenuItemFromMenuItemsCJB(m);
      allMenuItems = instance.getAllMenuItems();
      if (allMenuItems.contains(m)) {
        System.out.println("Item should be removed...");
        return false;
      }

      instance.addMenuItemToMenuItemsCJB(m);
      allMenuItems = instance.getAllMenuItems();
      if (!(allMenuItems.contains(m))) {
        System.out.println("Item should be added...");
        return false;
      }
    } else {
      // add then remove
      instance.addMenuItemToMenuItemsCJB(m);
      allMenuItems = instance.getAllMenuItems();
      if (!(allMenuItems.contains(m))) {
        System.out.println("Item should be added...");
        return false;
      }

      instance.removeMenuItemFromMenuItemsCJB(m);
      allMenuItems = instance.getAllMenuItems();
      if (allMenuItems.contains(m)) {
        System.out.println("Item should be removed...");
        return false;
      }
    }

    return true;
  }

  /**
   * This test ensures that both addIngredientToIngredientCJB and removeIngredientFromIngredientCJB
   * both function correctly and add or remove the Ingredient passed into them.
   * 
   * @author Callum
   */
  public static boolean IngredientAddRemoveTest() {
    Ingredient i = new Ingredient("", 3, 3, null);

    ArrayList<Ingredient> allIngredient = instance.getAllIngredients();

    if (allIngredient.contains(i)) {
      // remove then add
      instance.removeIngredientFromIngredientCJB(i);
      allIngredient = instance.getAllIngredients();
      if (allIngredient.contains(i)) {
        System.out.println("Item should be removed...");
        return false;
      }

      instance.addIngredientToIngredientCJB(i);
      allIngredient = instance.getAllIngredients();
      if (!(allIngredient.contains(i))) {
        System.out.println("Item should be added...");
        return false;
      }
    } else {
      // add then remove
      instance.addIngredientToIngredientCJB(i);
      allIngredient = instance.getAllIngredients();
      if (!(allIngredient.contains(i))) {
        System.out.println("Item should be added...");
        return false;
      }

      instance.removeIngredientFromIngredientCJB(i);
      allIngredient = instance.getAllIngredients();
      if (allIngredient.contains(i)) {
        System.out.println("Item should be removed...");
        return false;
      }
    }

    return true;
  }

  /**
   * This test ensures setIngredientStockLevel functions correctly. By picking an all ready present
   * ingredient within the database and setting it's stock level to a different level and checking
   * getIngredientStockLevel returns the same value before setting it back to its original value.
   * 
   * @author Callum
   */
  public static boolean stockLevelSetTest() {
    ArrayList<Ingredient> allIngredient = instance.getAllIngredients();
    int i = (int) Math.random() * (allIngredient.size() - 1);

    int oldStock = instance.getIngredientStockLevel(allIngredient.get(i));
    int testValue = 92;

    instance.setIngredientStockLevel(testValue, allIngredient.get(i));
    if (!(instance.getIngredientStockLevel(allIngredient.get(i)) == testValue)) {
      System.out.println("Stock level should have been set to the stock level...");
      return false;
    }

    // set back to orginal
    instance.setIngredientStockLevel(oldStock, allIngredient.get(i));
    return true;
  }

  /**
   * This functions ensures addToIngredientStockLevel functions correctly. By adding a test value to
   * an already present Ingredient's in the database stock level. checking it was added VIA
   * getIngredientStockLevel before resetting the original stock level.
   * 
   * @author Callum
   */
  public static boolean stockLevelAddTest() {
    ArrayList<Ingredient> allIngredient = instance.getAllIngredients();
    int i = (int) Math.random() * (allIngredient.size() - 1);

    int oldstock = instance.getIngredientStockLevel(allIngredient.get(i));
    int testValue = 43;

    instance.addToIngredientStockLevel(testValue, allIngredient.get(i));
    if (!(instance.getIngredientStockLevel(allIngredient.get(i)) == (oldstock + testValue))) {
      System.out.println("Should have added on the test value...");
      return false;
    }

    instance.deductFromIngredientStockLevel(testValue, allIngredient.get(i));
    return true;
  }

  /**
   * This functions ensures addToIngrediedeductFromIngredientStockLevelntStockLevel functions
   * correctly. By deducting a test value to an already present Ingredient's in the database stock
   * level. checking it was deducted VIA getIngredientStockLevel before resetting the original stock
   * level.
   * 
   * @author Callum
   */
  public static boolean stockLevelDeductTest() {
    ArrayList<Ingredient> allIngredient = instance.getAllIngredients();
    int i = (int) Math.random() * (allIngredient.size() - 1);

    int oldstock = instance.getIngredientStockLevel(allIngredient.get(i));
    int testValue = 43;

    instance.deductFromIngredientStockLevel(testValue, allIngredient.get(i));
    if (!(instance.getIngredientStockLevel(allIngredient.get(i)) == (oldstock - testValue))) {
      System.out.println("Should have added on the test value...");
      return false;
    }

    instance.addToIngredientStockLevel(testValue, allIngredient.get(i));
    return true;
  }

}
