import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import teamproject.Allergy;
import teamproject.Category;
import teamproject.Ingredient;
import teamproject.MenuItem;
import teamproject.Order;

/**
 * TODO
 * 
 * @author Callum
 */
public class OrderTest {

  Order o1, o2, o3;
  Order[] array;

  @Before
  public void init() {
    Allergy[] alg1 = { Allergy.Fish, Allergy.Nut };
    Allergy[] alg2 = { Allergy.Milk };
    Allergy[] alg3 = { Allergy.Wheat, Allergy.Shellfish };

    Ingredient i1 = new Ingredient("i1", 420, 420, alg1);
    Ingredient i2 = new Ingredient("i2", 420, 420, alg2);
    Ingredient i3 = new Ingredient("i3", 420, 420, alg2);
    Ingredient i4 = new Ingredient("i4", 420, 420, alg3);
    Ingredient i5 = new Ingredient("i5", 420, 420, alg1);

    Ingredient[] il1 = { i1 };
    Ingredient[] il2 = { i1, i3, i4 };
    Ingredient[] il3 = { i5, i2, i3 };

    Category[] cat1 = { Category.Starter, Category.Drink };
    Category[] cat2 = { Category.Main };
    Category[] cat3 = { Category.Dessert, Category.Main };

    MenuItem mi1 = new MenuItem("mi1", "url1", 420, il1, cat1);
    MenuItem mi2 = new MenuItem("mi2", "url2", 420, il2, cat2);
    MenuItem mi3 = new MenuItem("mi3", "url3", 420, il3, cat3);

    MenuItem[] mia1 = null;
    MenuItem[] mia2 = new MenuItem[3];
    mia2[0] = mi1;
    mia2[1] = mi2;
    mia2[2] = mi3;
    MenuItem[] mia3 = new MenuItem[1];
    mia3[0] = mi3;

    o1 = new Order(mia1, 6, "guest3");
    o2 = new Order(mia2, 9, "guest2");
    o3 = new Order(mia3, 7, "guest7");
    array = new Order[3];
    array[0] = o1;
    array[1] = o2;
    array[2] = o3;
  }

  /**
   * TODO
   * 
   * @author callum
   */
  @Test
  public void toOrderStatusReturnedEqualsToStringTest() {
    for (Order o : array) {
      if (!(o.toString().equalsIgnoreCase(Order.toOrder(o.toString()).toString()))) {
        fail("");
      }
    }
  }

}
