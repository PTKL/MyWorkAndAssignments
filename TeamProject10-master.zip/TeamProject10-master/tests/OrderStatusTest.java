import static org.junit.Assert.*;

import org.junit.Test;

import teamproject.OrderStatus;

/**
 * Order Status
 * 
 * @author Callum
 */
public class OrderStatusTest {

  /**
   * TODO
   * 
   * @author callum
   */
  @Test
  public void toOrderStatusReturnedEqualsToStringTest() {
    for (OrderStatus o : OrderStatus.values()) {
      assertEquals(o, OrderStatus.toOrderStatus(o.toString()));
    }
  }
}
