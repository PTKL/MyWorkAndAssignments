import static org.junit.Assert.*;

import org.junit.Test;

import teamproject.Allergy;

/**
 * JUnit tests for Allergy class.
 * 
 * @author Callum
 */
public class AllergyTest {

  /**
   * This test ensures that for every Enum value Allergy holds thats the toAllergy() returns an Enum
   * which is equal to Enum which passed into toAllergy() its toString(). This test ensures toString
   * & toAllergy work for ever Enum in Category it works.
   * 
   * @author Callum
   */
  @Test
  public void toAllergyReturnedEqualsToStringTest() {
    for (Allergy testing : Allergy.values()) {
      assertEquals(testing, Allergy.toAllergy(testing.toString()));
    }
    assertEquals(null, Allergy.toAllergy(null));
  }

  /**
   * This test tests that for a number of Allergy arrays that the toAllergyArray() returns an Enum
   * array which is equal to the Enum array which passed into toAllergyArray() its toString(). This
   * test ensures toString(Allergy[]) & toAllergyArray() work.
   * 
   * @author Callum
   */
  @Test
  public void toAllergyArrayReturnedEqualsToStringTest() {
    Allergy[] alg = { Allergy.Milk, Allergy.Fish, Allergy.Shellfish };
    Allergy[] alg2 = { Allergy.Nut, Allergy.Wheat };
    Allergy[] alg3 = {};
    Allergy[] alg4 = null;

    assertArrayEquals(alg, Allergy.toAllergyArray(Allergy.toString(alg)));
    assertArrayEquals(alg2, Allergy.toAllergyArray(Allergy.toString(alg2)));
    assertArrayEquals(alg3, Allergy.toAllergyArray(Allergy.toString(alg3)));
    assertArrayEquals(alg4, Allergy.toAllergyArray(Allergy.toString(alg4)));
  }
}
