import static org.junit.Assert.*;

import org.junit.Test;

import teamproject.OrderStatus;
import teamproject.OrderStatusTime;

public class OrderStatusTimeTest {

  @Test
  public void toStringToORderStatusTime() {
    OrderStatusTime o = new OrderStatusTime();
    o.setOrderStatusTime(OrderStatus.delivered);
    o.setOrderStatusTime(OrderStatus.ordered);
    o.setOrderStatusTime(OrderStatus.ready);
    assertEquals(o, OrderStatusTime.toOrderStatusTime(o.toString()));
  }

}
