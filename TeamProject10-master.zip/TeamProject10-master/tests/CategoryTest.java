import static org.junit.Assert.*;
import org.junit.Test;

import teamproject.Category;

/**
 * JUnit tests for Category class.
 * 
 * @author Callum
 */
public class CategoryTest {

  /**
   * This test ensures that for every Enum value Category holds thats the toCategory() returns an
   * Enum which is equal to Enum which passed into toCategory() its toString(). This test ensures
   * toString & toCategory work for ever Enum in Category it works.
   * 
   * @author Callum
   */
  @Test
  public void toCategoryReturnedEqualsToStringTest() {
    for (Category testing : Category.values()) {
      assertEquals(testing, Category.toCategory(testing.toString()));
    }
    assertEquals(null, Category.toCategory(null));
  }

  /**
   * This test tests that for a number of category arrays that the toCategoryArray() returns an Enum
   * array which is equal to the Enum array which passed into toCategoryArray() its toString(). This
   * test ensures toString(Allergy[]) & toAllergyArray() work.
   * 
   * @author Callum
   */
  @Test
  public void toCategoryArrayReturnedEqualsToStringTest() {
    Category[] cat1 = { Category.Starter, Category.Drink };
    Category[] cat2 = { Category.Main };
    Category[] cat3 = { Category.Dessert, Category.Main };
    Category[] cat4 = {};
    Category[] cat5 = null;

    assertArrayEquals(cat1, Category.toCategoryArray(Category.toString(cat1)));
    assertArrayEquals(cat2, Category.toCategoryArray(Category.toString(cat2)));
    assertArrayEquals(cat3, Category.toCategoryArray(Category.toString(cat3)));
    assertArrayEquals(cat4, Category.toCategoryArray(Category.toString(cat4)));
    assertArrayEquals(cat5, Category.toCategoryArray(Category.toString(cat5)));
  }
}
