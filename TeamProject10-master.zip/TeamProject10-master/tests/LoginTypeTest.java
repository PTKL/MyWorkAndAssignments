import static org.junit.Assert.*;

import org.junit.Test;

import teamproject.LoginType;

/**
 * JUnit tests for LoginType.
 * 
 * @author Callum
 */
public class LoginTypeTest {

  /**
   * Testing that both the toString and toLoginType function correctly for all LoginTypes.
   */
  @Test
  public void toStringToLoginTypeTest() {
    for (LoginType l : LoginType.values()) {
      assertEquals(l, LoginType.toLoginType(l.toString()));
    }
  }

}
