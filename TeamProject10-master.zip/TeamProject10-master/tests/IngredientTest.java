import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import teamproject.Allergy;
import teamproject.Ingredient;

/**
 * JUnit tests for Ingredient.
 * 
 * @author Callum
 */
public class IngredientTest {
  Ingredient i1, i2, i3, i4, i5;

  @Before
  public void setup() {
    Allergy[] alg1 = { Allergy.Fish, Allergy.Nut };
    Allergy[] alg2 = { Allergy.Milk };
    Allergy[] alg3 = { Allergy.Wheat, Allergy.Shellfish };
    Allergy[] alg4 = {};
    Allergy[] alg5 = null;

    i1 = new Ingredient("i1", 420, 420, alg1);
    i2 = new Ingredient("i2", 420, 420, alg2);
    i3 = new Ingredient("i3", 420, 420, alg3);
    i4 = new Ingredient("i4", 420, 420, alg4);
    i5 = new Ingredient("i5", 420, 420, alg5);
  }

  /**
   * 
   */
  @Test
  public void equalsTest() {
    if (i1.equals(i2)) {
      fail("");
    }

    if (i2.equals(i3)) {
      fail("");
    }

    if (!(i1.equals(i1))) {
      fail("");
    }

    if (!(i2.equals(i2))) {
      fail("");
    }

    if (!(i3.equals(i3))) {
      fail("");
    }

    if (!(i4.equals(i4))) {
      fail("");
    }

    if (!(i5.equals(i5))) {
      fail("");
    }
  }

  /**
   * 
   */
  @Test
  public void hashCodeTest() {
    if (i1.hashCode() == i2.hashCode()) {
      fail("");
    }

    if (i2.hashCode() == i3.hashCode()) {
      fail("");
    }

    if (!(i1.hashCode() == i1.hashCode())) {
      fail("");
    }

    if (!(i2.hashCode() == i2.hashCode())) {
      fail("");
    }

    if (!(i3.hashCode() == i3.hashCode())) {
      fail("");
    }

    if (!(i4.hashCode() == i4.hashCode())) {
      fail("");
    }

    if (!(i5.hashCode() == i5.hashCode())) {
      fail("");
    }
  }

  /**
   * equals and hascode needa be done before can test toMenuItem() //TODO
   */
  @Test
  public void toStringToIngredient() {
    assertEquals(i1, Ingredient.toIngredient(i1.toString()));
    assertEquals(i2, Ingredient.toIngredient(i2.toString()));
    assertEquals(i3, Ingredient.toIngredient(i3.toString()));
    assertEquals(null, Ingredient.toIngredient(null));
  }

  /**
   * 
   */
  @Test
  public void toStringToIngredientArray() {
    Ingredient[] il1 = { i1 };
    Ingredient[] il2 = { i1, i3 };
    Ingredient[] il3 = { i2, i3 };
    Ingredient[] il4 = {};
    Ingredient[] il5 = null;
    Ingredient[] il6 = { i4 };
    Ingredient[] il7 = { i5 };

    assertArrayEquals(il1, Ingredient.toIngredientArray(Ingredient.toString(il1)));
    assertArrayEquals(il2, Ingredient.toIngredientArray(Ingredient.toString(il2)));
    assertArrayEquals(il3, Ingredient.toIngredientArray(Ingredient.toString(il3)));
    assertArrayEquals(il4, Ingredient.toIngredientArray(Ingredient.toString(il4)));
    assertArrayEquals(il5, Ingredient.toIngredientArray(Ingredient.toString(il5)));
    assertArrayEquals(il6, Ingredient.toIngredientArray(Ingredient.toString(il6)));
    assertArrayEquals(il7, Ingredient.toIngredientArray(Ingredient.toString(il7)));
  }

}
