var dropBy = 500;
var sets = [];
var setShown = [];
var sensorShown = [];
var sensors = [];
var currentText = "";
var map;
var mapOptions;
var layer;
var isParksLoaded = false;
function initialize() {
  var mapOptions = {
    center: new google.maps.LatLng(51.446529, -0.443920),
    mapTypeId: google.maps.MapTypeId.ROADMAP,
    zoom: 11
  };
  map = new google.maps.Map(document.getElementById("map"), mapOptions);
  //insertNewDynLayer('./uploads/uj');


};

function insertNewLayer(geojson) {
  var slayer = new google.maps.Data();
  slayer.loadGeoJson(geojson);
  slayer.setMap(map);
}

function insertNewDynLayer(geojson) {
  var dlayer = new google.maps.Data();
  dlayer.loadGeoJson(geojson);
  randCol(dlayer);
  window.setTimeout(function() {
    randCol(dlayer)
  }, 10000);

}

function randCol(rlayer) {

  rlayer.setStyle(function(feature) {
    var color = getRandomColor();
    return /** @type {google.maps.Data.StyleOptions} */ ({
      fillColor: color,
      strokeColor: color,
      strokeWeight: 2
    });
  });
  rlayer.setMap(map);
}

function getRandomColor() {
  var letters = '0123456789ABCDEF';
  var color = '#';
  var end = '00'
  for (var i = 0; i < 4; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color + end;
}

function loadTable(file) {
  var countOfPollenCheck = 0;
  $.ajax({
    dataType: "json",
    url: "../uploads/"+file+".json",
    success: function(data) {
      var tabContents = "";
      $.each(data, function (i, res) {
        i++;
        var row = "<tr>";
          row += "<td>"+i+"</td>"
          row += "<td>"+res.name+"</td>"
          row += "<td>"+res.lnglat+"</td>"
          row += (isParksLoaded&&res.pollen)?"<td><i class=\"glyphicon glyphicon-check isK\"></i></td>":""
          row += "</tr>"
          tabContents += row;
          if(isParksLoaded&&res.pollen) {
            countOfPollenCheck++;
          }
      });
      if(isParksLoaded&&$.inArray(3, sensorShown) !== -1) {
        $("#locNum").text(countOfPollenCheck);
        $("#foundNotification").show();
      }
      console.log(tabContents);
      $("#loadTable").html(tabContents);
    },
    error: console.log
  });


}

function addLayer(type, id) {
  $(this).hide();
  if (type === "set" && $.inArray(id, sets) === -1) {
    $("#setItem" + id).hide();
    sets.push({
      id
    });

    if (id === 1) {
      insertNewLayer('./uploads/shops.geojson');
    } else if (id === 2) {
      insertNewLayer('./uploads/parks.geojson');
      isParksLoaded = true;
      loadTable("parks");
    } else if(id === 3) {

      insertNewLayer('./uploads/cafe.geojson');
      loadTable("cafe");
    }

    reloadSideBar();
  }
  if (type === "sensor" && $.inArray(id, sensors) === -1) {
    $("#sensorItem" + id).hide();

    sensors.push({
      id
    });

    if (id === 1) {
      insertNewDynLayer('./uploads/polution-geojson');
    } else if (id === 2) {
      //insertNewLayer('./uploads/pollen.geojson');
    } else if (id === 3) {
      insertNewDynLayer('./uploads/pollen.geojson');
    }


    reloadSideBar();
  }
  $("#searchBox").val("");
  hideShowResults();
  $("#searchBox").focus();

}



var reloadSideBar = function() {
  var locations;
  var setsHTML = [];
  var sensorsHTML = [];

  $.ajax({
    dataType: "json",

    url: "demoDataDescriptor.json",
    success: function(results) {
      $.each(sets, function(key, data) {
        console.log(data);
        if (results.sets[data.id]) {
          $("#hasNoSets").hide();

          var set = results.sets[data.id];
          setShown.push(set.title);
          setsHTML.push(
            "<div><i class=\"glyphicon glyphicon-minus layer-change remove-layer\"> </i> " +
            set.title + " <input type=\"hidden\" name=\"set" +
            data.id +
            "\" value=\"show\"> </div>");
        }
      });
      $("#hasSets").html(setsHTML);

      $.each(sensors, function(key, data) {

        if (results.sensors[data.id]) {

          $("#hasNoSensors").hide();

          var sensor = results.sensors[data.id];
          sensorShown.push(data.id);
          sensorsHTML.push(generateSensor(data.id, sensor.title,
            sensor.type, sensor.extra));
        }

      });
      $("#hasSensors").html(sensorsHTML);
      if (sensorsHTML.length === 0) {
        $("#hasNoSensors").show();
      }
      if (setsHTML.length === 0) {
        $("#hasNoSets").show();
      }
    },
    error: function(jqXHR, textStatus, errorThrown) {}
  });

  function generateSet(id, name) {
    return
      "<div><i class=\"glyphicon glyphicon-minus layer-change remove-layer\"> </i> " +
      name + " <input type=\"hidden\" name=\"set" + id +
      "\" value=\"show\"> </div>";

  }

  function generateSensor(id, name, type, extra) {
    var entry;
    if (type === "number") {
      entry = (extra.definition) ?
        "<span class=\"input-group-addon\" id=\"basic-addon3\">" + extra.definition +
        "</span>" : "";
      entry += "<input type=\"text\" class=\"form-control\" name=\"sensor" +
        id + "\" value=\"" + extra.default+"\">";
      entry += "<span class=\"input-group-addon\" id=\"basic-addon3\">" +
        extra.unit + "</span>";
    } else if (type === "choice") {
      entry = "<div class=\"btn-group\" role=\"group\">";
      $.each(extra.choice, function(i, choice) {
        entry += "<button type=\"button\" class=\"btn btn-default\">" +
          choice + "</button>";
      });
      entry += "</div>";
    }
    return "<p> <span id=\"title\">" + name +
      "<i class=\"glyphicon glyphicon-minus layer-change remove-layer pull-right\"> </i></span><span class=\"input-group action-entry\">" +
      entry + "</p>";
  }
}

var showSearchResults = function(results) {
  /*if(!isDropped) {
    $("#searchJumbotron").stop(true, false).animate({
         height: dropBy
     });
  }
   isDropped = true;
*/
  $("#setResults").html("");
  $.each(results.sets, function(i, object) {
    console.log(currentText)
    if (($.inArray(object.id, setShown) === -1) && object.title.toUpperCase()
      .includes(currentText.toUpperCase())) $("#setResults").append(
      "<div class=\"listItem addLayer\" id=\"setItem" + object.id +
      "\"><i onClick=\"addLayer('set', " + object.id +
      ")\"  class=\"glyphicon glyphicon-plus layer-change add-layer\"></i> " +
      object.title + "</div>");
  });

  $("#sensorResults").html("");
  $.each(results.sensors, function(i, object) {
    if (($.inArray(object.id, sensorShown) === -1) && object.title.toUpperCase()
      .includes(currentText.toUpperCase())) $("#sensorResults").append(
      "<div class=\"listItem addLayer\" id=\"sensorItem" + object.id +
      "\" ><i onClick=\"addLayer('sensor', " + object.id +
      ")\" class=\"glyphicon glyphicon-plus layer-change add-layer\"></i> " +
      object.title + "</div>");
  })
  $("#seachResults").slideDown();
}

var hideShowResults = function() {
  $("#seachResults").hide();
}

function parseSearch(search) {
  return search.split(" with good ")
}

$(document).ready(function() {
  $("#searchBox").bind('input', function() {
    var value = $(this).val();
    if (value.length > 0) {
      currentText = value;

      $.ajax({
        dataType: "json",
        data: {
          set: parseSearch(value)[0],
          sensor: parseSearch(value)[1]
        },
        url: "demoSearchResults.json",
        success: showSearchResults,
        error: console.log
      });
    } else {
      hideShowResults();
    }




  });



  $("#searchJumbotron").blur(function() {
    hideShowResults();
  });
});


window.QueryString = function() {
  var query_string = {};
  var query = window.location.search.substring(1);
  var vars = query.split("&");
  for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    // If first entry with this name
    if (typeof query_string[pair[0]] === "undefined") {
      query_string[pair[0]] = decodeURIComponent(pair[1]);
      // If second entry with this name
    } else if (typeof query_string[pair[0]] === "string") {
      var arr = [query_string[pair[0]], decodeURIComponent(pair[1])];
      query_string[pair[0]] = arr; // If third or later entry with this name
    } else {
      query_string[pair[0]].push(decodeURIComponent(pair[1]));
    }
  }
  return query_string;
}();
