var express = require('express');
var router = express.Router();
var fileUpload = require('express-fileupload');
var path = require('path');
var fs = require('fs');

/* GET home page. */
router.get('/', function(req, res) {
  res.send("This is da API");
});

router.use(fileUpload());

router.post('/submit/dynamic', function(req, res) {
  var title = req.body.title;
  var description = req.body.description;
  fs.writeFile(path.join(__dirname, '../public/uploads', title), req.body.text, function(err) {
      if(err) {
          return console.log(err);
      }
      res.send("file saved")
  });
});



router.post('/submit', function(req, res) {
  var title = req.body.title;
  var description = req.body.description;



  if (!req.files) {
    res.redirect("./contribute?alert")
    return;
  }

  var file = req.files.file;
  file.mv(path.join(__dirname, '../public/uploads', title), function(err) {
    if (err) {
      res.redirect("./contribute?alert")
    } else {
      res.redirect("/?alert")
    }
  });


});


module.exports = router;
